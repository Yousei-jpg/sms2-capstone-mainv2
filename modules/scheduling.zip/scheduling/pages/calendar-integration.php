<?php
/**
 * SMS 2 - Calendar Integration
 * Module: Class Scheduling  (Phase 9)
 *
 * Presents published schedules in month view and exports them as an
 * iCalendar (.ics) file. The calendar is read-only — it displays what other
 * modules have published and creates no scheduling data of its own.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Calendar Integration';
$activeModule = 'scheduling';
$activePage   = 'calendar-integration';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Calendar Integration', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
    .cal-meta { font-size: .78rem; color: #6c757d; }

    .cal-grid {
        display: grid; grid-template-columns: repeat(7, 1fr);
        gap: 1px; background: #e6e9ef; border: 1px solid #e6e9ef;
        border-radius: .5rem; overflow: hidden;
    }
    .cal-head {
        background: #f4f7fb; padding: .55rem .4rem; text-align: center;
        font-size: .72rem; font-weight: 700; letter-spacing: .05em;
        text-transform: uppercase; color: #40506b;
    }
    .cal-cell {
        background: #fff; min-height: 108px; padding: .4rem .45rem;
        display: flex; flex-direction: column; gap: .2rem;
    }
    .cal-cell.is-blank { background: #fafbfc; }
    .cal-cell.is-today { background: #f4f9ff; box-shadow: inset 0 0 0 2px #9dc2ea; }
    .cal-daynum { font-size: .78rem; font-weight: 700; color: #40506b; }
    .cal-cell.is-today .cal-daynum { color: #1F4E79; }

    .cal-event {
        border-radius: .3rem; padding: .18rem .35rem; font-size: .68rem;
        line-height: 1.25; cursor: default; border-left: 3px solid transparent;
        background: #eef2f7; color: #33405a;
    }
    .cal-event.src-Class   { background: #eaf1fb; border-left-color: #3a6ea8; color: #24405f; }
    .cal-event.src-Special { background: #fdf3e4; border-left-color: #c48521; color: #6d4a09; }
    .cal-event.src-Exam    { background: #fbeaec; border-left-color: #b03a48; color: #6e222c; }
    .cal-event .cal-event-time { font-weight: 700; }
    .cal-event.has-note { box-shadow: inset 0 0 0 1px #e3c98f; }

    .cal-more { font-size: .66rem; color: #6c757d; padding-left: .2rem; }

    .cal-legend { display: flex; flex-wrap: wrap; gap: 1rem; font-size: .76rem; color: #55617a; }
    .cal-legend span.dot {
        display: inline-block; width: .7rem; height: .7rem; border-radius: .2rem;
        margin-right: .3rem; vertical-align: -1px;
    }

    .cal-stat { border-radius: .6rem; border: 1px solid #e6e9ef; padding: .85rem; text-align: center; height: 100%; }
    .cal-stat .cal-stat-value { font-size: 1.6rem; font-weight: 700; line-height: 1; }
    .cal-stat .cal-stat-label {
        font-size: .7rem; letter-spacing: .05em; text-transform: uppercase;
        color: #6c757d; margin-top: .3rem;
    }

    .cal-empty { padding: 2rem 1rem; text-align: center; color: #6c757d; }

    @media (max-width: 767px) {
        .cal-cell { min-height: 76px; }
        .cal-event { font-size: .62rem; }
    }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-calendar-days text-sms-primary me-2"></i>Calendar Integration</h1>
        <p>View published schedules in calendar form and export them to an external calendar.</p>
    </div>
</div>

<div id="calAlert" class="alert submodule-alert d-none" role="alert">
    <i class="fas fa-circle-info me-2"></i><span id="calAlertText"></span>
</div>

<!-- Controls -->
<div class="card mb-3">
    <div class="card-body p-4">
        <div class="row g-3 align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-semibold">Month</label>
                <div class="d-flex align-items-center gap-2">
                    <button id="calPrevBtn" class="btn btn-outline-secondary rounded-3" title="Previous month">
                        <i class="fas fa-chevron-left"></i>
                    </button>
                    <div class="flex-grow-1 text-center fw-semibold" id="calMonthLabel">—</div>
                    <button id="calNextBtn" class="btn btn-outline-secondary rounded-3" title="Next month">
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
            <div class="col-md-3">
                <label for="calSection" class="form-label fw-semibold">Section</label>
                <select id="calSection" class="form-select rounded-3"></select>
            </div>
            <div class="col-md-3">
                <label for="calTeacher" class="form-label fw-semibold">Teacher</label>
                <select id="calTeacher" class="form-select rounded-3"></select>
            </div>
            <div class="col-md-2">
                <label for="calRoom" class="form-label fw-semibold">Room</label>
                <select id="calRoom" class="form-select rounded-3"></select>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-3">
            <button id="calTodayBtn" class="btn btn-outline-primary rounded-3">
                <i class="fas fa-calendar-day me-2"></i>Go to Today
            </button>
            <button id="calExportBtn" class="btn btn-success rounded-3">
                <i class="fas fa-file-arrow-down me-2"></i>Export to Calendar (.ics)
            </button>
            <button id="calClearBtn" class="btn btn-outline-secondary rounded-3">
                <i class="fas fa-filter-circle-xmark me-2"></i>Clear Filters
            </button>
        </div>

        <div class="cal-meta mt-2">
            Only <strong>published</strong> schedules appear. The .ics file imports into Google Calendar,
            Outlook, or Apple Calendar.
        </div>
    </div>
</div>

<!-- Summary -->
<div class="row g-3 mb-3">
    <div class="col-4 col-lg-3">
        <div class="cal-stat">
            <div class="cal-stat-value" id="calStatClass" style="color:#3a6ea8">0</div>
            <div class="cal-stat-label">Class Meetings</div>
        </div>
    </div>
    <div class="col-4 col-lg-3">
        <div class="cal-stat">
            <div class="cal-stat-value" id="calStatSpecial" style="color:#c48521">0</div>
            <div class="cal-stat-label">Special Sessions</div>
        </div>
    </div>
    <div class="col-4 col-lg-3">
        <div class="cal-stat">
            <div class="cal-stat-value" id="calStatExam" style="color:#b03a48">0</div>
            <div class="cal-stat-label">Examinations</div>
        </div>
    </div>
    <div class="col-12 col-lg-3">
        <div class="cal-stat">
            <div class="cal-stat-value" id="calStatTotal" style="color:#1F4E79">0</div>
            <div class="cal-stat-label">Total This Month</div>
        </div>
    </div>
</div>

<!-- Calendar -->
<div class="card">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0"><i class="fas fa-table-cells me-2 text-sms-primary"></i>Month View</h5>
            <div class="cal-legend">
                <span><span class="dot" style="background:#3a6ea8"></span>Class</span>
                <span><span class="dot" style="background:#c48521"></span>Special</span>
                <span><span class="dot" style="background:#b03a48"></span>Exam</span>
            </div>
        </div>

        <div id="calGrid" class="cal-grid"></div>

        <div id="calEmpty" class="cal-empty d-none">
            <i class="fas fa-calendar-xmark fa-2x mb-2 d-block opacity-50"></i>
            No published schedules fall in this month.
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    const CAL_API = '<?= BASE_URL ?>/api/scheduling/calendar.php';
    const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const MAX_PER_CELL = 3;

    const today = new Date();
    let viewYear  = today.getFullYear();
    let viewMonth = today.getMonth() + 1;

    const $ = (id) => document.getElementById(id);

    function showAlert(message, kind) {
        const box = $('calAlert');
        box.className = 'alert submodule-alert alert-' + (kind || 'info');
        $('calAlertText').textContent = message;
        box.classList.remove('d-none');
    }

    function hideAlert() {
        $('calAlert').classList.add('d-none');
    }

    async function request(url) {
        const response = await fetch(url, { method: 'GET' });
        let data = null;

        try {
            data = await response.json();
        } catch (error) {
            throw new Error('The server returned an unreadable response.');
        }

        if (!response.ok || !data.ok) {
            throw new Error((data && data.error) || 'Request failed.');
        }

        return data;
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function fillSelect(id, items, labelFn, placeholder) {
        $(id).innerHTML = '<option value="">' + placeholder + '</option>' +
            items.map((item) =>
                '<option value="' + item.id + '">' + escapeHtml(labelFn(item)) + '</option>'
            ).join('');
    }

    function currentFilters() {
        const params = new URLSearchParams({
            year: String(viewYear),
            month: String(viewMonth)
        });

        const section = $('calSection').value;
        if (section) { params.set('section_id', section); }

        const teacher = $('calTeacher').value;
        if (teacher) { params.set('teacher_id', teacher); }

        const room = $('calRoom').value;
        if (room) { params.set('room_id', room); }

        return params;
    }

    async function loadOptions() {
        try {
            const data = await request(CAL_API + '?action=options');
            fillSelect('calSection', data.sections || [], (s) => s.code + ' — ' + s.name, 'All sections');
            fillSelect('calTeacher', data.teachers || [], (t) => t.full_name, 'All teachers');
            fillSelect('calRoom', data.rooms || [], (r) => r.room_code, 'All rooms');
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function eventMarkup(event) {
        const noteClass = event.note ? ' has-note' : '';
        const tooltipBits = [event.title];

        if (event.subtitle)     { tooltipBits.push(event.subtitle); }
        if (event.teacher_name) { tooltipBits.push(event.teacher_name); }
        if (event.room_code)    { tooltipBits.push(event.room_code); }
        if (event.note)         { tooltipBits.push(event.note); }

        return '<div class="cal-event src-' + escapeHtml(event.source) + noteClass + '" title="' +
            escapeHtml(tooltipBits.join(' · ')) + '">' +
            '<span class="cal-event-time">' + escapeHtml(event.time.split(' - ')[0]) + '</span> ' +
            escapeHtml(event.title) +
            '</div>';
    }

    function renderGrid(data) {
        const grid = $('calGrid');
        const cells = [];

        DAY_NAMES.forEach((name) => {
            cells.push('<div class="cal-head">' + name + '</div>');
        });

        for (let i = 0; i < data.first_weekday; i++) {
            cells.push('<div class="cal-cell is-blank"></div>');
        }

        const todayKey = [
            today.getFullYear(),
            String(today.getMonth() + 1).padStart(2, '0'),
            String(today.getDate()).padStart(2, '0')
        ].join('-');

        for (let day = 1; day <= data.days_in_month; day++) {
            const key = data.year + '-' +
                String(data.month).padStart(2, '0') + '-' +
                String(day).padStart(2, '0');

            const dayEvents = (data.events && data.events[key]) ? data.events[key] : [];
            const isToday = key === todayKey ? ' is-today' : '';

            let body = dayEvents.slice(0, MAX_PER_CELL).map(eventMarkup).join('');

            if (dayEvents.length > MAX_PER_CELL) {
                body += '<div class="cal-more">+' + (dayEvents.length - MAX_PER_CELL) + ' more</div>';
            }

            cells.push(
                '<div class="cal-cell' + isToday + '">' +
                    '<div class="cal-daynum">' + day + '</div>' +
                    body +
                '</div>'
            );
        }

        while (cells.length % 7 !== 0) {
            cells.push('<div class="cal-cell is-blank"></div>');
        }

        grid.innerHTML = cells.join('');
    }

    async function loadMonth() {
        hideAlert();

        try {
            const data = await request(CAL_API + '?action=month&' + currentFilters().toString());

            $('calMonthLabel').textContent = data.month_label;
            $('calStatClass').textContent   = data.counts.Class || 0;
            $('calStatSpecial').textContent = data.counts.Special || 0;
            $('calStatExam').textContent    = data.counts.Exam || 0;
            $('calStatTotal').textContent   = data.total || 0;

            renderGrid(data);

            $('calEmpty').classList.toggle('d-none', data.total > 0);
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function shiftMonth(delta) {
        viewMonth += delta;

        if (viewMonth < 1)  { viewMonth = 12; viewYear -= 1; }
        if (viewMonth > 12) { viewMonth = 1;  viewYear += 1; }

        loadMonth();
    }

    function exportCalendar() {
        window.location.href = CAL_API + '?action=export&' + currentFilters().toString();
        showAlert('Preparing the calendar file. Import it into Google Calendar, Outlook, or Apple Calendar.', 'success');
    }

    document.addEventListener('DOMContentLoaded', function () {
        $('calPrevBtn').addEventListener('click', () => shiftMonth(-1));
        $('calNextBtn').addEventListener('click', () => shiftMonth(1));

        $('calTodayBtn').addEventListener('click', function () {
            viewYear  = today.getFullYear();
            viewMonth = today.getMonth() + 1;
            loadMonth();
        });

        $('calExportBtn').addEventListener('click', exportCalendar);

        $('calClearBtn').addEventListener('click', function () {
            $('calSection').value = '';
            $('calTeacher').value = '';
            $('calRoom').value = '';
            loadMonth();
        });

        $('calSection').addEventListener('change', loadMonth);
        $('calTeacher').addEventListener('change', loadMonth);
        $('calRoom').addEventListener('change', loadMonth);

        loadOptions();
        loadMonth();
    });
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
