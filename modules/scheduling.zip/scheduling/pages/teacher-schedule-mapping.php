<?php
/**
 * SMS 2 - Teacher Schedule Mapping
 * Module: Class Scheduling
 *
 * Front-end wizard implementing the flow:
 *   1. Create Schedule Draft   — pick section, assign teacher/room/day/time per subject
 *   2. Check Availability      — validate teacher load, room use, and conflicts
 *   3. Apply Schedule Decision — resolve conflicts with suggested fixes
 *   4. Publish Schedule Output — release the finalized timetable
 *
 * Phase 1 note: data lives in-browser (JS state) so the flow can be demoed
 * end-to-end. Swap the seed data + publish() stub for real API/DB calls
 * once the backend for this module is implemented.
 * 
 */

require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Teacher Schedule Mapping';
$activeModule = 'scheduling';
$activePage   = 'teacher-schedule-mapping';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Teacher Schedule Mapping', 'url' => null],
];
$initialSection = isset($_GET['section']) ? preg_replace('/[^A-Za-z0-9\-]/', '', $_GET['section']) : '';

/*
 * Conflict resolution hand-off. The Conflict Checker links here with the
 * section, day and start time of a finding so the offending row can be
 * highlighted directly. All three are optional; the page behaves normally
 * when they are absent.
 */
$resolveDay   = isset($_GET['day'])   ? preg_replace('/[^A-Za-z]/', '', $_GET['day']) : '';
$resolveStart = isset($_GET['start']) ? preg_replace('/[^0-9:]/', '', $_GET['start']) : '';
$resolveCid   = isset($_GET['cid'])   ? (int)$_GET['cid'] : 0;

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-chalkboard-user text-sms-primary me-2"></i>Teacher Schedule Mapping</h1>
        <p>Assign teachers and rooms to a section's subjects, resolve conflicts, then publish the timetable.</p>
    </div>
    <div class="tsm-term-badge">
        <i class="fas fa-calendar-alt me-2"></i>
        <span>SY 2026-2027 &middot; 1st Semester</span>
    </div>
</div>

<!-- ================= Stepper ================= -->
<div class="card mb-3">
    <div class="card-body py-3">
        <ol class="tsm-stepper" id="tsmStepper">
            <li data-step="1"><span class="tsm-step-dot"><i class="fas fa-pen-to-square"></i></span><div><strong>Create Schedule Draft</strong><small>Select section, teacher, room</small></div></li>
            <li data-step="2"><span class="tsm-step-dot"><i class="fas fa-magnifying-glass"></i></span><div><strong>Check Availability</strong><small>Validate load, room, conflicts</small></div></li>
            <li data-step="3"><span class="tsm-step-dot"><i class="fas fa-sliders"></i></span><div><strong>Apply Schedule Decision</strong><small>Resolve conflicts</small></div></li>
            <li data-step="4"><span class="tsm-step-dot"><i class="fas fa-paper-plane"></i></span><div><strong>Publish Schedule Output</strong><small>Release the timetable</small></div></li>
        </ol>
    </div>
</div>

<div id="tsmAlert" class="alert alert-success submodule-alert d-none" role="alert">
    <i class="fas fa-check-circle me-2"></i><span id="tsmAlertText"></span>
</div>

<?php if ($resolveDay !== '' && $resolveStart !== ''): ?>
<div class="tsm-resolve-banner" id="tsmResolveBanner">
    <div class="tsm-resolve-icon"><i class="fas fa-wrench"></i></div>
    <div class="flex-grow-1">
        <strong>Resolving a conflict</strong>
        <div class="tsm-resolve-detail">
            The highlighted row is scheduled on <?= htmlspecialchars($resolveDay) ?>
            at <?= htmlspecialchars($resolveStart) ?>. Change its teacher, room, day or time,
            then save and re-run the check.
        </div>
    </div>
    <a class="btn btn-outline-secondary btn-sm"
       href="<?= BASE_URL ?>/modules/scheduling/pages/conflict-checker.php">
        <i class="fas fa-arrow-left me-1"></i>Back to Conflict Checker
    </a>
</div>
<?php endif; ?>

<!-- ================= STEP 1: Create Schedule Draft ================= -->
<section class="tsm-step" id="tsm-step-draft">
    <div class="card mb-3">
        <div class="card-body">
            <div class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label class="form-label fw-semibold small">Section</label>
                    <select class="form-select" id="tsmSectionSelect"></select>
                </div>
                <div class="col-md-8">
                    <div class="tsm-info-chips" id="tsmSectionChips"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="card-title fw-semibold mb-0"><i class="fas fa-book text-sms-primary me-2"></i>Subject Assignment (Create Draft)</h5>
            </div>
            <div class="table-responsive">
                <table class="table submodule-table align-middle mb-0 tsm-draft-table">
                    <thead>
                        <tr>
                            <th style="width:34px">No.</th>
                            <th>Subject Code</th>
                            <th>Subject Name</th>
                            <th style="width:64px">Units</th>
                            <th style="min-width:170px">Select Teacher</th>
                            <th style="min-width:150px">Select Room</th>
                            <th style="min-width:130px">Day</th>
                            <th style="min-width:140px">Time</th>
                            <th style="width:110px">Type</th>
                            <th style="width:50px" class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody id="tsmDraftTableBody"></tbody>
                </table>
            </div>
            <button type="button" class="btn btn-outline-primary btn-sm mt-3" onclick="TSM.openAddSubject()">
                <i class="fas fa-plus me-2"></i>Add Subject / Activity
            </button>
        </div>
    </div>

    <!-- Add-subject inline picker -->
    <div class="card mt-3 d-none" id="tsmAddSubjectCard">
        <div class="card-body">
            <div class="row g-2 align-items-end">
                <div class="col-md-8">
                    <label class="form-label fw-semibold small">Subject to add</label>
                    <select class="form-select" id="tsmAddSubjectSelect"></select>
                </div>
                <div class="col-md-4 d-flex gap-2">
                    <button type="button" class="btn btn-sms-primary flex-fill" onclick="TSM.addSubjectRow()"><i class="fas fa-plus me-2"></i>Add</button>
                    <button type="button" class="btn btn-outline-secondary" onclick="TSM.closeAddSubject()"><i class="fas fa-xmark"></i></button>
                </div>
            </div>
        </div>
    </div>

    <div class="submodule-action-bar">
        <button type="button" class="btn btn-sms-primary ms-auto" onclick="TSM.checkAvailability()">Check Availability<i class="fas fa-magnifying-glass ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 2: Check Availability ================= -->
<section class="tsm-step d-none" id="tsm-step-availability">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                    <h5 class="card-title fw-semibold mb-1"><i class="fas fa-list-check text-sms-primary me-2"></i>Availability Check Results</h5>
                    <p class="text-muted small mb-0">System is validating the draft schedule against teacher load, room use, and section capacity.</p>
                </div>
                <button type="button" class="btn btn-outline-primary btn-sm" onclick="TSM.checkAvailability()"><i class="fas fa-rotate me-2"></i>Re-check Availability</button>
            </div>

            <div class="table-responsive">
                <table class="table submodule-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th style="width:34px">No.</th>
                            <th>Subject</th>
                            <th>Teacher</th>
                            <th>Room</th>
                            <th>Day &amp; Time</th>
                            <th>Result</th>
                            <th class="text-end">Details</th>
                        </tr>
                    </thead>
                    <tbody id="tsmAvailabilityTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row g-3 my-1">
        <div class="col-6 col-md-3">
            <div class="tsm-count-card success"><i class="fas fa-check"></i><strong id="tsmCountAvailable">0</strong><span>Available</span></div>
        </div>
        <div class="col-6 col-md-3">
            <div class="tsm-count-card danger"><i class="fas fa-xmark"></i><strong id="tsmCountConflicts">0</strong><span>Conflicts</span></div>
        </div>
        <div class="col-6 col-md-3">
            <div class="tsm-count-card muted"><i class="fas fa-minus"></i><strong id="tsmCountPending">0</strong><span>Pending</span></div>
        </div>
        <div class="col-6 col-md-3">
            <div class="tsm-count-card status" id="tsmOverallStatusCard">
                <span class="small text-muted d-block">Overall Status</span>
                <strong id="tsmOverallStatusText"></strong>
                <span class="small text-muted d-block" id="tsmOverallStatusHint"></span>
            </div>
        </div>
    </div>

    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="TSM.goToStep('draft')"><i class="fas fa-arrow-left me-2"></i>Back to Draft</button>
        <button type="button" class="btn btn-sms-primary ms-auto" id="tsmResolveBtn" onclick="TSM.goToResolve()">Resolve Conflicts<i class="fas fa-arrow-right ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 3: Apply Schedule Decision ================= -->
<section class="tsm-step d-none" id="tsm-step-resolve">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-1">
                <div>
                    <h5 class="card-title fw-semibold mb-1"><i class="fas fa-shield-halved text-sms-primary me-2"></i>Resolve Conflicts &amp; Apply Decision</h5>
                    <p class="text-muted small mb-0">Review suggestions and apply the best schedule decision.</p>
                </div>
                <div class="text-end">
                    <button type="button" class="btn btn-sms-glass btn-sm" onclick="TSM.autoOptimize()"><i class="fas fa-wand-magic-sparkles me-2"></i>Auto Optimize</button>
                    <div class="small text-muted mt-1">Let the system suggest best options</div>
                </div>
            </div>

            <ul class="nav nav-tabs mt-3" id="tsmResolveTabs">
                <li class="nav-item"><button type="button" class="nav-link active" data-tab="conflicts" onclick="TSM.switchResolveTab('conflicts')">Conflicts <span id="tsmConflictsTabCount">(0)</span></button></li>
                <li class="nav-item"><button type="button" class="nav-link" data-tab="all" onclick="TSM.switchResolveTab('all')">All Suggestions <span id="tsmAllTabCount">(0)</span></button></li>
            </ul>

            <div class="tsm-conflict-list mt-3" id="tsmConflictList"></div>
        </div>
    </div>

    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="TSM.goToStep('availability')"><i class="fas fa-arrow-left me-2"></i>Back to Availability Check</button>
        <button type="button" class="btn btn-sms-primary ms-auto" onclick="TSM.applyAllAndUpdate()">Apply All &amp; Update Draft<i class="fas fa-check-double ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 4: Publish Schedule Output ================= -->
<section class="tsm-step d-none" id="tsm-step-publish">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-1">
                <div>
                    <h5 class="card-title fw-semibold mb-1"><i class="fas fa-circle-check text-success me-2"></i><span id="tsmPublishHeadline">Schedule Published Successfully!</span></h5>
                    <p class="text-muted small mb-0" id="tsmPublishSub">The schedule has been finalized and published.</p>
                </div>
                <span class="badge text-bg-success" id="tsmPublishedBadge">Published</span>
            </div>

            <ul class="nav nav-tabs mt-3" id="tsmPublishTabs">
                <li class="nav-item"><button type="button" class="nav-link active" data-tab="section" onclick="TSM.switchPublishTab('section')">Section Timetable</button></li>
                <li class="nav-item"><button type="button" class="nav-link" data-tab="teacher" onclick="TSM.switchPublishTab('teacher')">Teacher Timetable</button></li>
                <li class="nav-item"><button type="button" class="nav-link" data-tab="room" onclick="TSM.switchPublishTab('room')">Room Schedule</button></li>
                <li class="nav-item"><button type="button" class="nav-link" data-tab="exam" onclick="TSM.switchPublishTab('exam')">Exam Schedule</button></li>
                <li class="nav-item"><button type="button" class="nav-link" data-tab="calendar" onclick="TSM.switchPublishTab('calendar')">Calendar Sync</button></li>
            </ul>

            <div class="mt-3" id="tsmPublishBody"></div>
        </div>
    </div>

    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="TSM.goToStep('draft')"><i class="fas fa-arrow-left me-2"></i>Back to Mapping</button>
        <div class="d-flex gap-2 ms-auto">
    <button type="button" class="btn btn-outline-primary" onclick="TSM.saveSchedule()"><i class="fas fa-save me-2"></i>Save Schedule</button>
    <button type="button" class="btn btn-sms-primary" id="tsmPublishBtn" onclick="TSM.publish()" disabled><i class="fas fa-calendar-check me-2"></i>Publish Schedule</button>
</div>
    </div>
</section>

<style>
.tsm-resolve-banner{display:flex;align-items:center;gap:1rem;padding:.9rem 1.1rem;margin-bottom:1rem;
    border:1px solid var(--sms-primary);border-radius:12px;background:var(--sms-primary-xlight);}
.tsm-resolve-icon{width:40px;height:40px;flex-shrink:0;border-radius:10px;display:flex;align-items:center;
    justify-content:center;background:var(--sms-primary);color:#fff;font-size:1rem;}
.tsm-resolve-detail{font-size:.82rem;color:var(--sms-text-muted);margin-top:.15rem;}
tr.tsm-row-flagged > td{background:rgba(217,119,6,.14)!important;}
.tsm-avail-note{font-size:.7rem;margin-top:.25rem;color:var(--sms-text-muted);}
.tsm-avail-note .tsm-free{color:var(--sms-success);font-weight:700;}
.tsm-avail-note .tsm-busy{color:var(--sms-danger);font-weight:700;}
option.tsm-opt-busy{color:var(--sms-danger);}
tr.tsm-row-flagged > td:first-child{box-shadow:inset 3px 0 0 var(--sms-warning,#d97706);}

.tsm-term-badge{display:inline-flex;align-items:center;padding:.55rem .95rem;border-radius:999px;border:1px solid var(--sms-glass-border);background:var(--sms-surface);color:var(--sms-primary);font-weight:700;font-size:.82rem;backdrop-filter:var(--sms-glass-blur);-webkit-backdrop-filter:var(--sms-glass-blur);}
.tsm-stepper{list-style:none;display:flex;flex-wrap:wrap;gap:.5rem;margin:0;padding:0;}
.tsm-stepper li{flex:1 1 180px;display:flex;align-items:center;gap:.6rem;padding:.5rem .6rem;border-radius:10px;opacity:.55;transition:var(--sms-transition);}
.tsm-stepper li strong{display:block;font-size:.8rem;color:var(--sms-heading);line-height:1.2;}
.tsm-stepper li small{display:block;font-size:.68rem;color:var(--sms-text-muted);}
.tsm-step-dot{width:32px;height:32px;flex-shrink:0;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:var(--sms-surface-muted);color:var(--sms-text-muted);border:1px solid var(--sms-border);font-size:.85rem;}
.tsm-stepper li.active{opacity:1;background:var(--sms-primary-xlight);}
.tsm-stepper li.active .tsm-step-dot{background:var(--sms-primary);color:#fff;border-color:transparent;}
.tsm-stepper li.done{opacity:1;}
.tsm-stepper li.done .tsm-step-dot{background:var(--sms-success);color:#fff;border-color:transparent;}

.tsm-info-chips{display:flex;flex-wrap:wrap;gap:.6rem;}
.tsm-chip{display:flex;align-items:center;gap:.5rem;padding:.5rem .85rem;border:1px solid var(--sms-border);border-radius:10px;background:var(--sms-surface-muted);font-size:.82rem;min-width:120px;}
.tsm-chip i{color:var(--sms-primary);}
.tsm-chip strong{display:block;color:var(--sms-heading);font-size:.9rem;}
.tsm-chip span{display:block;color:var(--sms-text-muted);font-size:.68rem;text-transform:uppercase;letter-spacing:.04em;}

.tsm-draft-table select.form-select,
.tsm-draft-table input.form-control{font-size:.82rem;padding:.35rem .55rem;}
.tsm-del-btn{color:var(--sms-danger);background:none;border:none;font-size:1rem;cursor:pointer;}
.tsm-del-btn:hover{opacity:.7;}

.tsm-count-card{border:1px solid var(--sms-glass-border);border-radius:14px;background:var(--sms-surface);padding:.9rem 1rem;text-align:center;height:100%;box-shadow:var(--sms-shadow-xs);}
.tsm-count-card i{width:34px;height:34px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;margin-bottom:.4rem;font-size:.85rem;}
.tsm-count-card strong{display:block;font-size:1.35rem;color:var(--sms-heading);}
.tsm-count-card span{font-size:.72rem;color:var(--sms-text-muted);text-transform:uppercase;letter-spacing:.04em;}
.tsm-count-card.success i{background:rgba(22,163,74,.15);color:var(--sms-success);}
.tsm-count-card.danger i{background:rgba(220,38,38,.15);color:var(--sms-danger);}
.tsm-count-card.muted i{background:var(--sms-surface-muted);color:var(--sms-text-muted);}
.tsm-count-card.status{text-align:left;}
.tsm-count-card.status strong{font-size:1rem;}
.tsm-count-card.status strong.ok{color:var(--sms-success);}
.tsm-count-card.status strong.issues{color:var(--sms-danger);}

.tsm-conflict-list{display:grid;gap:.9rem;}
.tsm-conflict-card{border:1px solid var(--sms-border);border-radius:12px;padding:1rem 1.1rem;background:var(--sms-surface-muted);}
.tsm-conflict-card.resolved{opacity:.55;}
.tsm-conflict-title{display:flex;align-items:center;gap:.6rem;font-weight:700;color:var(--sms-heading);font-size:.92rem;margin-bottom:.15rem;}
.tsm-conflict-badge{width:24px;height:24px;border-radius:50%;background:var(--sms-danger);color:#fff;font-size:.75rem;display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;}
.tsm-conflict-reason{color:var(--sms-text-muted);font-size:.8rem;margin-bottom:.75rem;}
.tsm-conflict-compare{display:flex;align-items:center;gap:.75rem;flex-wrap:wrap;}
.tsm-conflict-box{flex:1 1 220px;border-radius:10px;padding:.65rem .85rem;font-size:.82rem;}
.tsm-conflict-box.current{background:rgba(220,38,38,.08);border:1px dashed rgba(220,38,38,.35);}
.tsm-conflict-box.suggested{background:rgba(22,163,74,.08);border:1px solid rgba(22,163,74,.35);}
.tsm-conflict-box .label{font-size:.68rem;text-transform:uppercase;letter-spacing:.04em;color:var(--sms-text-muted);display:block;margin-bottom:.2rem;}

.tsm-timetable{width:100%;border-collapse:separate;border-spacing:0;font-size:.78rem;}
.tsm-timetable th,.tsm-timetable td{border:1px solid var(--sms-table-border);padding:.55rem .5rem;vertical-align:top;}
.tsm-timetable thead th{background:var(--sms-table-head-bg);color:var(--sms-text-muted);text-transform:uppercase;font-size:.68rem;letter-spacing:.04em;text-align:center;}
.tsm-timetable td.time-col{white-space:nowrap;font-weight:700;color:var(--sms-heading);background:var(--sms-table-head-bg);}
.tsm-cell-subject{font-weight:700;color:var(--sms-heading);display:block;}
.tsm-cell-meta{color:var(--sms-text-muted);font-size:.72rem;display:block;}
.tsm-cell-empty{color:var(--sms-text-faint);}

@media (max-width:767.98px){ .tsm-stepper li{flex:1 1 100%;} }
</style>

<script>
(function () {
"use strict";

const INITIAL_SECTION = <?= json_encode($initialSection) ?>;

/* ---------------------------------------------------------------------
 * Mock data layer — replace with real API/DB calls once this module's
 * backend endpoints exist.
 * ------------------------------------------------------------------- */
let subjectCatalog = {
    IT301: { name: 'Database Systems', units: 3 },
    IT302: { name: 'Web Development', units: 3 },
    IT303: { name: 'Networking', units: 3 },
    IT304: { name: 'Capstone Project 1', units: 3 },
    GE301: { name: 'Purposive Communication', units: 3 },
    GE302: { name: 'Life and Works of Rizal', units: 3 },
    CS301: { name: 'Data Structures & Algorithms', units: 3 },
    CS302: { name: 'Operating Systems', units: 3 },
    CS303: { name: 'Automata Theory', units: 3 },
    IT201: { name: 'Object-Oriented Programming', units: 3 },
    IT202: { name: 'Industrial Electronics', units: 3 },
    PE301: { name: 'Physical Education 3', units: 2 },
};

let teachers = ['Prof. Juan Cruz', 'Prof. Maria Santos', 'Prof. Mark Reyes', 'Prof. Ana Garcia', 'Prof. Maria Lopez', 'Prof. Liza Fernandez', 'Prof. Ramon Cruz', 'Prof. Noel Reyes', 'Prof. Carlos Dela Cruz', 'Prof. Grace Villanueva'];
let rooms = ['Lab 301', 'Lab 302', 'Lab 303', 'Lab 304', 'Room 204', 'Room 205', 'Room 206', 'Room 301'];
const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
let timeSlots = ['08:00 - 10:00', '10:00 - 12:00', '01:00 - 03:00', '03:00 - 05:00', '05:00 - 07:00'];
const types = ['Lecture', 'Lab'];

function row(subject, teacher, room, day, time, type) {
    return { subject, teacher: teacher || '', room: room || '', day: day || '', time: time || '', type: type || 'Lecture' };
}

let sections = {
    'BSIT-3A': {
        name: 'BSIT 3A', program: 'BSIT', year: '3rd Year', sem: '1st Semester', max: 45, current: 40,
        rows: [
            row('IT301', 'Prof. Juan Cruz', 'Lab 301', 'Monday', '08:00 - 10:00', 'Lecture'),
            row('IT302', 'Prof. Maria Santos', 'Lab 302', 'Tuesday', '10:00 - 12:00', 'Lecture'),
            row('IT303', 'Prof. Mark Reyes', 'Lab 303', 'Wednesday', '01:00 - 03:00', 'Lecture'),
            row('GE301', 'Prof. Ana Garcia', 'Room 204', 'Thursday', '08:00 - 10:00', 'Lecture'),
            row('IT304', '', '', '', '', 'Lab'),
        ],
    },
    'BSIT-3B': {
        name: 'BSIT 3B', program: 'BSIT', year: '3rd Year', sem: '1st Semester', max: 45, current: 38,
        rows: [
            row('IT301', 'Prof. Carlos Dela Cruz', 'Lab 304', 'Monday', '10:00 - 12:00', 'Lecture'),
            row('IT302', 'Prof. Grace Villanueva', 'Lab 301', 'Tuesday', '01:00 - 03:00', 'Lecture'),
            row('IT303', 'Prof. Noel Reyes', 'Lab 302', 'Wednesday', '08:00 - 10:00', 'Lecture'),
            row('GE301', 'Prof. Liza Fernandez', 'Room 205', 'Friday', '10:00 - 12:00', 'Lecture'),
        ],
    },
    'BSCS-3A': {
        name: 'BSCS 3A', program: 'BSCS', year: '3rd Year', sem: '1st Semester', max: 40, current: 35,
        rows: [
            row('CS301', 'Prof. Liza Fernandez', 'Lab 303', 'Monday', '01:00 - 03:00', 'Lecture'),
            row('CS302', 'Prof. Ramon Cruz', 'Lab 304', 'Tuesday', '08:00 - 10:00', 'Lecture'),
            row('GE301', '', '', '', '', 'Lecture'),
        ],
    },
    'IT-3A': {
        name: 'IT 3A', program: 'BIT', year: '3rd Year', sem: '1st Semester', max: 45, current: 36,
        rows: [
            row('IT201', 'Prof. Noel Reyes', 'Lab 301', 'Thursday', '10:00 - 12:00', 'Lecture'),
            row('IT202', '', '', '', '', 'Lab'),
            row('GE302', 'Prof. Ana Garcia', 'Room 206', 'Friday', '08:00 - 10:00', 'Lecture'),
        ],
    },
};

const SMS_BASE = '<?= BASE_URL ?>';
    /* Conflict hand-off: which row should be flagged, if any. */
    const TSM_RESOLVE = {
        day:   '<?= htmlspecialchars($resolveDay, ENT_QUOTES) ?>',
        start: '<?= htmlspecialchars($resolveStart, ENT_QUOTES) ?>'
    };
const TEACHER_SCHEDULE_API = SMS_BASE + '/api/scheduling/teacher-schedule-mapping.php';

function formatScheduleTime(start, end) {
    if (!start || !end) return '';
    return `${String(start).substring(0, 5)} - ${String(end).substring(0, 5)}`;
}

async function loadTeacherScheduleFromAPI(sectionCode) {
    let url = TEACHER_SCHEDULE_API;
    if (sectionCode) {
        url += '?section_code=' + encodeURIComponent(sectionCode);
    }

    console.log('Loading Teacher Schedule API:', url);

    const response = await fetch(url, {
        credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
    });

    const text = await response.text();
    console.log('Teacher Schedule API status:', response.status);
    console.log('Teacher Schedule API response:', text);

    let data;
    try {
        data = JSON.parse(text);
    } catch (error) {
        throw new Error(`Teacher Schedule API returned invalid JSON (HTTP ${response.status}).`);
    }

    if (!response.ok || !data.ok) {
        throw new Error(data.error || 'Unable to load Teacher Schedule data.');
    }

    subjectCatalog = {};
    (data.subjects || []).forEach(subject => {
        subjectCatalog[subject.code] = {
            name: subject.name,
            units: Number(subject.units) || 0,
        };
    });

    teachers = (data.teachers || []).map(teacher => teacher.full_name).filter(Boolean);
    rooms = (data.rooms || []).map(room => room.room_code).filter(Boolean);
    const dbTimeBlocks = (data.time_blocks || []).map(tb => tb.label).filter(Boolean);
    if (dbTimeBlocks.length > 0) {
        timeSlots = dbTimeBlocks;
    }

    const apiSections = {};
    (data.sections || []).forEach(section => {
        const yearLevel = Number(section.year_level) || 0;
        const yearLabel = yearLevel === 1 ? '1st Year'
            : yearLevel === 2 ? '2nd Year'
            : yearLevel === 3 ? '3rd Year'
            : yearLevel === 4 ? '4th Year'
            : `${yearLevel}th Year`;
        apiSections[section.code] = {
            name: section.name,
            program: section.program,
            year: yearLabel,
            sem: section.semester,
            max: Number(section.max_students) || 0,
            current: Number(section.current_students) || 0,
            rows: [],
        };
    });

    if (data.section && sectionCode) {
        if (!apiSections[sectionCode]) {
            throw new Error(`Section ${sectionCode} was not found in the API response.`);
        }

        const bySubject = {};
        (data.section_schedule || []).forEach(schedule => {
            bySubject[schedule.subject_code] = schedule;
        });

        apiSections[sectionCode].rows = (data.assigned_subjects || []).map(subject => {
            const existing = bySubject[subject.code];
            return row(
                subject.code,
                existing?.teacher_name || '',
                existing?.room_code || '',
                existing?.day_of_week || '',
                existing ? formatScheduleTime(existing.start_time, existing.end_time) : '',
                existing?.class_type || (subject.subject_type === 'Lab' ? 'Lab' : 'Lecture')
            );
        });
    }

    sections = apiSections;

    console.log('Database subjects:', subjectCatalog);
    console.log('Database teachers:', teachers);
    console.log('Database rooms:', rooms);
    console.log('Database sections:', sections);
}

/* Fixed bookings from OTHER sections — used to simulate real conflicts. */
const externalBookings = [
    { section: 'BSIT-2A', teacher: 'Prof. Maria Santos', room: 'Lab 302', day: 'Tuesday', time: '10:00 - 12:00' },
    { section: 'BSCS-2A', teacher: 'Prof. Carlos Dela Cruz', room: 'Room 204', day: 'Thursday', time: '08:00 - 10:00' },
];

/* ---------------------------------------------------------------------
 * TSM — wizard controller
 * ------------------------------------------------------------------- */
const TSM = {
    sectionCode: null,
    results: [],
    suggestions: [],
    resolveTab: 'conflicts',
    publishTab: 'section',
    scheduleSaved: false,
    // Keep unsaved edits/suggestions in memory so navigating between
    // Draft -> Availability -> Resolve cannot overwrite them with API data.
    unsavedDrafts: {},

    rememberDraft() {
        if (!this.sectionCode || !sections[this.sectionCode]) return;
        this.unsavedDrafts[this.sectionCode] = sections[this.sectionCode].rows.map(r => ({ ...r }));
    },

    restoreDraft(code) {
        const savedRows = this.unsavedDrafts[code];
        if (!savedRows || !sections[code]) return;
        sections[code].rows = savedRows.map(r => ({ ...r }));
    },

    escape(str) {
        return String(str ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    },

    optionList(arr, current) {
        return arr.map(v => `<option value="${this.escape(v)}" ${v === current ? 'selected' : ''}>${this.escape(v)}</option>`).join('');
    },

    /* ---------- navigation ---------- */
    goToStep(name) {
        document.querySelectorAll('.tsm-step').forEach(el => el.classList.add('d-none'));
        document.getElementById('tsm-step-' + name).classList.remove('d-none');
        window.scrollTo({ top: document.querySelector('.page-header').offsetTop - 20, behavior: 'smooth' });
        this.updateStepper(name);
    },

    stepMap: { draft: 1, availability: 2, resolve: 3, publish: 4 },

    updateStepper(name) {
        const active = this.stepMap[name] || 1;
        document.querySelectorAll('#tsmStepper li').forEach(li => {
            const n = parseInt(li.dataset.step, 10);
            li.classList.remove('active', 'done');
            if (n < active) li.classList.add('done');
            else if (n === active) li.classList.add('active');
        });
    },

    showAlert(msg) {
        const box = document.getElementById('tsmAlert');
        document.getElementById('tsmAlertText').textContent = msg;
        box.classList.remove('d-none');
        clearTimeout(this._alertTimer);
        this._alertTimer = setTimeout(() => box.classList.add('d-none'), 4000);
    },

    /* ---------- STEP 1: draft ---------- */
    initSectionSelect() {
        const sel = document.getElementById('tsmSectionSelect');
        sel.innerHTML = Object.keys(sections).map(code => `<option value="${code}">${code} — ${this.escape(sections[code].name)}</option>`).join('');
        const startCode = (INITIAL_SECTION && sections[INITIAL_SECTION]) ? INITIAL_SECTION : Object.keys(sections)[0];
        sel.value = startCode;

        sel.addEventListener('change', async () => {
            const code = sel.value;

            // Preserve any edits in the section we are leaving.
            this.rememberDraft();

            try {
                await loadTeacherScheduleFromAPI(code);
                this.restoreDraft(code);
                this.loadSection(code);
            } catch (error) {
                console.error('Unable to load selected section:', error);
                this.showAlert('Unable to load section data: ' + error.message);
            }
        });

        loadTeacherScheduleFromAPI(startCode)
            .then(() => this.loadSection(startCode))
            .catch(error => {
                console.error('Unable to load initial section:', error);
                this.loadSection(startCode);
            });
    },

    loadSection(code) {
        this.sectionCode = code;
        this.restoreDraft(code);
        const s = sections[code];
        document.getElementById('tsmSectionChips').innerHTML = `
            <div class="tsm-chip"><i class="fas fa-graduation-cap"></i><div><strong>${this.escape(s.program)}</strong><span>Program</span></div></div>
            <div class="tsm-chip"><i class="fas fa-layer-group"></i><div><strong>${this.escape(s.year)}</strong><span>Year Level</span></div></div>
            <div class="tsm-chip"><i class="fas fa-calendar"></i><div><strong>${this.escape(s.sem)}</strong><span>Semester</span></div></div>
            <div class="tsm-chip"><i class="fas fa-users"></i><div><strong>${s.max}</strong><span>Max Students</span></div></div>
            <div class="tsm-chip"><i class="fas fa-user-check"></i><div><strong>${s.current}</strong><span>Assigned Students</span></div></div>
        `;
        this.renderDraftTable();
        this.closeAddSubject();
    },

    renderDraftTable() {
        const s = sections[this.sectionCode];
        document.getElementById('tsmDraftTableBody').innerHTML = s.rows.map((r, i) => {
            const sub = subjectCatalog[r.subject] || { name: r.subject, units: '—' };
            return `
            <tr>
                <td>${i + 1}</td>
                <td class="fw-semibold">${this.escape(r.subject)}</td>
                <td>${this.escape(sub.name)}</td>
                <td>${sub.units}</td>
                <td><select class="form-select" onchange="TSM.updateRow(${i},'teacher',this.value)"><option value="">-- Select Teacher --</option>${this.optionList(teachers, r.teacher)}</select></td>
                <td><select class="form-select" onchange="TSM.updateRow(${i},'room',this.value)"><option value="">-- Select Room --</option>${this.optionList(rooms, r.room)}</select></td>
                <td><select class="form-select" onchange="TSM.updateRow(${i},'day',this.value)"><option value="">-- Day --</option>${this.optionList(days, r.day)}</select></td>
                <td><select class="form-select" onchange="TSM.updateRow(${i},'time',this.value)"><option value="">-- Time --</option>${this.optionList(timeSlots, r.time)}</select></td>
                <td><select class="form-select" onchange="TSM.updateRow(${i},'type',this.value)">${this.optionList(types, r.type)}</select></td>
                <td class="text-center"><button type="button" class="tsm-del-btn" title="Remove" onclick="TSM.removeRow(${i})"><i class="fas fa-trash"></i></button></td>
            </tr>`;
        }).join('') || `<tr><td colspan="10" class="text-center text-muted py-3">No subjects in this section yet.</td></tr>`;

        this.flagConflictRow();
        this.refreshAvailability();
    },

    /*
     * Live availability. For every row that already has a day and a time, the
     * teacher and room dropdowns are relabelled to show whether each option is
     * free in that slot. Rows sharing a slot are fetched once, so a four-row
     * draft on four different slots costs four requests, not forty.
     */
    slotCache: {},

    async refreshAvailability() {
        const s = sections[this.sectionCode];
        if (!s) { return; }

        const body = document.getElementById('tsmDraftTableBody');
        const wanted = new Map();

        s.rows.forEach((r, i) => {
            if (!r.day || !r.time) { return; }
            const parts = String(r.time).split('-').map(v => v.trim());
            if (parts.length !== 2) { return; }

            const key = r.day + '|' + parts[0] + '|' + parts[1];
            if (!wanted.has(key)) {
                wanted.set(key, { day: r.day, start: parts[0], end: parts[1], rows: [] });
            }
            wanted.get(key).rows.push(i);
        });

        for (const [key, slot] of wanted) {
            let data = this.slotCache[key];

            if (!data) {
                try {
                    const params = new URLSearchParams({
                        action: 'slot',
                        day: slot.day,
                        start: slot.start,
                        end: slot.end,
                        exclude_section: this.sectionCode || ''
                    });

                    const response = await fetch(
                        SMS_BASE + '/api/scheduling/slot-availability.php?' + params.toString()
                    );
                    const payload = await response.json();
                    if (!response.ok || !payload.ok) { continue; }

                    data = payload;
                    this.slotCache[key] = data;
                } catch (error) {
                    continue;
                }
            }

            slot.rows.forEach(i => {
                const tr = body.rows[i];
                if (!tr) { return; }

                this.labelSelect(tr.cells[4].querySelector('select'), data.teachers);
                this.labelSelect(tr.cells[5].querySelector('select'), data.rooms);

                const cell = tr.cells[4];
                let note = cell.querySelector('.tsm-avail-note');
                if (!note) {
                    note = document.createElement('div');
                    note.className = 'tsm-avail-note';
                    cell.appendChild(note);
                }
                note.innerHTML =
                    '<span class="tsm-free">' + data.summary.teachers_available + ' free</span> \u00b7 ' +
                    '<span class="tsm-busy">' + data.summary.teachers_occupied + ' occupied</span>';
            });
        }
    },

    /*
     * Rewrites option labels in place. The option value is left untouched, so a
     * selection already made stays valid. Occupied options remain visible and
     * selectable — the user may still need to pick one and move the other class.
     */
    labelSelect(select, items) {
        if (!select || !items) { return; }

        const byName = {};
        items.forEach(item => { byName[item.name] = item; });

        Array.from(select.options).forEach(option => {
            if (!option.value) { return; }

            const info = byName[option.value];
            if (!info) { return; }

            if (info.available) {
                option.textContent = '\u25cf ' + info.name + ' \u2014 Available';
                option.classList.remove('tsm-opt-busy');
            } else {
                const where = info.busy_with ? ' (' + info.busy_with + ')' : '';
                option.textContent = '\u25cf ' + info.name + ' \u2014 Occupied' + where;
                option.classList.add('tsm-opt-busy');
            }
        });
    },

    /*
     * Highlights the row a conflict finding refers to. Matching is done on day
     * and start time, which is what conflict_results stores; the entry id is
     * not carried on the draft rows.
     */
    flagConflictRow() {
        if (!TSM_RESOLVE.day || !TSM_RESOLVE.start) {
            return;
        }

        const s = sections[this.sectionCode];
        if (!s) { return; }

        const body = document.getElementById('tsmDraftTableBody');
        let first = null;

        s.rows.forEach((r, i) => {
            const sameDay  = String(r.day || '') === TSM_RESOLVE.day;
            const sameTime = String(r.time || '').replace(/\s/g, '')
                                .startsWith(TSM_RESOLVE.start.replace(/\s/g, ''));

            if (sameDay && sameTime) {
                const tr = body.rows[i];
                if (tr) {
                    tr.classList.add('tsm-row-flagged');
                    if (!first) { first = tr; }
                }
            }
        });

        if (first) {
            first.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    },

    updateRow(i, field, value) {
        sections[this.sectionCode].rows[i][field] = value;
        this.rememberDraft();

        /* A new day or time means a different slot, so availability is re-read. */
        if (field === 'day' || field === 'time') {
            this.renderDraftTable();
        }
    },

    removeRow(i) {
        sections[this.sectionCode].rows.splice(i, 1);
        this.rememberDraft();
        this.renderDraftTable();
    },

    openAddSubject() {
        const s = sections[this.sectionCode];
        const used = s.rows.map(r => r.subject);
        const available = Object.keys(subjectCatalog).filter(code => !used.includes(code));
        document.getElementById('tsmAddSubjectSelect').innerHTML = available.length
            ? available.map(code => `<option value="${code}">${code} — ${this.escape(subjectCatalog[code].name)}</option>`).join('')
            : `<option value="">No more subjects available</option>`;
        document.getElementById('tsmAddSubjectCard').classList.remove('d-none');
    },

    closeAddSubject() {
        document.getElementById('tsmAddSubjectCard').classList.add('d-none');
    },

    addSubjectRow() {
        const code = document.getElementById('tsmAddSubjectSelect').value;
        if (!code) return;
        sections[this.sectionCode].rows.push(row(code, '', '', '', '', 'Lecture'));
        this.rememberDraft();
        this.renderDraftTable();
        this.closeAddSubject();
    },

    /* ---------- STEP 2: availability ---------- */
    async checkAvailability() {
        const s = sections[this.sectionCode];

        if (!s) {
            this.showAlert('Please select a valid section first.');
            return;
        }

        // Freeze the current draft before checking it. This makes the
        // exact rows used by the checker the source of truth for the next step.
        this.rememberDraft();

        const entries = s.rows.map(r => ({
            subject_code: r.subject,
            teacher: r.teacher || '',
            room: r.room || '',
            day: r.day || '',
            time: r.time || '',
            class_type: r.type || 'Lecture'
        }));

        try {
             const response = await fetch(SMS_BASE + '/api/scheduling/check-availability.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    section_code: this.sectionCode,
                    entries
                })
            });

            const data = await response.json();

            if (!response.ok || !data.ok) {
                throw new Error(data.error || 'Availability check failed.');
            }

            this.results = (data.results || []).map(item => {
                const r = s.rows[item.index] || {
                    subject: item.subject_code || '',
                    teacher: '',
                    room: '',
                    day: '',
                    time: '',
                    type: 'Lecture'
                };

                if (item.result === 'Pending') {
                    return {
                        i: item.index,
                        r,
                        status: 'pending',
                        detail: item.message || 'Teacher, room, day, and time are required.'
                    };
                }

                if (item.result === 'Conflict') {
                    const first = (item.conflicts && item.conflicts[0]) || null;
                    const reasonType = first ? String(first.type || '').toLowerCase() : 'teacher';
                    const status = reasonType === 'room' ? 'room-conflict' : 'conflict';
                    const detail = first ? first.message : (item.message || 'Conflict found.');

                    return {
                        i: item.index,
                        r,
                        status,
                        detail,
                        reasonType
                    };
                }

                return {
                    i: item.index,
                    r,
                    status: 'available',
                    detail: item.message || 'No teacher, room, or section conflict found.'
                };
            });

            this.renderAvailability();
            this.goToStep('availability');

        } catch (error) {
            console.error('Availability API error:', error);
            this.showAlert('Unable to check availability.\n\n' + error.message);
        }
    },

    statusBadge(status) {
        if (status === 'available') return '<span class="badge text-bg-success">Available</span>';
        if (status === 'conflict') return '<span class="badge text-bg-danger">Conflict</span>';
        if (status === 'room-conflict') return '<span class="badge text-bg-warning">Room Unavailable</span>';
        return '<span class="badge text-bg-secondary">Pending</span>';
    },

    renderAvailability() {
        const sub = code => subjectCatalog[code] || { name: code };
        document.getElementById('tsmAvailabilityTableBody').innerHTML = this.results.map((res, idx) => `
            <tr>
                <td>${idx + 1}</td>
                <td><strong>${this.escape(sub(res.r.subject).name)}</strong><br><small class="text-muted">${this.escape(res.r.subject)}</small></td>
                <td>${this.escape(res.r.teacher) || '—'}</td>
                <td>${this.escape(res.r.room) || '—'}</td>
                <td>${res.r.day ? this.escape(res.r.day + ' ' + res.r.time) : '—'}</td>
                <td>${this.statusBadge(res.status)}</td>
                <td class="text-end">${(res.status === 'conflict' || res.status === 'room-conflict') ? `<span class="small text-danger">${this.escape(res.detail)}</span>` : `<span class="small text-muted">${this.escape(res.detail)}</span>`}</td>
            </tr>
        `).join('');

        const available = this.results.filter(r => r.status === 'available').length;
        const conflicts = this.results.filter(r => r.status === 'conflict' || r.status === 'room-conflict').length;
        const pending = this.results.filter(r => r.status === 'pending').length;

        document.getElementById('tsmCountAvailable').textContent = available;
        document.getElementById('tsmCountConflicts').textContent = conflicts;
        document.getElementById('tsmCountPending').textContent = pending;

        const statusText = document.getElementById('tsmOverallStatusText');
        const statusHint = document.getElementById('tsmOverallStatusHint');
        const resolveBtn = document.getElementById('tsmResolveBtn');

        if (conflicts > 0) {
            statusText.textContent = 'Issues Found';
            statusText.className = 'issues';
            statusHint.textContent = 'Please resolve the conflicts below.';
            resolveBtn.innerHTML = 'Resolve Conflicts<i class="fas fa-arrow-right ms-2"></i>';
            resolveBtn.onclick = () => this.goToResolve();
        } else if (pending > 0) {
            statusText.textContent = 'Incomplete Draft';
            statusText.className = 'issues';
            statusHint.textContent = 'Assign a teacher, room, day, and time to every subject.';
            resolveBtn.innerHTML = 'Back to Draft<i class="fas fa-arrow-left ms-2"></i>';
            resolveBtn.onclick = () => this.goToStep('draft');
        } else {
            statusText.textContent = 'All Clear';
            statusText.className = 'ok';
            statusHint.textContent = 'No conflicts found — ready to publish.';
            resolveBtn.innerHTML = 'Proceed to Publish<i class="fas fa-arrow-right ms-2"></i>';
            resolveBtn.onclick = () => this.goToPublish();
        }
    },

    async goToResolve() {
        await this.buildSuggestions();
        this.resolveTab = 'conflicts';
        document.querySelectorAll('#tsmResolveTabs .nav-link').forEach(b => b.classList.toggle('active', b.dataset.tab === 'conflicts'));
        this.renderResolve();
        this.goToStep('resolve');
    },

    /* ---------- STEP 3: resolve ---------- */
    async buildSuggestions() {
        const conflicts = (this.results || [])
            .filter(r => r.status === 'conflict' || r.status === 'room-conflict');

        const suggestions = [];
        const section = sections[this.sectionCode];

        for (const r of conflicts) {
            const baseEntries = (section?.rows || []).map(row => ({
                subject_code: row.subject,
                teacher: row.teacher || '',
                room: row.room || '',
                day: row.day || '',
                time: row.time || '',
                class_type: row.type || 'Lecture'
            }));

            let candidates = [];

            if (r.reasonType === 'teacher') {
                candidates = teachers
                    .filter(t => t && t !== r.r.teacher)
                    .map(t => ({
                        teacher: t,
                        room: r.r.room,
                        day: r.r.day,
                        time: r.r.time
                    }));
            } else {
                // For room conflicts, first try other rooms at the same time,
                // then try other time slots using the current room.
                candidates = rooms
                    .filter(rm => rm && rm !== r.r.room)
                    .map(rm => ({
                        teacher: r.r.teacher,
                        room: rm,
                        day: r.r.day,
                        time: r.r.time
                    }));

                for (const t of timeSlots) {
                    if (t !== r.r.time) {
                        candidates.push({
                            teacher: r.r.teacher,
                            room: r.r.room,
                            day: r.r.day,
                            time: t
                        });
                    }
                }
            }

            let suggested = null;

            for (const candidate of candidates) {
                const trialEntries = baseEntries.map((entry, idx) => {
                    if (idx !== r.i) return entry;
                    return { ...entry, ...candidate };
                });

                try {
                    const response = await fetch(SMS_BASE + '/api/scheduling/check-availability.php', {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({
                            section_code: this.sectionCode,
                            entries: trialEntries
                        })
                    });

                    const data = await response.json();
                    if (!response.ok || !data.ok) continue;

                    // IMPORTANT: evaluate only the row we are trying to fix.
                    // Other rows may still contain unresolved conflicts; those
                    // must not prevent us from finding a valid alternative for
                    // this specific row.
                    const item = (data.results || []).find(x => x.index === r.i);
                    if (item && item.result === 'Available') {
                        const sameAsCurrent =
                            candidate.teacher === r.r.teacher &&
                            candidate.room === r.r.room &&
                            candidate.day === r.r.day &&
                            candidate.time === r.r.time;

                        if (!sameAsCurrent) {
                            suggested = candidate;
                            break;
                        }
                    }
                } catch (error) {
                    console.error('Suggestion availability check failed:', error);
                }
            }

            suggestions.push({
                index: r.i,
                subject: r.r.subject,
                reasonType: r.reasonType,
                detail: r.detail,
                current: { teacher: r.r.teacher, room: r.r.room, day: r.r.day, time: r.r.time },
                suggested,
                resolved: false,
                noSuggestion: !suggested,
            });
        }

        this.suggestions = suggestions;
    },

    switchResolveTab(tab) {
        this.resolveTab = tab;
        document.querySelectorAll('#tsmResolveTabs .nav-link').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
        this.renderResolve();
    },

    renderResolve() {
        const list = this.suggestions || [];
        document.getElementById('tsmConflictsTabCount').textContent = `(${list.filter(x => !x.resolved).length})`;
        document.getElementById('tsmAllTabCount').textContent = `(${list.length})`;

        const shown = this.resolveTab === 'conflicts' ? list.filter(x => !x.resolved) : list;
        const sub = code => subjectCatalog[code] || { name: code };

        document.getElementById('tsmConflictList').innerHTML = shown.map((c) => {
            const realIdx = list.indexOf(c);
            return `
            <div class="tsm-conflict-card ${c.resolved ? 'resolved' : ''}">
                <div class="tsm-conflict-title"><span class="tsm-conflict-badge">${realIdx + 1}</span>${this.escape(sub(c.subject).name)} (${this.escape(c.subject)}) — ${c.reasonType === 'teacher' ? 'Teacher Conflict' : 'Room Conflict'}</div>
                <div class="tsm-conflict-reason">${this.escape(c.detail)}</div>
                <div class="tsm-conflict-compare">
                    <div class="tsm-conflict-box current">
                        <span class="label">Current Draft</span>
                        ${this.escape(c.current.teacher)} | ${this.escape(c.current.day)} ${this.escape(c.current.time)} | ${this.escape(c.current.room)}
                    </div>
                    <i class="fas fa-arrow-right text-muted"></i>
                    <div class="tsm-conflict-box suggested">
                        <span class="label">Suggested Solution</span>
                        ${c.suggested ? `${this.escape(c.suggested.teacher)} | ${this.escape(c.suggested.day)} ${this.escape(c.suggested.time)} | ${this.escape(c.suggested.room)}` : '<span class="text-danger">No safe alternative found</span>'}
                    </div>
                    <button type="button" class="btn btn-sms-primary btn-sm" ${c.resolved || c.noSuggestion ? 'disabled' : ''} onclick="TSM.applySuggestion(${realIdx})">
                        ${c.resolved ? '<i class="fas fa-check me-1"></i>Applied' : (c.noSuggestion ? 'No Alternative' : 'Apply')}
                    </button>
                </div>
            </div>`;
        }).join('') || `<div class="text-center text-muted py-4"><i class="fas fa-circle-check fa-2x text-success mb-2 d-block"></i>No conflicts left to resolve.</div>`;
    },

    applySuggestion(idx) {
        const c = this.suggestions[idx];
        if (!c || c.resolved || !c.suggested) return;
        const rowRef = sections[this.sectionCode].rows[c.index];
        rowRef.teacher = c.suggested.teacher;
        rowRef.room = c.suggested.room;
        rowRef.day = c.suggested.day;
        rowRef.time = c.suggested.time;

        // Persist the suggestion in the client-side draft immediately.
        // The Availability step must use these updated values on re-check.
        this.rememberDraft();

        // Keep the in-memory result row synchronized as well.
        const resultRef = (this.results || []).find(r => r.i === c.index);
        if (resultRef) resultRef.r = { ...rowRef };

        c.current = { ...c.suggested };
        c.resolved = true;
        this.renderResolve();
        this.showAlert('Suggestion applied to the draft.');
    },

    autoOptimize() {
        (this.suggestions || []).forEach((c, idx) => { if (!c.resolved) this.applySuggestion(idx); });
        this.showAlert('Auto Optimize applied all suggested fixes.');
    },

    async applyAllAndUpdate() {
        this.autoOptimize();
        this.rememberDraft();
        this.renderDraftTable();

        // Re-check only after all suggestions have been applied.
        await this.checkAvailability();

        const conflicts = (this.results || [])
            .filter(r => r.status === 'conflict' || r.status === 'room-conflict').length;
        const pending = (this.results || [])
            .filter(r => r.status === 'pending').length;

        if (conflicts > 0) {
            // Stay in Resolve Conflicts rather than looping back to Availability.
            await this.goToResolve();
            return;
        }

        if (pending > 0) {
            this.goToStep('draft');
            return;
        }

        this.goToPublish();
    },

    /* ---------- STEP 4: publish ---------- */
    goToPublish() {
        this.publishTab = 'section';
        document.querySelectorAll('#tsmPublishTabs .nav-link').forEach(b => b.classList.toggle('active', b.dataset.tab === 'section'));
        this.renderPublish();
        this.goToStep('publish');
    },

    switchPublishTab(tab) {
        this.publishTab = tab;
        document.querySelectorAll('#tsmPublishTabs .nav-link').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
        this.renderPublish();
    },

    renderPublish() {
        const s = sections[this.sectionCode];
        const rows = s.rows;
        const body = document.getElementById('tsmPublishBody');

        if (this.publishTab === 'section') {
            body.innerHTML = this.buildTimetableGrid(
                `${this.sectionCode} — Section Timetable`,
                rows.filter(r => r.day && r.time).map(r => ({ day: r.day, time: r.time, main: r.subject, meta: `${r.room} · ${r.teacher}` }))
            );
        } else if (this.publishTab === 'teacher') {
            const byTeacher = {};
            rows.filter(r => r.teacher && r.day).forEach(r => { (byTeacher[r.teacher] = byTeacher[r.teacher] || []).push(r); });
            body.innerHTML = Object.keys(byTeacher).length
                ? Object.keys(byTeacher).map(t => this.buildTimetableGrid(t, byTeacher[t].map(r => ({ day: r.day, time: r.time, main: r.subject, meta: r.room })))).join('<hr class="my-4">')
                : `<p class="text-muted text-center py-4 mb-0">No teachers assigned yet.</p>`;
        } else if (this.publishTab === 'room') {
            const byRoom = {};
            rows.filter(r => r.room && r.day).forEach(r => { (byRoom[r.room] = byRoom[r.room] || []).push(r); });
            body.innerHTML = Object.keys(byRoom).length
                ? Object.keys(byRoom).map(rm => this.buildTimetableGrid(rm, byRoom[rm].map(r => ({ day: r.day, time: r.time, main: r.subject, meta: r.teacher })))).join('<hr class="my-4">')
                : `<p class="text-muted text-center py-4 mb-0">No rooms assigned yet.</p>`;
        } else if (this.publishTab === 'exam') {
            body.innerHTML = `<div class="text-center py-5">
                <i class="fas fa-file-pen fa-2x mb-3 d-block text-muted"></i>
                <p class="text-muted mb-1">Examinations are created in a separate module.</p>
                <p class="text-muted small mb-3">Once this section's classes are published, the Exam Timetable
                Generator can create one examination per subject and schedule them, either by hand or with
                Google OR-Tools.</p>
                <a class="btn btn-outline-primary btn-sm" href="${SMS_BASE}/modules/scheduling/pages/exam-timetable-generator.php">
                    <i class="fas fa-arrow-right me-1"></i>Open Exam Timetable Generator
                </a>
            </div>`;
        } else {
            /*
             * Published entries are read by the Calendar Integration module,
             * which presents them in month view and exports them as an
             * iCalendar (.ics) file. There is no separate synchronisation step:
             * publishing is what makes a timetable visible to the calendar.
             */
            const published = rows.filter(r => r.teacher && r.room && r.day && r.time).length;

            body.innerHTML = `<div class="text-center py-5">
                <i class="fas fa-calendar-days fa-2x mb-3 d-block text-muted"></i>
                <p class="text-muted mb-1">${published} entr${published === 1 ? 'y' : 'ies'} in this section
                will appear on the calendar once published.</p>
                <p class="text-muted small mb-3">Calendar Integration presents every published class, special
                session and examination in month view, and exports them as an iCalendar (.ics) file for
                Google Calendar, Outlook or Apple Calendar. Publishing is the only step required &mdash;
                no separate synchronisation is needed.</p>
                <a class="btn btn-outline-primary btn-sm" href="${SMS_BASE}/modules/scheduling/pages/calendar-integration.php">
                    <i class="fas fa-arrow-right me-1"></i>Open Calendar Integration
                </a>
            </div>`;
        }
    },

    buildTimetableGrid(title, entries) {
        const usedTimes = [...new Set(entries.map(e => e.time))];
        const timeRows = usedTimes.length ? usedTimes.sort() : timeSlots;

        let html = `<h6 class="fw-semibold mb-2">${this.escape(title)}</h6>`;
        html += `<div class="table-responsive"><table class="tsm-timetable"><thead><tr><th>Time</th>${days.map(d => `<th>${d}</th>`).join('')}</tr></thead><tbody>`;
        timeRows.forEach(t => {
            html += `<tr><td class="time-col">${this.escape(t)}</td>`;
            days.forEach(d => {
                const e = entries.find(x => x.day === d && x.time === t);
                if (e) {
                    const name = subjectCatalog[e.main] ? subjectCatalog[e.main].name : e.main;
                    html += `<td><span class="tsm-cell-subject">${this.escape(e.main)}</span><span class="tsm-cell-meta">${this.escape(name)}</span><span class="tsm-cell-meta">${this.escape(e.meta)}</span></td>`;
                } else {
                    html += `<td class="tsm-cell-empty text-center">-</td>`;
                }
            });
            html += `</tr>`;
        });
        html += `</tbody></table></div>`;
        return html;
    },

    async saveSchedule() {
        const s = sections[this.sectionCode];
        if (!s) {
            this.showAlert('Please select a valid section first.');
            return;
        }

        const entries = s.rows.map(r => ({
            subject_code: r.subject,
            teacher: r.teacher || '',
            room: r.room || '',
            day: r.day || '',
            time: r.time || '',
            class_type: r.type || 'Lecture'
        }));

        try {
        const response = await fetch(SMS_BASE + '/api/scheduling/save-schedule.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({
                    section_code: this.sectionCode,
                    entries
                })
            });

            const data = await response.json();

            if (!response.ok || !data.ok) {
             throw new Error(data.details || data.error || 'Schedule could not be saved.');
            }

            this.scheduleSaved = true;
            const publishBtn = document.getElementById('tsmPublishBtn');
            if (publishBtn) publishBtn.disabled = false;

            this.showAlert(`Schedule saved successfully (${data.saved_count} entries).`);

        } catch (error) {
            console.error('Save Schedule API error:', error);
            this.showAlert('Unable to save schedule.\n\n' + error.message);
        }
    },

    async publish() {
        if (!this.scheduleSaved) {
            this.showAlert('Please save the schedule before publishing it.');
            return;
        }

        const sectionCode = this.sectionCode;

        if (!sectionCode) {
            this.showAlert('Please select a section before publishing.');
            return;
        }

        const publishBtn = document.getElementById('tsmPublishBtn');
        if (publishBtn) {
            publishBtn.disabled = true;
            publishBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Publishing...';
        }

        try {
          const response = await fetch(SMS_BASE + '/api/scheduling/publish-schedule.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ section_code: sectionCode })
            });

            const data = await response.json();

            if (!response.ok || !data.ok) {
                throw new Error(data.details || data.error || 'Schedule could not be published.');
            }

            document.getElementById('tsmPublishedBadge')?.classList.remove('d-none');

            const headline = document.getElementById('tsmPublishHeadline');
            if (headline) headline.textContent = 'Schedule Published Successfully!';

            const sub = document.getElementById('tsmPublishSub');
            if (sub) sub.textContent = `${data.published_count} schedule entries are now published.`;

            this.showAlert(`Schedule published successfully (${data.published_count} entries).`);

            // Refresh the selected section from the API so the published rows are current.
            try {
                await loadTeacherScheduleFromAPI(sectionCode);
                delete this.unsavedDrafts[sectionCode];
                this.renderDraftTable();
            } catch (refreshError) {
                console.warn('Published successfully, but refresh failed:', refreshError);
            }

        } catch (error) {
            console.error('Publish Schedule API error:', error);
            this.showAlert('Unable to publish schedule.\n\n' + error.message);

        } finally {
            if (publishBtn) {
                publishBtn.disabled = false;
                publishBtn.innerHTML = '<i class="fas fa-calendar-check me-2"></i>Publish Schedule';
            }
        }
    },
};

window.TSM = TSM;

document.addEventListener('DOMContentLoaded', async () => {
    try {
        await loadTeacherScheduleFromAPI(INITIAL_SECTION);
        TSM.initSectionSelect();
        TSM.goToStep('draft');
        console.log('Teacher Schedule Mapping loaded from MySQL successfully.');
    } catch (error) {
        console.error('Teacher Schedule Mapping API error:', error);
        alert('Unable to load scheduling data.\n\n' + error.message);
    }
});
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
