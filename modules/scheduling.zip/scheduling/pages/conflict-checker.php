<?php
/**
 * SMS 2 - Automated Conflict Checker
 * Module: Class Scheduling  (Phase 4)
 *
 * Validates schedules already stored in the database and records the
 * findings in conflict_results.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Conflict Checker';
$activeModule = 'scheduling';
$activePage   = 'conflict-checker';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Conflict Checker', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
    .cc-term-badge {
        background: #eef4fb; border: 1px solid #d6e4f5;
        color: var(--sms-primary, #1F4E79);
        border-radius: 999px; padding: .45rem 1rem;
        font-size: .85rem; font-weight: 600; white-space: nowrap;
    }
    .cc-stat { border-radius: .6rem; border: 1px solid #e6e9ef; padding: 1rem; text-align: center; height: 100%; }
    .cc-stat .cc-stat-value { font-size: 1.9rem; font-weight: 700; line-height: 1; }
    .cc-stat .cc-stat-label {
        font-size: .72rem; letter-spacing: .06em; text-transform: uppercase;
        color: #6c757d; margin-top: .35rem;
    }
    .cc-stat.is-error   { background: #fdf3f3; border-color: #f3d4d4; }
    .cc-stat.is-error   .cc-stat-value { color: #b53d3d; }
    .cc-stat.is-warning { background: #fff9ee; border-color: #f2e2c4; }
    .cc-stat.is-warning .cc-stat-value { color: #b26a00; }
    .cc-stat.is-clean   { background: #f2fbf5; border-color: #cdeed9; }
    .cc-stat.is-clean   .cc-stat-value { color: #1e7e42; }
    .cc-stat.is-total   { background: #f4f7fb; border-color: #dbe5f1; }
    .cc-stat.is-total   .cc-stat-value { color: var(--sms-primary, #1F4E79); }

    .cc-badge { font-size: .72rem; font-weight: 600; padding: .3rem .6rem; border-radius: 999px; white-space: nowrap; }
    .cc-badge.type-Teacher      { background: #e4ecfa; color: #26497f; }
    .cc-badge.type-Room         { background: #fae4e4; color: #99372f; }
    .cc-badge.type-Section      { background: #ede4fa; color: #5b3d8f; }
    .cc-badge.type-Availability { background: #fde8d5; color: #8a4b00; }
    .cc-badge.type-Capacity     { background: #fff3cd; color: #7a5b00; }
    .cc-badge.sev-Error   { background: #fadede; color: #b53d3d; }
    .cc-badge.sev-Warning { background: #fdf0d5; color: #8a5b00; }
    .cc-badge.sev-Info    { background: #e4ecfa; color: #26497f; }
    .cc-badge.resolved    { background: #d9f2e3; color: #1e7e42; }

    .cc-action-text { font-size: .8rem; color: #5a6169; font-style: italic; }
    .cc-empty { padding: 2.5rem 1rem; text-align: center; color: #6c757d; }
    .cc-clean { padding: 2.5rem 1rem; text-align: center; color: #1e7e42; }
    .cc-row-resolved { opacity: .55; }
    .cc-scope-card { cursor: pointer; transition: border-color .15s ease, box-shadow .15s ease; }
    .cc-scope-card.active { border-color: var(--sms-primary, #1F4E79); box-shadow: 0 0 0 2px rgba(31,78,121,.12); }
    .cc-run-meta { font-size: .78rem; color: #6c757d; }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-shield-halved text-sms-primary me-2"></i>Automated Conflict Checker</h1>
        <p>Validate saved schedules against teacher, room, section, load, and capacity rules.</p>
    </div>
    <div class="cc-term-badge">
        <i class="fas fa-calendar-alt me-2"></i>
        <span>SY 2026-2027 &middot; 1st Semester</span>
    </div>
</div>

<div id="ccAlert" class="alert submodule-alert d-none" role="alert">
    <i class="fas fa-circle-info me-2"></i><span id="ccAlertText"></span>
</div>

<!-- ================= Scope ================= -->
<div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-3">
            <i class="fas fa-crosshairs text-sms-primary me-2"></i>Validation Scope
        </h5>

        <div class="row g-3">
            <div class="col-md-6">
                <div class="card h-100 cc-scope-card active" id="ccScopeAll" data-scope="all">
                    <div class="card-body d-flex align-items-center gap-3">
                        <div class="sat-choice-icon primary"><i class="fas fa-layer-group"></i></div>
                        <div>
                            <h6 class="mb-1 fw-semibold">All Sections</h6>
                            <p class="text-muted mb-0 small">Check every saved schedule in the system.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card h-100 cc-scope-card" id="ccScopeSection" data-scope="section">
                    <div class="card-body d-flex align-items-center gap-3">
                        <div class="sat-choice-icon success"><i class="fas fa-list-ul"></i></div>
                        <div class="flex-grow-1">
                            <h6 class="mb-1 fw-semibold">One Section</h6>
                            <select class="form-select form-select-sm mt-1" id="ccSectionSelect" disabled>
                                <option value="">Loading sections...</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3">
            <small class="text-muted">
                <i class="fas fa-circle-info me-1"></i>
                Checks Draft, Validated, and Published entries. Cancelled entries are ignored.
            </small>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-secondary" id="ccClearBtn">
                    <i class="fas fa-trash-can me-1"></i> Clear History
                </button>
                <button type="button" class="btn btn-primary" id="ccRunBtn">
                    <i class="fas fa-play me-1"></i> Run Conflict Check
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ================= Summary ================= -->
<div class="row g-3 mb-3 d-none" id="ccSummaryRow">
    <div class="col-6 col-lg-3">
        <div class="cc-stat is-error">
            <div class="cc-stat-value" id="ccStatErrors">0</div>
            <div class="cc-stat-label">Errors</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="cc-stat is-warning">
            <div class="cc-stat-value" id="ccStatWarnings">0</div>
            <div class="cc-stat-label">Warnings</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="cc-stat is-clean">
            <div class="cc-stat-value" id="ccStatScanned">0</div>
            <div class="cc-stat-label">Entries Checked</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="cc-stat is-total">
            <div class="cc-stat-value" id="ccStatTotal">0</div>
            <div class="cc-stat-label">Total Findings</div>
        </div>
    </div>
</div>

<!-- ================= Findings ================= -->
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="card-title fw-semibold mb-0">
                <i class="fas fa-triangle-exclamation text-sms-primary me-2"></i>Conflict Findings
            </h5>
            <span class="cc-run-meta" id="ccRunLabel"></span>
        </div>

        <div class="table-responsive">
            <table class="table submodule-table align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width:55px;">No.</th>
                        <th style="width:120px;">Type</th>
                        <th style="width:100px;">Severity</th>
                        <th style="width:150px;">Day &amp; Time</th>
                        <th>Finding</th>
                        <th style="width:110px;" class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody id="ccTableBody">
                    <tr>
                        <td colspan="6">
                            <div class="cc-empty">
                                <i class="fas fa-shield-halved fa-2x mb-2 d-block opacity-50"></i>
                                Select a scope and click <strong>Run Conflict Check</strong>.
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    const SMS_BASE = '<?= BASE_URL ?>';
    const CC_API   = SMS_BASE + '/api/scheduling/conflict-check.php';

    let currentScope = 'all';

    const $ = (id) => document.getElementById(id);

    function escapeHtml(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function showAlert(message, kind) {
        const box = $('ccAlert');
        box.className = 'alert submodule-alert alert-' + (kind || 'info');
        $('ccAlertText').textContent = message;
        box.classList.remove('d-none');
    }

    function hideAlert() { $('ccAlert').classList.add('d-none'); }

    async function request(url, options) {
        const response = await fetch(url, Object.assign({
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' }
        }, options || {}));
        const data = await response.json();
        if (!response.ok || !data.ok) {
            throw new Error(data.error || 'Request failed.');
        }
        return data;
    }

    /* ---------- scope selection ---------- */
    function setScope(scope) {
        currentScope = scope;
        $('ccScopeAll').classList.toggle('active', scope === 'all');
        $('ccScopeSection').classList.toggle('active', scope === 'section');
        $('ccSectionSelect').disabled = (scope !== 'section');
    }

    /* ---------- load sections ---------- */
    async function loadOptions() {
        try {
            const data = await request(CC_API + '?action=options', { method: 'GET' });
            const select = $('ccSectionSelect');
            select.innerHTML = '';

            const sections = data.sections || [];
            if (sections.length === 0) {
                select.innerHTML = '<option value="">No active sections</option>';
            } else {
                sections.forEach(section => {
                    const option = document.createElement('option');
                    option.value = section.code;
                    option.textContent = section.code + ' \u2014 ' + section.name +
                        '  (' + section.entry_count + ' entries)';
                    select.appendChild(option);
                });
            }
            console.log('Conflict Checker options:', data);
            await loadLatest();
        } catch (error) {
            showAlert('Could not load sections. ' + error.message, 'danger');
            console.error(error);
        }
    }

    /* ---------- show the last stored run ---------- */
    async function loadLatest() {
        try {
            const data = await request(CC_API + '?action=latest', { method: 'GET' });
            if (!data.run_id) { return; }
            renderFindings(data.findings, data.run_id, null);
            $('ccStatErrors').textContent   = data.summary.errors;
            $('ccStatWarnings').textContent = data.summary.warnings;
            $('ccStatTotal').textContent    = data.summary.total;
            $('ccStatScanned').textContent  = '\u2014';
            $('ccSummaryRow').classList.remove('d-none');
        } catch (error) {
            console.error(error);
        }
    }

    /* ---------- run the check ---------- */
    async function runCheck() {
        hideAlert();

        const body = { action: 'run', scope: currentScope };
        if (currentScope === 'section') {
            const code = $('ccSectionSelect').value;
            if (!code) {
                showAlert('Please select a section first.', 'danger');
                return;
            }
            body.section_code = code;
        }

        const button = $('ccRunBtn');
        const original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Checking...';

        try {
            const data = await request(CC_API, {
                method: 'POST',
                body: JSON.stringify(body)
            });

            $('ccStatErrors').textContent   = data.summary.errors;
            $('ccStatWarnings').textContent = data.summary.warnings;
            $('ccStatTotal').textContent    = data.summary.total;
            $('ccStatScanned').textContent  = data.scanned;
            $('ccSummaryRow').classList.remove('d-none');

            showAlert(data.message, data.summary.total === 0 ? 'success' : 'warning');

            const detail = await request(CC_API + '?action=latest', { method: 'GET' });
            renderFindings(detail.findings, data.run_id, data.scanned);

            console.log('Conflict check result:', data);
        } catch (error) {
            showAlert(error.message, 'danger');
            console.error(error);
        } finally {
            button.disabled = false;
            button.innerHTML = original;
        }
    }

    /* ---------- render ---------- */
    /*
     * Builds the deep link used by the Fix button.
     *
     * Returns an empty string when a finding cannot be traced to one editable
     * row — a teacher load finding, for example, concerns a teacher's whole
     * timetable rather than a single entry, so no single destination exists.
     */
    function buildFixUrl(finding) {
        if (!finding.section_code || !finding.day_of_week) {
            return '';
        }

        const params = new URLSearchParams({
            section: finding.section_code,
            day: finding.day_of_week,
            start: String(finding.start_time || '').substring(0, 5),
            cid: String(finding.id)
        });

        return SMS_BASE + '/modules/scheduling/pages/teacher-schedule-mapping.php?' +
               params.toString();
    }

    function renderFindings(findings, runId, scanned) {
        $('ccRunLabel').textContent = runId ? ('Run ' + runId) : '';
        const body = $('ccTableBody');

        if (!findings || findings.length === 0) {
            body.innerHTML = '<tr><td colspan="6"><div class="cc-clean">' +
                '<i class="fas fa-circle-check fa-2x mb-2 d-block"></i>' +
                '<strong>No conflicts found.</strong><br>' +
                '<span class="text-muted small">All checked schedule entries satisfy the validation rules.</span>' +
                '</div></td></tr>';
            return;
        }

        body.innerHTML = findings.map((finding, index) => {
            const resolved = Number(finding.is_resolved) === 1;

            let when = '<span class="text-muted small">\u2014</span>';
            if (finding.day_of_week) {
                when = escapeHtml(finding.day_of_week) + '<br><span class="text-muted small">' +
                    escapeHtml(String(finding.start_time || '').substring(0, 5)) + ' - ' +
                    escapeHtml(String(finding.end_time || '').substring(0, 5)) + '</span>';
            }

            /*
             * Direct resolution. Teacher, Room, Section and Capacity findings all
             * originate from a schedule entry, which is edited in Teacher Schedule
             * Mapping. The section, day and start time are enough to open that page
             * on the exact row, so no new columns are needed.
             */
            const fixUrl = buildFixUrl(finding);

            const fixButton = fixUrl
                ? '<a class="btn btn-sm btn-primary me-1" href="' + fixUrl + '">' +
                  '<i class="fas fa-wrench me-1"></i>Fix</a>'
                : '';

            const actionCell = resolved
                ? '<span class="cc-badge resolved"><i class="fas fa-check me-1"></i>Resolved</span>'
                : fixButton +
                  '<button type="button" class="btn btn-sm btn-outline-success" ' +
                  'onclick="CCResolve(' + Number(finding.id) + ')">' +
                  '<i class="fas fa-check me-1"></i>Resolve</button>';

            return '<tr class="' + (resolved ? 'cc-row-resolved' : '') + '">' +
                '<td>' + (index + 1) + '</td>' +
                '<td><span class="cc-badge type-' + escapeHtml(finding.conflict_type) + '">' +
                    escapeHtml(finding.conflict_type) + '</span></td>' +
                '<td><span class="cc-badge sev-' + escapeHtml(finding.severity) + '">' +
                    escapeHtml(finding.severity) + '</span></td>' +
                '<td>' + when + '</td>' +
                '<td>' + escapeHtml(finding.message) +
                    (finding.recommended_action
                        ? '<div class="cc-action-text"><i class="fas fa-lightbulb me-1"></i>' +
                          escapeHtml(finding.recommended_action) + '</div>'
                        : '') +
                '</td>' +
                '<td class="text-end">' + actionCell + '</td>' +
                '</tr>';
        }).join('');
    }

    /* ---------- resolve / clear ---------- */
    window.CCResolve = async function (id) {
        try {
            await request(CC_API, {
                method: 'POST',
                body: JSON.stringify({ action: 'resolve', id: id })
            });
            const detail = await request(CC_API + '?action=latest', { method: 'GET' });
            renderFindings(detail.findings, detail.run_id, null);
            $('ccStatErrors').textContent   = detail.summary.errors;
            $('ccStatWarnings').textContent = detail.summary.warnings;
            $('ccStatTotal').textContent    = detail.summary.total;
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    };

    async function clearHistory() {
        if (!window.confirm('Delete all stored conflict findings? Schedules are not affected.')) {
            return;
        }
        try {
            const data = await request(CC_API, {
                method: 'POST',
                body: JSON.stringify({ action: 'clear' })
            });
            showAlert(data.message, 'success');
            $('ccSummaryRow').classList.add('d-none');
            $('ccRunLabel').textContent = '';
            $('ccTableBody').innerHTML =
                '<tr><td colspan="6"><div class="cc-empty">' +
                '<i class="fas fa-shield-halved fa-2x mb-2 d-block opacity-50"></i>' +
                'Select a scope and click <strong>Run Conflict Check</strong>.' +
                '</div></td></tr>';
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        $('ccScopeAll').addEventListener('click', () => setScope('all'));
        $('ccScopeSection').addEventListener('click', () => setScope('section'));
        $('ccRunBtn').addEventListener('click', runCheck);
        $('ccClearBtn').addEventListener('click', clearHistory);
        setScope('all');
        loadOptions();
    });
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
