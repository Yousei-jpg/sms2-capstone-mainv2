<?php
/**
 * SMS 2 - Section Assignment Tool
 * Module: Class Scheduling
 *
 * Front-end wizard implementing the flow:
 *   1. Open Section Assignment  (create new OR select existing)
 *   2. Section Information      (create)   / Select Existing Section (existing)
 *   3. Assign Subjects          (create)   / Section Details         (existing)
 *   4. Review & Validate        (create only)
 *   5. Save Section Assignment  (create only)
 *   6. Proceed to Next Module   (Teacher Schedule Mapping)
 *
 * Backend note: sections and subjects are loaded and saved through the scheduling API.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Section Assignment Tool';
$activeModule = 'scheduling';
$activePage   = 'section-assignment-tool';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Section Assignment Tool', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-layer-group text-sms-primary me-2"></i>Section Assignment Tool</h1>
        <p>Select or create the record that belongs to this page.</p>
    </div>
    <div class="sat-term-badge">
        <i class="fas fa-calendar-alt me-2"></i>
        <span id="satTermBadge">SY 2026-2027 &middot; 1st Semester</span>
    </div>
</div>

<!-- ================= Stepper ================= -->
<div class="card mb-3">
    <div class="card-body py-3">
        <ol class="sat-stepper" id="satStepper">
            <li data-step="1"><span class="sat-step-dot"><i class="fas fa-folder-open"></i></span><div><strong>Open Section Assignment</strong><small>Select or create a record</small></div></li>
            <li data-step="2"><span class="sat-step-dot"><i class="fas fa-clipboard-list"></i></span><div><strong>Section Information</strong><small>Basic section details</small></div></li>
            <li data-step="3"><span class="sat-step-dot"><i class="fas fa-book"></i></span><div><strong>Assign Subjects</strong><small>Subjects the section will take</small></div></li>
            <li data-step="4"><span class="sat-step-dot"><i class="fas fa-shield-halved"></i></span><div><strong>Review &amp; Validate</strong><small>Check before saving</small></div></li>
            <li data-step="5"><span class="sat-step-dot"><i class="fas fa-floppy-disk"></i></span><div><strong>Save Section</strong><small>Confirm &amp; store</small></div></li>
            <li data-step="6"><span class="sat-step-dot"><i class="fas fa-user-group"></i></span><div><strong>Next Module</strong><small>Teacher scheduling mapping</small></div></li>
        </ol>
    </div>
</div>

<div id="satAlert" class="alert alert-success submodule-alert d-none" role="alert">
    <i class="fas fa-check-circle me-2"></i><span id="satAlertText"></span>
</div>

<!-- ================= STEP 1: Open Section Assignment ================= -->
<section class="sat-step" id="sat-step-open">
    <div class="row g-3 mb-1">
        <div class="col-md-6">
            <div class="card hover-card sat-choice-card h-100" onclick="SAT.startSelectExisting()">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="sat-choice-icon primary"><i class="fas fa-folder-open"></i></div>
                    <div>
                        <h6 class="mb-1 fw-semibold">Select Existing Section</h6>
                        <p class="text-muted mb-0 small">Search and select a section that has already been created.</p>
                    </div>
                    <i class="fas fa-chevron-right ms-auto text-muted"></i>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card hover-card sat-choice-card h-100" onclick="SAT.startCreateNew()">
                <div class="card-body d-flex align-items-center gap-3">
                    <div class="sat-choice-icon success"><i class="fas fa-plus"></i></div>
                    <div>
                        <h6 class="mb-1 fw-semibold">Create New Section</h6>
                        <p class="text-muted mb-0 small">Create a new section and assign subjects.</p>
                    </div>
                    <i class="fas fa-chevron-right ms-auto text-muted"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-3"><i class="fas fa-clock-rotate-left text-sms-primary me-2"></i>Recently Created / Updated Sections</h5>
            <div class="table-responsive">
                <table class="table submodule-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Section Code</th>
                            <th>Section Name</th>
                            <th>Program</th>
                            <th>Year Level</th>
                            <th>Semester</th>
                            <th>Students</th>
                            <th>Status</th>
                            <th>Last Updated</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody id="satRecentTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<!-- ================= STEP 2a: Select Existing Section ================= -->
<section class="sat-step d-none" id="sat-step-select">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                    <h5 class="card-title fw-semibold mb-1"><i class="fas fa-magnifying-glass text-sms-primary me-2"></i>Select Existing Section</h5>
                    <p class="text-muted small mb-0">Search and select the section you want to open.</p>
                </div>
                <button type="button" class="btn btn-outline-secondary btn-sm" onclick="SAT.goToStep('open')"><i class="fas fa-arrow-left me-1"></i>Back</button>
            </div>

            <div class="input-group mb-3">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
                <input type="text" class="form-control" id="satSearchInput" placeholder="Search by Section Code, Section Name, or Advisor...">
            </div>

            <div class="row g-3 align-items-end mb-3">
                <div class="col-6 col-md-3">
                    <label class="form-label fw-semibold small">Program</label>
                    <select class="form-select" id="satFilterProgram">
                        <option value="">All Programs</option>
                        <option value="BSIT">BSIT</option>
                        <option value="BSCS">BSCS</option>
                        <option value="BIT">BIT</option>
                    </select>
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label fw-semibold small">Year Level</label>
                    <select class="form-select" id="satFilterYear">
                        <option value="">All Years</option>
                        <option>1st Year</option>
                        <option>2nd Year</option>
                        <option>3rd Year</option>
                        <option>4th Year</option>
                    </select>
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label fw-semibold small">Semester</label>
                    <select class="form-select" id="satFilterSemester">
                        <option value="">All Semesters</option>
                        <option>1st Semester</option>
                        <option>2nd Semester</option>
                    </select>
                </div>
                <div class="col-6 col-md-3">
                    <label class="form-label fw-semibold small">Academic Year</label>
                    <select class="form-select" id="satFilterAY">
                        <option value="">All A.Y.</option>
                        <option>2026-2027</option>
                        <option>2025-2026</option>
                    </select>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table submodule-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th>Section Code</th>
                            <th>Section Name</th>
                            <th>Program</th>
                            <th>Year Level</th>
                            <th>Semester</th>
                            <th>Students</th>
                            <th>Status</th>
                            <th class="text-end">Action</th>
                        </tr>
                    </thead>
                    <tbody id="satSelectTableBody"></tbody>
                </table>
            </div>
            <div class="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-2">
                <small class="text-muted" id="satSelectCount"></small>
                <nav><ul class="pagination pagination-sm mb-0" id="satSelectPagination"></ul></nav>
            </div>
        </div>
    </div>
</section>

<!-- ================= STEP 2b: Section Details (view existing) ================= -->
<section class="sat-step d-none" id="sat-step-details">
    <div class="row g-3">
        <div class="col-lg-6">
            <div class="card h-100">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3"><i class="fas fa-circle-info text-sms-primary me-2"></i>Section Information</h5>
                    <div class="student-detail-list" id="satDetailsInfo"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3 d-flex justify-content-between">
                        <span><i class="fas fa-book text-sms-primary me-2"></i>Assigned Subjects</span>
                        <span class="badge bg-primary-subtle text-primary" id="satDetailsSubjectCount"></span>
                    </h5>
                    <div class="table-responsive">
                        <table class="table submodule-table align-middle mb-0">
                            <thead><tr><th>#</th><th>Code</th><th>Subject Name</th><th>Units</th><th>Type</th></tr></thead>
                            <tbody id="satDetailsSubjects"></tbody>
                            <tfoot>
                                <tr><td colspan="3" class="text-end fw-semibold">Total Units</td><td class="fw-bold" colspan="2" id="satDetailsTotalUnits"></td></tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title fw-semibold mb-3"><i class="fas fa-users text-sms-primary me-2"></i>Students Summary</h5>
                    <div class="row text-center g-2">
                        <div class="col-4">
                            <div class="sat-mini-stat"><i class="fas fa-user-graduate text-sms-primary"></i><strong id="satDetailsMax"></strong><span>Maximum</span></div>
                        </div>
                        <div class="col-4">
                            <div class="sat-mini-stat"><i class="fas fa-user-check text-sms-primary"></i><strong id="satDetailsCurrent"></strong><span>Current</span></div>
                        </div>
                        <div class="col-4">
                            <div class="sat-mini-stat"><i class="fas fa-user-plus text-sms-primary"></i><strong id="satDetailsAvailable"></strong><span>Available</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="SAT.goToStep('select')"><i class="fas fa-arrow-left me-2"></i>Back to List</button>
        <button type="button" class="btn btn-outline-primary" id="satEditSectionBtn"><i class="fas fa-pen me-2"></i>Edit Section</button>
        <button type="button" class="btn btn-sms-primary ms-auto" id="satContinueTeacherBtn">Continue to Teacher Mapping<i class="fas fa-arrow-right ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 2c: Section Information (create/edit form) ================= -->
<section class="sat-step d-none" id="sat-step-form">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-3"><i class="fas fa-clipboard-list text-sms-primary me-2"></i><span id="satFormTitle">Section Information</span></h5>
            <form id="satSectionForm" novalidate>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Section Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="satFieldName" placeholder="e.g. BSIT 3C" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Section Code <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="satFieldCode" placeholder="e.g. BSIT-3C" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Program / Course <span class="text-danger">*</span></label>
                        <select class="form-select" id="satFieldProgram" required>
                            <option value="">Select program...</option>
                            <option value="BSIT">Bachelor of Science in Information Technology (BSIT)</option>
                            <option value="BSCS">Bachelor of Science in Computer Science (BSCS)</option>
                            <option value="BIT">Bachelor in Industrial Technology (BIT)</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Year Level <span class="text-danger">*</span></label>
                        <select class="form-select" id="satFieldYear" required>
                            <option value="">Select year level...</option>
                            <option>1st Year</option>
                            <option>2nd Year</option>
                            <option>3rd Year</option>
                            <option>4th Year</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Semester <span class="text-danger">*</span></label>
                        <select class="form-select" id="satFieldSemester" required>
                            <option>1st Semester</option>
                            <option>2nd Semester</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Academic Year <span class="text-danger">*</span></label>
                        <select class="form-select" id="satFieldAY" required>
                            <option>2026-2027</option>
                            <option>2025-2026</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Maximum Students <span class="text-danger">*</span></label>
                        <input type="number" min="1" max="80" class="form-control" id="satFieldMax" placeholder="e.g. 45" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Advisor</label>
                        <input type="text" class="form-control" id="satFieldAdvisor" placeholder="e.g. Prof. Maria Santos">
                    </div>
                    <div class="col-12">
                        <div class="alert alert-primary bg-primary-subtle border-0 small mb-0">
                            <i class="fas fa-circle-info me-2"></i>Maximum students will be used to validate room capacity and generate schedule.
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="SAT.cancelForm()"><i class="fas fa-xmark me-2"></i>Cancel</button>
        <button type="button" class="btn btn-sms-primary ms-auto" onclick="SAT.submitSectionForm()">Next: Assign Subjects<i class="fas fa-arrow-right ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 3: Assign Subjects to Section ================= -->
<section class="sat-step d-none" id="sat-step-subjects">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-2">
                <h5 class="card-title fw-semibold mb-0"><i class="fas fa-book text-sms-primary me-2"></i>Assign Subjects to Section</h5>
                <span class="badge bg-primary-subtle text-primary" id="satSubjectsSectionBadge"></span>
            </div>
            <p class="text-muted small mb-3" id="satSubjectsMeta"></p>

            <div class="table-responsive">
                <table class="table submodule-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th style="width:36px">#</th>
                            <th>Subject Code</th>
                            <th>Subject Name</th>
                            <th>Units</th>
                            <th>Type</th>
                            <th class="text-center" style="width:70px">Select</th>
                        </tr>
                    </thead>
                    <tbody id="satSubjectsTableBody"></tbody>
                </table>
            </div>
            <div class="d-flex justify-content-end gap-4 mt-3 pt-3 border-top">
                <div><span class="text-muted small">Total Subjects</span> <strong id="satTotalSubjects">0</strong></div>
                <div><span class="text-muted small">Total Units</span> <strong id="satTotalUnits">0</strong></div>
            </div>
        </div>
    </div>
    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="SAT.goToStep('form')"><i class="fas fa-arrow-left me-2"></i>Back</button>
        <button type="button" class="btn btn-sms-primary ms-auto" onclick="SAT.goToValidate()">Validate Section<i class="fas fa-shield-halved ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 4: Review & Validate ================= -->
<section class="sat-step d-none" id="sat-step-validate">
    <div class="card">
        <div class="card-body text-center py-4">
            <div class="mb-2" id="satValidateIcon"><i class="fas fa-circle-check fa-3x text-success"></i></div>
            <h4 class="fw-semibold mb-1" id="satValidateTitle">Validation Passed!</h4>
            <p class="text-muted mb-4" id="satValidateSub">All information is valid and ready to save.</p>
            <div class="sat-validate-list text-start mx-auto" id="satValidateList" style="max-width:560px;"></div>
        </div>
    </div>
    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="SAT.goToStep('subjects')"><i class="fas fa-arrow-left me-2"></i>Back to Edit</button>
        <button type="button" class="btn btn-sms-primary ms-auto" id="satSaveBtn" onclick="SAT.saveSection()">Save Section Assignment<i class="fas fa-floppy-disk ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 5: Save Section Assignment (success) ================= -->
<section class="sat-step d-none" id="sat-step-saved">
    <div class="card">
        <div class="card-body text-center py-5">
            <div class="mb-3"><i class="fas fa-file-circle-check fa-4x text-success opacity-75"></i></div>
            <h4 class="fw-semibold mb-1">Section assignment has been saved successfully!</h4>
            <p class="text-muted mb-4">You can proceed to teacher scheduling mapping for this section.</p>
            <div class="student-record-grid mx-auto text-start" style="max-width:640px;" id="satSavedSummary"></div>
        </div>
    </div>
    <div class="submodule-action-bar">
        <button type="button" class="btn btn-outline-secondary" onclick="SAT.goToStep('open')"><i class="fas fa-list me-2"></i>Back to List</button>
        <button type="button" class="btn btn-sms-primary ms-auto" onclick="SAT.goToNextModuleStep()">Proceed to Teacher Mapping<i class="fas fa-arrow-right ms-2"></i></button>
    </div>
</section>

<!-- ================= STEP 6: What's Next ================= -->
<section class="sat-step d-none" id="sat-step-next">
    <div class="card">
        <div class="card-body text-center py-4">
            <div class="mb-3"><i class="fas fa-user-group fa-3x text-sms-primary opacity-75"></i></div>
            <h4 class="fw-semibold mb-1">The section is ready for teacher assignment.</h4>
            <p class="text-muted mb-4 mx-auto" style="max-width:520px;">Proceed to Teacher Scheduling Mapping to assign qualified teachers for each subject.</p>
            <div class="student-record-grid mx-auto text-start mb-2" style="max-width:640px;" id="satNextSummary"></div>
        </div>
    </div>
    <div class="submodule-action-bar">
        <a href="<?= BASE_URL ?>/dashboard/index.php" class="btn btn-outline-secondary"><i class="fas fa-house me-2"></i>Back to Dashboard</a>
        <a href="#" class="btn btn-sms-primary ms-auto" id="satGoToTeacherMappingBtn">Go to Teacher Mapping<i class="fas fa-arrow-right ms-2"></i></a>
    </div>
</section>

<style>
.sat-term-badge{display:inline-flex;align-items:center;padding:.55rem .95rem;border-radius:999px;border:1px solid var(--sms-glass-border);background:var(--sms-surface);color:var(--sms-primary);font-weight:700;font-size:.82rem;backdrop-filter:var(--sms-glass-blur);-webkit-backdrop-filter:var(--sms-glass-blur);}
.sat-stepper{list-style:none;display:flex;flex-wrap:wrap;gap:.5rem;margin:0;padding:0;counter-reset:sat;}
.sat-stepper li{flex:1 1 150px;display:flex;align-items:center;gap:.6rem;padding:.5rem .6rem;border-radius:10px;opacity:.55;transition:var(--sms-transition);}
.sat-stepper li strong{display:block;font-size:.8rem;color:var(--sms-heading);line-height:1.2;}
.sat-stepper li small{display:block;font-size:.68rem;color:var(--sms-text-muted);}
.sat-step-dot{width:32px;height:32px;flex-shrink:0;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:var(--sms-surface-muted);color:var(--sms-text-muted);border:1px solid var(--sms-border);font-size:.85rem;}
.sat-stepper li.active{opacity:1;background:var(--sms-primary-xlight);}
.sat-stepper li.active .sat-step-dot{background:var(--sms-primary);color:#fff;border-color:transparent;}
.sat-stepper li.done{opacity:1;}
.sat-stepper li.done .sat-step-dot{background:var(--sms-success);color:#fff;border-color:transparent;}
.sat-choice-card{cursor:pointer;}
.sat-choice-icon{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.sat-choice-icon.primary{background:var(--sms-primary-xlight);color:var(--sms-primary);}
.sat-choice-icon.success{background:rgba(22,163,74,.15);color:var(--sms-success);}
.sat-mini-stat{padding:.75rem .5rem;border:1px solid var(--sms-border);border-radius:10px;background:var(--sms-surface-muted);}
.sat-mini-stat i{display:block;margin-bottom:.35rem;}
.sat-mini-stat strong{display:block;font-size:1.15rem;color:var(--sms-heading);}
.sat-mini-stat span{font-size:.72rem;color:var(--sms-text-muted);}
.sat-validate-list{display:grid;gap:.55rem;}
.sat-validate-list div{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.6rem .85rem;border:1px solid var(--sms-border);border-radius:10px;background:var(--sms-surface-muted);font-size:.88rem;}
.sat-validate-list .ok{color:var(--sms-success);font-weight:700;font-size:.8rem;}
.sat-validate-list .fail{color:var(--sms-danger);font-weight:700;font-size:.8rem;}
.sat-subject-row.selected{background:var(--sms-primary-xlight);}
@media (max-width:767.98px){ .sat-stepper li{flex:1 1 100%;} }
</style>

<script>
(function () {
"use strict";

/* ---------------------------------------------------------------------
 * SAT.db — real database data layer.
 * Data is loaded from the PHP API below instead of browser-only mock data.
 * ------------------------------------------------------------------- */
const SMS_BASE = '<?= BASE_URL ?>';
const SAT_API = SMS_BASE + '/api/scheduling/section-assignment.php';

let subjectCatalog = [];
let sections = [];

function yearLabel(value) {
    const n = parseInt(value, 10);

    if (!Number.isFinite(n)) {
        return '';
    }

    if (n === 1) return '1st Year';
    if (n === 2) return '2nd Year';
    if (n === 3) return '3rd Year';
    if (n === 4) return '4th Year';

    return n + 'th Year';
}

function yearNumber(label) {
    const match = String(label || '').match(/\d+/);
    return match ? parseInt(match[0], 10) : null;
}

function normalizeSection(row) {
    return {
        id: Number(row.id),
        code: row.code || '',
        name: row.name || '',
        program: row.program || '',
        year: yearLabel(row.year_level),
        yearLevel: Number(row.year_level) || null,
        sem: row.semester || '1st Semester',
        ay: row.academic_year || '',
        maxStudents: Number(row.max_students) || 0,
        currentStudents: Number(row.current_students) || 0,
        advisor: row.advisor_name || '',
        status: row.status || 'Active',
        created: row.created_at || '',
        updated: row.updated_at || '',
        subjects: Array.isArray(row.subjects)
            ? row.subjects.map(String)
            : []
    };
}

async function satRequest(url, options = {}) {

    console.log('SAT API REQUEST:', url);

    const response = await fetch(url, {
        method: options.method || 'GET',
        credentials: 'same-origin',
        headers: {
            'Accept': 'application/json',
            ...(options.body
                ? { 'Content-Type': 'application/json' }
                : {})
        },
        body: options.body || undefined
    });

    console.log('SAT API STATUS:', response.status);

    const text = await response.text();

    console.log('SAT API RESPONSE:', text);

    let payload;

    try {
        payload = JSON.parse(text);
    } catch (error) {
        throw new Error(
            'The API did not return valid JSON. Check the browser Console.'
        );
    }

    if (!response.ok || payload.ok === false) {
        throw new Error(
            payload.error || `Request failed (${response.status})`
        );
    }

    return payload;
}

async function loadSATData() {

    try {

        const data = await satRequest(SAT_API);

        console.log('SECTIONS FROM DATABASE:', data.sections);
        console.log('SUBJECTS FROM DATABASE:', data.subjects);

        subjectCatalog = Array.isArray(data.subjects)
            ? data.subjects.map(s => ({
                code: s.code || '',
                name: s.name || '',
                units: Number(s.units) || 0,
                type: s.subject_type || 'Major',
                program: s.program || 'ALL',
                yearLevel: (s.year_level === null || s.year_level === undefined || s.year_level === '') ? null : Number(s.year_level),
                semester: s.semester || null
            }))
            : [];

        sections = Array.isArray(data.sections)
            ? data.sections.map(normalizeSection)
            : [];

        console.log('NORMALIZED SECTIONS:', sections);

    } catch (error) {

        console.error('SAT LOAD ERROR:', error);

        subjectCatalog = [];
        sections = [];

        throw error;
    }
}
/* ---------------------------------------------------------------------
 * SAT — wizard controller
 * ------------------------------------------------------------------- */
const SAT = {
    mode: null,          // 'create' | 'edit'
    editingCode: null,
    current: null,        // working section object while building
    selectPage: 1,
    pageSize: 5,

    escape(str) {
        return String(str ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    },

    /* ---------- navigation ---------- */
    goToStep(name) {
        document.querySelectorAll('.sat-step').forEach(el => el.classList.add('d-none'));
        document.getElementById('sat-step-' + name).classList.remove('d-none');
        window.scrollTo({ top: document.querySelector('.page-header').offsetTop - 20, behavior: 'smooth' });
        this.updateStepper(name);
    },

    stepMap: {
        open: 1, select: 2, details: 3, form: 2, subjects: 3, validate: 4, saved: 5, next: 6,
    },

    updateStepper(name) {
        const active = this.stepMap[name] || 1;
        document.querySelectorAll('#satStepper li').forEach(li => {
            const n = parseInt(li.dataset.step, 10);
            li.classList.remove('active', 'done');
            if (n < active) li.classList.add('done');
            else if (n === active) li.classList.add('active');
        });
    },

    showAlert(msg) {
        const box = document.getElementById('satAlert');
        document.getElementById('satAlertText').textContent = msg;
        box.classList.remove('d-none');
        clearTimeout(this._alertTimer);
        this._alertTimer = setTimeout(() => box.classList.add('d-none'), 4000);
    },

    /* ---------- STEP 1 ---------- */
    renderRecent() {
        const body = document.getElementById('satRecentTableBody');
        const rows = sections.slice().sort((a, b) => (a.updated < b.updated ? 1 : -1)).slice(0, 5);
        body.innerHTML = rows.map(s => `
            <tr>
                <td class="fw-semibold">${this.escape(s.code)}</td>
                <td>${this.escape(s.name)}</td>
                <td>${this.escape(s.program)}</td>
                <td>${this.escape(s.year)}</td>
                <td>${this.escape(s.sem)}</td>
                <td>${s.currentStudents} / ${s.maxStudents}</td>
                <td><span class="badge text-bg-success">${this.escape(s.status)}</span></td>
                <td>${this.escape(s.updated)}</td>
                <td class="text-end"><button type="button" class="btn btn-outline-primary btn-sm" onclick="SAT.openDetails('${s.code}')"><i class="fas fa-eye me-1"></i>Open</button></td>
            </tr>
        `).join('') || `<tr><td colspan="9" class="text-center text-muted py-3">No sections yet — create one to get started.</td></tr>`;
    },

    startSelectExisting() {
        this.selectPage = 1;
        this.goToStep('select');
        this.renderSelectTable();
    },

    startCreateNew() {
        this.mode = 'create';
        this.editingCode = null;
        this.current = { code: '', name: '', program: '', year: '', sem: '1st Semester', ay: '2026-2027', maxStudents: '', advisor: '', subjects: [] };
        document.getElementById('satFormTitle').textContent = 'Section Information';
        this.fillForm();
        this.goToStep('form');
    },

    /* ---------- STEP 2a: select existing ---------- */
    filteredSections() {
        const q = (document.getElementById('satSearchInput')?.value || '').trim().toLowerCase();
        const program = document.getElementById('satFilterProgram')?.value || '';
        const year = document.getElementById('satFilterYear')?.value || '';
        const sem = document.getElementById('satFilterSemester')?.value || '';
        const ay = document.getElementById('satFilterAY')?.value || '';
        return sections.filter(s => {
            if (program && s.program !== program) return false;
            if (year && s.year !== year) return false;
            if (sem && s.sem !== sem) return false;
            if (ay && s.ay !== ay) return false;
            if (q && !(s.code.toLowerCase().includes(q) || s.name.toLowerCase().includes(q) || s.advisor.toLowerCase().includes(q))) return false;
            return true;
        });
    },

    renderSelectTable() {
        const all = this.filteredSections();
        const totalPages = Math.max(1, Math.ceil(all.length / this.pageSize));
        this.selectPage = Math.min(this.selectPage, totalPages);
        const start = (this.selectPage - 1) * this.pageSize;
        const rows = all.slice(start, start + this.pageSize);

        document.getElementById('satSelectTableBody').innerHTML = rows.map(s => `
            <tr>
                <td class="fw-semibold">${this.escape(s.code)}</td>
                <td>${this.escape(s.name)}</td>
                <td>${this.escape(s.program)}</td>
                <td>${this.escape(s.year)}</td>
                <td>${this.escape(s.sem)}</td>
                <td>${s.currentStudents} / ${s.maxStudents}</td>
                <td><span class="badge text-bg-success">${this.escape(s.status)}</span></td>
                <td class="text-end"><button type="button" class="btn btn-outline-primary btn-sm" onclick="SAT.openDetails('${s.code}')"><i class="fas fa-eye me-1"></i>Open</button></td>
            </tr>
        `).join('') || `<tr><td colspan="8" class="text-center text-muted py-3">No sections match your filters.</td></tr>`;

        document.getElementById('satSelectCount').textContent = all.length
            ? `Showing ${start + 1} to ${Math.min(start + this.pageSize, all.length)} of ${all.length} entries`
            : 'No entries found';

        const pager = document.getElementById('satSelectPagination');
        let html = `<li class="page-item ${this.selectPage === 1 ? 'disabled' : ''}"><a class="page-link" href="#" onclick="event.preventDefault();SAT.changeSelectPage(${this.selectPage - 1})">&lsaquo;</a></li>`;
        for (let p = 1; p <= totalPages; p++) {
            html += `<li class="page-item ${p === this.selectPage ? 'active' : ''}"><a class="page-link" href="#" onclick="event.preventDefault();SAT.changeSelectPage(${p})">${p}</a></li>`;
        }
        html += `<li class="page-item ${this.selectPage === totalPages ? 'disabled' : ''}"><a class="page-link" href="#" onclick="event.preventDefault();SAT.changeSelectPage(${this.selectPage + 1})">&rsaquo;</a></li>`;
        pager.innerHTML = html;
    },

    changeSelectPage(p) {
        if (p < 1) return;
        this.selectPage = p;
        this.renderSelectTable();
    },

    /* ---------- STEP 2b: section details (view) ---------- */
    openDetails(code) {
        const s = sections.find(x => x.code === code);
        if (!s) return;
        this.current = s;
        const subjects = s.subjects.map(code => subjectCatalog.find(sub => sub.code === code)).filter(Boolean);
        const totalUnits = subjects.reduce((sum, x) => sum + x.units, 0);

        document.getElementById('satDetailsInfo').innerHTML = [
            ['Section Code', s.code], ['Section Name', s.name], ['Program / Course', s.program],
            ['Year Level', s.year], ['Semester', s.sem], ['Academic Year', s.ay],
            ['Maximum Students', s.maxStudents], ['Current Students', s.currentStudents],
            ['Advisor', s.advisor || '—'], ['Status', s.status],
            ['Created At', s.created], ['Last Updated', s.updated],
        ].map(([label, val]) => `<div><span>${this.escape(label)}</span><strong>${this.escape(val)}</strong></div>`).join('');

        document.getElementById('satDetailsSubjectCount').textContent = subjects.length + ' subjects';
        document.getElementById('satDetailsSubjects').innerHTML = subjects.map((sub, i) => `
            <tr><td>${i + 1}</td><td>${this.escape(sub.code)}</td><td>${this.escape(sub.name)}</td><td>${sub.units}</td><td>${this.escape(sub.type)}</td></tr>
        `).join('') || `<tr><td colspan="5" class="text-center text-muted py-3">No subjects assigned yet.</td></tr>`;
        document.getElementById('satDetailsTotalUnits').textContent = totalUnits;

        document.getElementById('satDetailsMax').textContent = s.maxStudents;
        document.getElementById('satDetailsCurrent').textContent = s.currentStudents;
        document.getElementById('satDetailsAvailable').textContent = Math.max(0, s.maxStudents - s.currentStudents);

        document.getElementById('satEditSectionBtn').onclick = () => this.editFromDetails(s.code);
        document.getElementById('satContinueTeacherBtn').onclick = () => this.goToNextModuleStep();

        this.goToStep('details');
    },

    editFromDetails(code) {
        const s = sections.find(x => x.code === code);
        if (!s) return;
        this.mode = 'edit';
        this.editingCode = s.code;
        this.current = { ...s, subjects: s.subjects.slice() };
        document.getElementById('satFormTitle').textContent = 'Edit Section — ' + s.code;
        this.fillForm();
        this.goToStep('form');
    },

    /* ---------- STEP 2c: form ---------- */
    fillForm() {
        const c = this.current;
        document.getElementById('satFieldName').value = c.name || '';
        document.getElementById('satFieldCode').value = c.code || '';
        document.getElementById('satFieldProgram').value = c.program || '';
        document.getElementById('satFieldYear').value = c.year || '';
        document.getElementById('satFieldSemester').value = c.sem || '1st Semester';
        document.getElementById('satFieldAY').value = c.ay || '2026-2027';
        document.getElementById('satFieldMax').value = c.maxStudents || '';
        document.getElementById('satFieldAdvisor').value = c.advisor || '';
    },

    cancelForm() {
        this.goToStep(this.editingCode ? 'details' : 'open');
        if (!this.editingCode) this.renderRecent();
    },

    submitSectionForm() {
        const name = document.getElementById('satFieldName').value.trim();
        const code = document.getElementById('satFieldCode').value.trim().toUpperCase();
        const program = document.getElementById('satFieldProgram').value;
        const year = document.getElementById('satFieldYear').value;
        const sem = document.getElementById('satFieldSemester').value;
        const ay = document.getElementById('satFieldAY').value;
        const max = parseInt(document.getElementById('satFieldMax').value, 10);
        const advisor = document.getElementById('satFieldAdvisor').value.trim();

        const missing = !name || !code || !program || !year || !sem || !ay || !max;
        document.querySelectorAll('#satSectionForm [required]').forEach(el => el.classList.toggle('is-invalid', !el.value));
        if (missing) {
            this.showAlert('Please complete all required fields before continuing.');
            return;
        }

        this.current = {
            ...this.current, name, code, program, year, sem, ay,
            maxStudents: max,
            currentStudents: this.current.currentStudents || 0,
            advisor,
            subjects: this.current.subjects || [],
        };
        this.renderSubjectStep();
        this.goToStep('subjects');
    },

    /* ---------- STEP 3: assign subjects ---------- */
    renderSubjectStep() {
        const c = this.current;
        document.getElementById('satSubjectsSectionBadge').textContent = `${c.code} (${c.name})`;
        document.getElementById('satSubjectsMeta').textContent = `Program: ${c.program} · Year Level: ${c.year} · Semester: ${c.sem} · Academic Year: ${c.ay}`;
        const sectionYear = parseInt(c.year, 10);
        const available = subjectCatalog.filter(s => {
            const programOk = (s.program === c.program || s.program === 'ALL');
            const yearOk    = (s.yearLevel === null || s.yearLevel === sectionYear);
            const semOk     = (s.semester === null || s.semester === c.sem);
            return programOk && yearOk && semOk;
        });
        document.getElementById('satSubjectsTableBody').innerHTML = available.map((s, i) => {
            const checked = c.subjects.includes(s.code) ? 'checked' : '';
            return `
            <tr class="sat-subject-row ${checked ? 'selected' : ''}" id="satSubjRow_${s.code}">
                <td>${i + 1}</td>
                <td>${this.escape(s.code)}</td>
                <td>${this.escape(s.name)}</td>
                <td>${s.units}</td>
                <td>${this.escape(s.type)}</td>
                <td class="text-center">
                    <input type="checkbox" class="form-check-input" ${checked} onchange="SAT.toggleSubject('${s.code}', this.checked)">
                </td>
            </tr>`;
        }).join('') || `<tr><td colspan="6" class="text-center text-muted py-3">No subjects available for this program yet.</td></tr>`;

        this.updateSubjectTotals();
    },

    toggleSubject(code, checked) {
        const c = this.current;
        const idx = c.subjects.indexOf(code);
        if (checked && idx === -1) c.subjects.push(code);
        if (!checked && idx !== -1) c.subjects.splice(idx, 1);
        document.getElementById('satSubjRow_' + code).classList.toggle('selected', checked);
        this.updateSubjectTotals();
    },

    updateSubjectTotals() {
        const subs = this.current.subjects.map(code => subjectCatalog.find(s => s.code === code)).filter(Boolean);
        document.getElementById('satTotalSubjects').textContent = subs.length;
        document.getElementById('satTotalUnits').textContent = subs.reduce((sum, s) => sum + s.units, 0);
    },

    /* ---------- STEP 4: validate ---------- */
    goToValidate() {
        const c = this.current;
        const dupe = sections.some(s => s.code === c.code && s.code !== this.editingCode);
        const validateYear = parseInt(c.year, 10);
        const invalidSubjects = c.subjects.filter(code => {
            const s = subjectCatalog.find(x => x.code === code);
            if (!s) return true;
            const programOk = (s.program === c.program || s.program === 'ALL');
            const yearOk    = (s.yearLevel === null || s.yearLevel === validateYear);
            const semOk     = (s.semester === null || s.semester === c.sem);
            return !(programOk && yearOk && semOk);
        });
        const checks = [
            { label: 'Section Information', ok: !!(c.name && c.code) },
            { label: 'Program, Year Level, Semester', ok: !!(c.program && c.year && c.sem) },
            { label: 'Academic Year', ok: !!c.ay },
            { label: 'Maximum Students', ok: !!c.maxStudents },
            { label: 'Assigned Subjects', ok: c.subjects.length > 0 },
            { label: 'Duplicate Section Code', ok: !dupe, okText: 'No duplicates found', failText: 'Section code already exists' },
            { label: 'Subject Availability',
              ok: invalidSubjects.length === 0,
              okText: c.subjects.length + ' subject(s) verified',
              failText: 'Not valid for this section: ' + invalidSubjects.join(', ') },
        ];
        const allOk = checks.every(x => x.ok);

        document.getElementById('satValidateList').innerHTML = checks.map(x => `
            <div>
                <span>${this.escape(x.label)}</span>
                <span class="${x.ok ? 'ok' : 'fail'}"><i class="fas ${x.ok ? 'fa-circle-check' : 'fa-circle-xmark'} me-1"></i>${this.escape(x.ok ? (x.okText || 'Complete') : (x.failText || 'Incomplete'))}</span>
            </div>
        `).join('') + `
            <div><span>Total Units</span><strong>${c.subjects.reduce((sum, code) => { const s = subjectCatalog.find(x => x.code === code); return sum + (s ? s.units : 0); }, 0)} units</strong></div>
        `;

        document.getElementById('satValidateIcon').innerHTML = allOk
            ? '<i class="fas fa-circle-check fa-3x text-success"></i>'
            : '<i class="fas fa-triangle-exclamation fa-3x text-danger"></i>';
        document.getElementById('satValidateTitle').textContent = allOk ? 'Validation Passed!' : 'Validation Failed';
        document.getElementById('satValidateTitle').className = 'fw-semibold mb-1 ' + (allOk ? 'text-success' : 'text-danger');
        document.getElementById('satValidateSub').textContent = allOk
            ? 'All information is valid and ready to save.'
            : 'Please resolve the issues above before saving.';
        document.getElementById('satSaveBtn').disabled = !allOk;

        this.goToStep('validate');
    },

    /* ---------- STEP 5: save ---------- */
    async saveSection() {
        const c = this.current;
        c.status = c.status || 'Active';

        try {
            const payload = await satRequest(SAT_API, {
                method: 'POST',
                body: JSON.stringify({
                    id: c.id || null,
                    original_code: this.editingCode || null,
                    code: c.code,
                    name: c.name,
                    program: c.program,
                    year_level: yearNumber(c.year),
                    semester: c.sem,
                    academic_year: c.ay,
                    max_students: Number(c.maxStudents) || 0,
                    current_students: Number(c.currentStudents) || 0,
                    advisor_name: c.advisor || null,
                    status: c.status,
                    subjects: c.subjects || [],
                }),
            });

            c.id = Number(payload.section.id);
            sections = Array.isArray(payload.sections) ? payload.sections.map(normalizeSection) : sections;
            this.current = sections.find(s => s.id === c.id) || normalizeSection(payload.section);

            const subs = this.current.subjects.map(code => subjectCatalog.find(s => s.code === code)).filter(Boolean);
            const totalUnits = subs.reduce((sum, s) => sum + Number(s.units || 0), 0);
            document.getElementById('satSavedSummary').innerHTML = [
                ['Section Code', this.current.code], ['Section Name', this.current.name],
                ['Program', this.current.program], ['Year Level', this.current.year],
                ['Semester', this.current.sem], ['Academic Year', this.current.ay],
                ['Total Subjects', subs.length], ['Total Units', totalUnits],
                ['Status', this.current.status],
            ].map(([label, val]) => `<div><span>${this.escape(label)}</span><strong>${this.escape(val)}</strong></div>`).join('');

            this.showAlert(payload.message || 'Section assignment saved successfully.');
            this.goToStep('saved');
        } catch (error) {
            console.error(error);
            this.showAlert(error.message || 'Unable to save section assignment.');
        }
    },

    /* ---------- STEP 6: next module ---------- */
    goToNextModuleStep() {
        const c = this.current;
        const subs = (c.subjects || []).map(code => subjectCatalog.find(s => s.code === code)).filter(Boolean);
        const totalUnits = subs.reduce((sum, s) => sum + s.units, 0);
        document.getElementById('satNextSummary').innerHTML = [
            ['Section', `${c.code} (${c.name})`], ['Program', c.program], ['Year Level', c.year],
            ['Semester', c.sem], ['Academic Year', c.ay], ['Total Subjects', subs.length],
            ['Total Units', totalUnits], ['Status', c.status],
        ].map(([label, val]) => `<div><span>${this.escape(label)}</span><strong>${this.escape(val)}</strong></div>`).join('');

        document.getElementById('satGoToTeacherMappingBtn').href =
            '<?= BASE_URL ?>/modules/scheduling/pages/teacher-schedule-mapping.php?section=' + encodeURIComponent(c.code);

        this.goToStep('next');
    },
};

window.SAT = SAT;

/* wire filter/search live updates */
document.addEventListener('DOMContentLoaded', async () => {
    ['satFilterProgram', 'satFilterYear', 'satFilterSemester', 'satFilterAY'].forEach(id => {
        document.getElementById(id).addEventListener('change', () => { SAT.selectPage = 1; SAT.renderSelectTable(); });
    });
    document.getElementById('satSearchInput').addEventListener('input', () => { SAT.selectPage = 1; SAT.renderSelectTable(); });

    try {
        await loadSATData();
        SAT.renderRecent();
        SAT.goToStep('open');
    } catch (error) {
        console.error(error);
        SAT.renderRecent();
        SAT.goToStep('open');
        SAT.showAlert('Unable to load scheduling data: ' + error.message);
    }
});
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
