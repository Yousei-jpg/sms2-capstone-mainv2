<?php
/**
 * SMS 2 - Special Class Scheduler
 * Module: Class Scheduling  (Phase 8)
 *
 * Schedules non-standard sessions that fall on a specific calendar date:
 * make-up classes, tutorials, review sessions, and seminars. Conflicts are
 * detected against both recurring classes and other special sessions.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Special Class Scheduler';
$activeModule = 'scheduling';
$activePage   = 'special-class-scheduler';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Special Class Scheduler', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
    .spc-meta { font-size: .78rem; color: #6c757d; }

    .spc-badge { font-size: .72rem; font-weight: 600; padding: .3rem .6rem; border-radius: 999px; white-space: nowrap; }
    .spc-badge.st-Draft     { background: #e4ecfa; color: #26497f; }
    .spc-badge.st-Validated { background: #fdf0d5; color: #8a5b00; }
    .spc-badge.st-Published { background: #d9f2e3; color: #1e7e42; }
    .spc-badge.st-Cancelled { background: #f1f3f5; color: #6c757d; }

    .spc-type { font-size: .72rem; font-weight: 600; padding: .25rem .55rem; border-radius: .35rem;
                background: #eef2f7; color: #40506b; white-space: nowrap; }

    .spc-conflict {
        border: 1px solid #f2c9cd; background: #fdf4f5; border-radius: .5rem;
        padding: .7rem .9rem; margin-bottom: .5rem;
    }
    .spc-conflict .spc-conflict-head { font-weight: 600; color: #b02a37; font-size: .85rem; }
    .spc-conflict .spc-conflict-body { font-size: .82rem; color: #55424a; margin-top: .15rem; }
    .spc-conflict .spc-conflict-act  { font-size: .78rem; color: #6c757d; margin-top: .2rem; }

    .spc-empty { padding: 2.5rem 1rem; text-align: center; color: #6c757d; }
    #spcRecordTable td { vertical-align: middle; }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-calendar-plus text-sms-primary me-2"></i>Special Class Scheduler</h1>
        <p>Schedule make-up classes, tutorials, review sessions, and seminars on a specific date.</p>
    </div>
</div>

<div id="spcAlert" class="alert submodule-alert d-none" role="alert">
    <i class="fas fa-circle-info me-2"></i><span id="spcAlertText"></span>
</div>

<!-- Session form -->
<div class="card mb-3">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0"><i class="fas fa-pen-to-square me-2 text-sms-primary"></i>Session Details</h5>
            <span class="spc-meta" id="spcEditLabel"></span>
        </div>

        <div class="row g-3">
            <div class="col-md-6">
                <label for="spcTitle" class="form-label fw-semibold">Title</label>
                <input type="text" id="spcTitle" class="form-control rounded-3" maxlength="150"
                       placeholder="e.g. Make-up class for IT301">
            </div>
            <div class="col-md-3">
                <label for="spcType" class="form-label fw-semibold">Type</label>
                <select id="spcType" class="form-select rounded-3"></select>
            </div>
            <div class="col-md-3">
                <label for="spcDate" class="form-label fw-semibold">Date</label>
                <input type="date" id="spcDate" class="form-control rounded-3">
                <div id="spcWeekday" class="spc-meta mt-1"></div>
            </div>

            <div class="col-md-3">
                <label for="spcStart" class="form-label fw-semibold">Start time</label>
                <input type="time" id="spcStart" class="form-control rounded-3">
            </div>
            <div class="col-md-3">
                <label for="spcEnd" class="form-label fw-semibold">End time</label>
                <input type="time" id="spcEnd" class="form-control rounded-3">
            </div>
            <div class="col-md-3">
                <label for="spcTeacher" class="form-label fw-semibold">Teacher <span class="text-muted fw-normal">(optional)</span></label>
                <select id="spcTeacher" class="form-select rounded-3"></select>
            </div>
            <div class="col-md-3">
                <label for="spcRoom" class="form-label fw-semibold">Room <span class="text-muted fw-normal">(optional)</span></label>
                <select id="spcRoom" class="form-select rounded-3"></select>
            </div>

            <div class="col-md-3">
                <label for="spcSection" class="form-label fw-semibold">Section <span class="text-muted fw-normal">(optional)</span></label>
                <select id="spcSection" class="form-select rounded-3"></select>
            </div>
            <div class="col-md-3">
                <label for="spcSubject" class="form-label fw-semibold">Subject <span class="text-muted fw-normal">(optional)</span></label>
                <select id="spcSubject" class="form-select rounded-3"></select>
            </div>
            <div class="col-md-6">
                <label for="spcRemarks" class="form-label fw-semibold">Remarks <span class="text-muted fw-normal">(optional)</span></label>
                <input type="text" id="spcRemarks" class="form-control rounded-3" maxlength="255"
                       placeholder="Optional note">
            </div>
        </div>

        <div id="spcConflictBox" class="mt-3 d-none">
            <div class="fw-semibold mb-2 text-danger">
                <i class="fas fa-triangle-exclamation me-1"></i><span id="spcConflictCount"></span>
            </div>
            <div id="spcConflictList"></div>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-3">
            <button id="spcCheckBtn" class="btn btn-outline-primary rounded-3">
                <i class="fas fa-magnifying-glass me-2"></i>Check Conflicts
            </button>
            <button id="spcSaveBtn" class="btn btn-success rounded-3">
                <i class="fas fa-floppy-disk me-2"></i>Save Session
            </button>
            <button id="spcResetBtn" class="btn btn-outline-secondary rounded-3">
                <i class="fas fa-rotate-left me-2"></i>Clear Form
            </button>
        </div>

        <div class="spc-meta mt-2">
            Sessions are saved as <strong>Draft</strong>. A session must be free of conflicts before it can be published.
        </div>
    </div>
</div>

<!-- Recorded sessions -->
<div class="card">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0"><i class="fas fa-calendar-days me-2 text-sms-primary"></i>Scheduled Sessions</h5>
            <div class="d-flex gap-2 align-items-center">
                <select id="spcFilterType" class="form-select form-select-sm rounded-3" style="width:auto">
                    <option value="">All types</option>
                </select>
                <select id="spcFilterStatus" class="form-select form-select-sm rounded-3" style="width:auto">
                    <option value="">All statuses</option>
                    <option value="Draft">Draft</option>
                    <option value="Validated">Validated</option>
                    <option value="Published">Published</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
                <button id="spcRefreshBtn" class="btn btn-outline-primary btn-sm rounded-3">
                    <i class="fas fa-rotate me-1"></i>Refresh
                </button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle" id="spcRecordTable">
                <thead class="table-light">
                    <tr>
                        <th style="width:20%">Title</th>
                        <th style="width:10%">Type</th>
                        <th style="width:12%">Date</th>
                        <th style="width:11%">Time</th>
                        <th style="width:14%">Teacher</th>
                        <th style="width:9%">Room</th>
                        <th style="width:10%">Section</th>
                        <th style="width:8%">Status</th>
                        <th style="width:6%">Action</th>
                    </tr>
                </thead>
                <tbody id="spcRecordBody">
                    <tr>
                        <td colspan="9">
                            <div class="spc-empty">
                                <i class="fas fa-calendar fa-2x mb-2 d-block opacity-50"></i>
                                No special sessions scheduled yet.
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    const SPC_API = '<?= BASE_URL ?>/api/scheduling/special-class.php';

    let editingId = 0;

    const $ = (id) => document.getElementById(id);

    function showAlert(message, kind) {
        const box = $('spcAlert');
        box.className = 'alert submodule-alert alert-' + (kind || 'info');
        $('spcAlertText').textContent = message;
        box.classList.remove('d-none');
    }

    function hideAlert() {
        $('spcAlert').classList.add('d-none');
    }

    async function request(url, options) {
        const response = await fetch(url, options);
        let data = null;

        try {
            data = await response.json();
        } catch (error) {
            throw new Error('The server returned an unreadable response.');
        }

        if (!response.ok || !data.ok) {
            throw new Error((data && data.error) || 'Request failed.');
        }

        return data;
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function updateWeekday() {
        const value = $('spcDate').value;
        if (!value) {
            $('spcWeekday').textContent = '';
            return;
        }

        const parts = value.split('-').map(Number);
        const date = new Date(parts[0], parts[1] - 1, parts[2]);
        const names = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        $('spcWeekday').textContent = names[date.getDay()];
    }

    function fillSelect(id, items, valueKey, labelFn, placeholder) {
        $(id).innerHTML = '<option value="">' + placeholder + '</option>' +
            items.map((item) =>
                '<option value="' + item[valueKey] + '">' + escapeHtml(labelFn(item)) + '</option>'
            ).join('');
    }

    async function loadOptions() {
        try {
            const data = await request(SPC_API + '?action=options', { method: 'GET' });

            $('spcType').innerHTML = (data.types || [])
                .map((t) => '<option value="' + t + '">' + t + '</option>').join('');

            $('spcFilterType').innerHTML = '<option value="">All types</option>' +
                (data.types || []).map((t) => '<option value="' + t + '">' + t + '</option>').join('');

            fillSelect('spcTeacher', data.teachers || [], 'id', (t) => t.full_name, '— None —');
            fillSelect('spcRoom', data.rooms || [], 'id', (r) => r.room_code, '— None —');
            fillSelect('spcSection', data.sections || [], 'id', (s) => s.code + ' — ' + s.name, '— None —');
            fillSelect('spcSubject', data.subjects || [], 'id', (s) => s.code + ' — ' + s.name, '— None —');
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function renderConflicts(conflicts) {
        const box = $('spcConflictBox');

        if (!conflicts || conflicts.length === 0) {
            box.classList.add('d-none');
            $('spcConflictList').innerHTML = '';
            return;
        }

        $('spcConflictCount').textContent =
            conflicts.length + ' conflict(s) found';

        $('spcConflictList').innerHTML = conflicts.map((item) =>
            '<div class="spc-conflict">' +
                '<div class="spc-conflict-head">' + escapeHtml(item.type) +
                    ' conflict · ' + escapeHtml(item.against) + '</div>' +
                '<div class="spc-conflict-body">' + escapeHtml(item.detail) + '</div>' +
                '<div class="spc-conflict-act"><i class="fas fa-lightbulb me-1"></i>' +
                    escapeHtml(item.action) + '</div>' +
            '</div>'
        ).join('');

        box.classList.remove('d-none');
    }

    function collectForm() {
        return {
            id: editingId,
            title: $('spcTitle').value.trim(),
            special_type: $('spcType').value,
            class_date: $('spcDate').value,
            start_time: $('spcStart').value,
            end_time: $('spcEnd').value,
            teacher_id: Number($('spcTeacher').value) || 0,
            room_id: Number($('spcRoom').value) || 0,
            section_id: Number($('spcSection').value) || 0,
            subject_id: Number($('spcSubject').value) || 0,
            remarks: $('spcRemarks').value.trim()
        };
    }

    function validateForm(form) {
        if (!form.title)      { return 'Please enter a title.'; }
        if (!form.class_date) { return 'Please choose a date.'; }
        if (!form.start_time) { return 'Please enter a start time.'; }
        if (!form.end_time)   { return 'Please enter an end time.'; }
        if (form.start_time >= form.end_time) {
            return 'Start time must be earlier than end time.';
        }
        return null;
    }

    async function checkConflicts() {
        const form = collectForm();
        const problem = validateForm(form);

        if (problem) {
            showAlert(problem, 'warning');
            return;
        }

        hideAlert();

        try {
            const params = new URLSearchParams({
                action: 'check',
                class_date: form.class_date,
                start_time: form.start_time,
                end_time: form.end_time,
                teacher_id: form.teacher_id,
                room_id: form.room_id,
                section_id: form.section_id,
                id: form.id
            });

            const data = await request(SPC_API + '?' + params.toString(), { method: 'GET' });
            renderConflicts(data.conflicts);

            showAlert(
                data.count === 0
                    ? 'No conflicts found for ' + data.weekday + ' ' + form.class_date + '.'
                    : data.count + ' conflict(s) found. Review the details below.',
                data.count === 0 ? 'success' : 'warning'
            );
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function saveSession() {
        const form = collectForm();
        const problem = validateForm(form);

        if (problem) {
            showAlert(problem, 'warning');
            return;
        }

        const button = $('spcSaveBtn');
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Saving…';

        try {
            const data = await request(SPC_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.assign({ action: 'save' }, form))
            });

            renderConflicts(data.conflicts);
            showAlert(data.message, (data.conflicts && data.conflicts.length > 0) ? 'warning' : 'success');

            resetForm();
            await loadRecords();
        } catch (error) {
            showAlert(error.message, 'danger');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-floppy-disk me-2"></i>Save Session';
        }
    }

    function renderRecords(records) {
        const body = $('spcRecordBody');

        if (records.length === 0) {
            body.innerHTML =
                '<tr><td colspan="9"><div class="spc-empty">' +
                '<i class="fas fa-calendar fa-2x mb-2 d-block opacity-50"></i>' +
                'No special sessions match the current filter.' +
                '</div></td></tr>';
            return;
        }

        body.innerHTML = records.map((row) => {
            let actions = '';

            if (row.status === 'Draft') {
                actions += '<button class="btn btn-outline-success btn-sm rounded-3 me-1" ' +
                    'data-act="Published" data-id="' + row.id + '" title="Publish">' +
                    '<i class="fas fa-check"></i></button>';
            }

            if (row.status !== 'Cancelled' && row.status !== 'Published') {
                actions += '<button class="btn btn-outline-secondary btn-sm rounded-3" ' +
                    'data-act="Cancelled" data-id="' + row.id + '" title="Cancel">' +
                    '<i class="fas fa-xmark"></i></button>';
            }

            if (actions === '') {
                actions = '<span class="text-muted small">—</span>';
            }

            return '<tr>' +
                '<td class="small"><span class="fw-semibold">' + escapeHtml(row.title) + '</span>' +
                    (row.remarks ? '<div class="spc-meta">' + escapeHtml(row.remarks) + '</div>' : '') + '</td>' +
                '<td><span class="spc-type">' + escapeHtml(row.special_type) + '</span></td>' +
                '<td class="small">' + escapeHtml(row.class_date) +
                    '<div class="spc-meta">' + escapeHtml(row.weekday) + '</div></td>' +
                '<td class="small">' + escapeHtml(row.time) + '</td>' +
                '<td class="small">' + escapeHtml(row.teacher_name || '—') + '</td>' +
                '<td class="small">' + escapeHtml(row.room_code || '—') + '</td>' +
                '<td class="small">' + escapeHtml(row.section_code || '—') + '</td>' +
                '<td><span class="spc-badge st-' + escapeHtml(row.status) + '">' +
                    escapeHtml(row.status) + '</span></td>' +
                '<td>' + actions + '</td>' +
                '</tr>';
        }).join('');

        body.querySelectorAll('button[data-act]').forEach((button) => {
            button.addEventListener('click', () => {
                updateStatus(Number(button.dataset.id), button.dataset.act);
            });
        });
    }

    async function loadRecords() {
        try {
            const params = new URLSearchParams({ action: 'list' });

            const status = $('spcFilterStatus').value;
            if (status) { params.set('status', status); }

            const type = $('spcFilterType').value;
            if (type) { params.set('type', type); }

            const data = await request(SPC_API + '?' + params.toString(), { method: 'GET' });
            renderRecords(data.records || []);
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function updateStatus(id, status) {
        try {
            const data = await request(SPC_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'update_status', id: id, status: status })
            });

            showAlert(data.message, 'success');
            await loadRecords();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function resetForm() {
        editingId = 0;
        $('spcTitle').value = '';
        $('spcDate').value = '';
        $('spcStart').value = '';
        $('spcEnd').value = '';
        $('spcRemarks').value = '';
        $('spcTeacher').value = '';
        $('spcRoom').value = '';
        $('spcSection').value = '';
        $('spcSubject').value = '';
        $('spcWeekday').textContent = '';
        $('spcEditLabel').textContent = '';
        renderConflicts([]);
    }

    document.addEventListener('DOMContentLoaded', function () {
        $('spcCheckBtn').addEventListener('click', checkConflicts);
        $('spcSaveBtn').addEventListener('click', saveSession);
        $('spcResetBtn').addEventListener('click', function () {
            resetForm();
            hideAlert();
        });
        $('spcRefreshBtn').addEventListener('click', loadRecords);
        $('spcFilterStatus').addEventListener('change', loadRecords);
        $('spcFilterType').addEventListener('change', loadRecords);
        $('spcDate').addEventListener('change', updateWeekday);

        loadOptions();
        loadRecords();
    });
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
