<?php
/**
 * SMS 2 - Substitute Assignment Tracker
 * Module: Class Scheduling  (Phase 7)
 *
 * Records a teacher's absence on a given date, lists the classes affected, and
 * tracks who covers each one. Substitute choices are limited to teachers with
 * no conflicting class in the same time slot.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Substitute Assignment Tracker';
$activeModule = 'scheduling';
$activePage   = 'substitute-assignment-tracker';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Substitute Assignment Tracker', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
    .sa-stat { border-radius: .6rem; border: 1px solid #e6e9ef; padding: 1rem; text-align: center; height: 100%; }
    .sa-stat .sa-stat-value { font-size: 1.9rem; font-weight: 700; line-height: 1; }
    .sa-stat .sa-stat-label {
        font-size: .72rem; letter-spacing: .06em; text-transform: uppercase;
        color: #6c757d; margin-top: .35rem;
    }
    .sa-stat.is-total   { background: #f4f7fb; border-color: #dbe5f1; }
    .sa-stat.is-total   .sa-stat-value { color: var(--sms-primary, #1F4E79); }
    .sa-stat.is-clean   { background: #f2fbf5; border-color: #cdeed9; }
    .sa-stat.is-clean   .sa-stat-value { color: #1e7e42; }
    .sa-stat.is-warning { background: #fff9ee; border-color: #f2e2c4; }
    .sa-stat.is-warning .sa-stat-value { color: #b26a00; }

    .sa-badge { font-size: .72rem; font-weight: 600; padding: .3rem .6rem; border-radius: 999px; white-space: nowrap; }
    .sa-badge.st-Pending   { background: #fdf0d5; color: #8a5b00; }
    .sa-badge.st-Assigned  { background: #e4ecfa; color: #26497f; }
    .sa-badge.st-Completed { background: #d9f2e3; color: #1e7e42; }
    .sa-badge.st-Cancelled { background: #f1f3f5; color: #6c757d; }

    .sa-empty { padding: 2.5rem 1rem; text-align: center; color: #6c757d; }
    .sa-meta { font-size: .78rem; color: #6c757d; }
    .sa-none-free { font-size: .78rem; color: #b02a37; }
    #saClassTable td, #saRecordTable td { vertical-align: middle; }
    #saClassTable .form-select-sm, #saClassTable .form-control-sm { font-size: .82rem; }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-user-clock text-sms-primary me-2"></i>Substitute Assignment Tracker</h1>
        <p>Record a teacher's absence and assign substitute faculty to the affected classes.</p>
    </div>
</div>

<div id="saAlert" class="alert submodule-alert d-none" role="alert">
    <i class="fas fa-circle-info me-2"></i><span id="saAlertText"></span>
</div>

<!-- Step 1: absence details -->
<div class="card mb-3">
    <div class="card-body p-4">
        <h5 class="fw-semibold mb-3"><i class="fas fa-user-xmark me-2 text-sms-primary"></i>Absence Details</h5>
        <div class="row g-3">
            <div class="col-md-4">
                <label for="saTeacher" class="form-label fw-semibold">Absent teacher</label>
                <select id="saTeacher" class="form-select rounded-3">
                    <option value="">Select a teacher…</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="saDate" class="form-label fw-semibold">Absence date</label>
                <input type="date" id="saDate" class="form-control rounded-3">
                <div id="saWeekday" class="sa-meta mt-1"></div>
            </div>
            <div class="col-md-5">
                <label for="saReason" class="form-label fw-semibold">Reason <span class="text-muted fw-normal">(optional)</span></label>
                <input type="text" id="saReason" class="form-control rounded-3" maxlength="255"
                       placeholder="e.g. Medical leave, official business">
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-3">
            <button id="saFindBtn" class="btn btn-primary rounded-3">
                <i class="fas fa-magnifying-glass me-2"></i>Find Affected Classes
            </button>
            <button id="saResetBtn" class="btn btn-outline-secondary rounded-3">
                <i class="fas fa-rotate-left me-2"></i>Reset
            </button>
        </div>
    </div>
</div>

<!-- Step 2: summary -->
<div id="saSummaryRow" class="row g-3 mb-3 d-none">
    <div class="col-6 col-lg-4">
        <div class="sa-stat is-total">
            <div class="sa-stat-value" id="saStatClasses">0</div>
            <div class="sa-stat-label">Affected Classes</div>
        </div>
    </div>
    <div class="col-6 col-lg-4">
        <div class="sa-stat is-clean">
            <div class="sa-stat-value" id="saStatCovered">0</div>
            <div class="sa-stat-label">Substitute Selected</div>
        </div>
    </div>
    <div class="col-6 col-lg-4">
        <div class="sa-stat is-warning">
            <div class="sa-stat-value" id="saStatUncovered">0</div>
            <div class="sa-stat-label">Still Uncovered</div>
        </div>
    </div>
</div>

<!-- Step 3: assign substitutes -->
<div class="card mb-3">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0"><i class="fas fa-people-arrows me-2 text-sms-primary"></i>Assign Substitutes</h5>
            <span class="sa-meta" id="saClassLabel"></span>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle" id="saClassTable">
                <thead class="table-light">
                    <tr>
                        <th style="width:12%">Section</th>
                        <th style="width:20%">Subject</th>
                        <th style="width:12%">Time</th>
                        <th style="width:10%">Room</th>
                        <th style="width:23%">Substitute Teacher</th>
                        <th style="width:23%">Remarks</th>
                    </tr>
                </thead>
                <tbody id="saClassBody">
                    <tr>
                        <td colspan="6">
                            <div class="sa-empty">
                                <i class="fas fa-user-clock fa-2x mb-2 d-block opacity-50"></i>
                                Select a teacher and absence date, then click <strong>Find Affected Classes</strong>.
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <hr class="my-4">

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span class="sa-meta">
                Classes left without a substitute are saved as <strong>Pending</strong> so they stay visible.
            </span>
            <button id="saSaveBtn" class="btn btn-success rounded-3" disabled>
                <i class="fas fa-floppy-disk me-2"></i>Save Assignments
            </button>
        </div>
    </div>
</div>

<!-- Step 4: recorded assignments -->
<div class="card">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0"><i class="fas fa-clipboard-list me-2 text-sms-primary"></i>Recorded Assignments</h5>
            <div class="d-flex gap-2 align-items-center">
                <select id="saFilterStatus" class="form-select form-select-sm rounded-3" style="width:auto">
                    <option value="">All statuses</option>
                    <option value="Pending">Pending</option>
                    <option value="Assigned">Assigned</option>
                    <option value="Completed">Completed</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
                <button id="saRefreshBtn" class="btn btn-outline-primary btn-sm rounded-3">
                    <i class="fas fa-rotate me-1"></i>Refresh
                </button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle" id="saRecordTable">
                <thead class="table-light">
                    <tr>
                        <th style="width:11%">Date</th>
                        <th style="width:14%">Absent Teacher</th>
                        <th style="width:14%">Substitute</th>
                        <th style="width:16%">Class</th>
                        <th style="width:12%">Time</th>
                        <th style="width:13%">Reason</th>
                        <th style="width:10%">Status</th>
                        <th style="width:10%">Action</th>
                    </tr>
                </thead>
                <tbody id="saRecordBody">
                    <tr>
                        <td colspan="8">
                            <div class="sa-empty">
                                <i class="fas fa-clipboard fa-2x mb-2 d-block opacity-50"></i>
                                No substitute assignments recorded yet.
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    const SA_API = '<?= BASE_URL ?>/api/scheduling/substitute-assignment.php';

    let teachers = [];
    let classRows = [];

    const $ = (id) => document.getElementById(id);

    function showAlert(message, kind) {
        const box = $('saAlert');
        box.className = 'alert submodule-alert alert-' + (kind || 'info');
        $('saAlertText').textContent = message;
        box.classList.remove('d-none');
    }

    function hideAlert() {
        $('saAlert').classList.add('d-none');
    }

    async function request(url, options) {
        const response = await fetch(url, options);
        let data = null;

        try {
            data = await response.json();
        } catch (error) {
            throw new Error('The server returned an unreadable response.');
        }

        if (!response.ok || !data.ok) {
            throw new Error((data && data.error) || 'Request failed.');
        }

        return data;
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function updateWeekday() {
        const value = $('saDate').value;
        if (!value) {
            $('saWeekday').textContent = '';
            return;
        }

        const parts = value.split('-').map(Number);
        const date = new Date(parts[0], parts[1] - 1, parts[2]);
        const names = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        $('saWeekday').textContent = names[date.getDay()];
    }

    async function loadOptions() {
        try {
            const data = await request(SA_API + '?action=options', { method: 'GET' });
            teachers = data.teachers || [];

            $('saTeacher').innerHTML = '<option value="">Select a teacher…</option>' +
                teachers.map((item) =>
                    '<option value="' + item.id + '">' + escapeHtml(item.full_name) + '</option>'
                ).join('');
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function refreshSummary() {
        const covered = classRows.filter((row) => row.assigned_id).length;

        $('saStatClasses').textContent   = classRows.length;
        $('saStatCovered').textContent   = covered;
        $('saStatUncovered').textContent = classRows.length - covered;
        $('saSummaryRow').classList.remove('d-none');
    }

    function renderClasses() {
        const body = $('saClassBody');

        if (classRows.length === 0) {
            body.innerHTML =
                '<tr><td colspan="6"><div class="sa-empty">' +
                '<i class="fas fa-calendar-check fa-2x mb-2 d-block opacity-50"></i>' +
                'This teacher has no classes scheduled on that day.' +
                '</div></td></tr>';
            $('saSaveBtn').disabled = true;
            return;
        }

        body.innerHTML = classRows.map((row, index) => {
            const options = (row.candidates || []).map((teacher) =>
                '<option value="' + teacher.id + '"' +
                (Number(row.assigned_id) === Number(teacher.id) ? ' selected' : '') + '>' +
                escapeHtml(teacher.full_name) + '</option>'
            ).join('');

            const noneFree = (row.candidates || []).length === 0
                ? '<div class="sa-none-free mt-1">No free teacher in this slot</div>'
                : '';

            return '<tr data-index="' + index + '">' +
                '<td><span class="fw-semibold">' + escapeHtml(row.section_code) + '</span></td>' +
                '<td><span class="fw-semibold">' + escapeHtml(row.subject_code) + '</span>' +
                    '<div class="sa-meta">' + escapeHtml(row.subject_name || '') + '</div></td>' +
                '<td class="small">' + escapeHtml(row.time) + '</td>' +
                '<td class="small">' + escapeHtml(row.room_code || '—') + '</td>' +
                '<td><select class="form-select form-select-sm rounded-3" data-field="substitute">' +
                    '<option value="">— Leave pending —</option>' + options + '</select>' + noneFree + '</td>' +
                '<td><input type="text" class="form-control form-control-sm rounded-3" ' +
                    'data-field="remarks" maxlength="255" value="' + escapeHtml(row.remarks || '') + '" ' +
                    'placeholder="Optional note"></td>' +
                '</tr>';
        }).join('');

        body.querySelectorAll('tr[data-index]').forEach((tr) => {
            const index = Number(tr.dataset.index);

            const select = tr.querySelector('[data-field="substitute"]');
            if (select) {
                select.addEventListener('change', () => {
                    classRows[index].assigned_id = select.value ? Number(select.value) : null;
                    refreshSummary();
                });
            }

            const remarks = tr.querySelector('[data-field="remarks"]');
            if (remarks) {
                remarks.addEventListener('change', () => {
                    classRows[index].remarks = remarks.value;
                });
            }
        });

        $('saSaveBtn').disabled = false;
    }

    async function findClasses() {
        const teacherId = $('saTeacher').value;
        const date = $('saDate').value;

        if (!teacherId) {
            showAlert('Please select the absent teacher.', 'warning');
            return;
        }

        if (!date) {
            showAlert('Please choose the absence date.', 'warning');
            return;
        }

        hideAlert();

        try {
            const params = new URLSearchParams({
                action: 'affected',
                teacher_id: teacherId,
                absence_date: date
            });

            const data = await request(SA_API + '?' + params.toString(), { method: 'GET' });

            classRows = data.classes || [];
            renderClasses();
            refreshSummary();

            $('saClassLabel').textContent =
                data.teacher.full_name + ' · ' + data.weekday + ' ' + data.absence_date;

            if (classRows.length === 0) {
                showAlert('No classes are scheduled for this teacher on ' + data.weekday + '.', 'info');
            }
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function saveAssignments() {
        const teacherId = $('saTeacher').value;
        const date = $('saDate').value;

        if (!teacherId || !date || classRows.length === 0) {
            showAlert('Find the affected classes first.', 'warning');
            return;
        }

        const button = $('saSaveBtn');
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Saving…';

        try {
            const data = await request(SA_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'save',
                    teacher_id: Number(teacherId),
                    absence_date: date,
                    reason: $('saReason').value,
                    assignments: classRows.map((row) => ({
                        schedule_entry_id: row.schedule_entry_id,
                        substitute_teacher_id: row.assigned_id || 0,
                        remarks: row.remarks || ''
                    }))
                })
            });

            showAlert(data.message, 'success');
            await loadRecords();
        } catch (error) {
            showAlert(error.message, 'danger');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-floppy-disk me-2"></i>Save Assignments';
        }
    }

    function renderRecords(records) {
        const body = $('saRecordBody');

        if (records.length === 0) {
            body.innerHTML =
                '<tr><td colspan="8"><div class="sa-empty">' +
                '<i class="fas fa-clipboard fa-2x mb-2 d-block opacity-50"></i>' +
                'No substitute assignments recorded yet.' +
                '</div></td></tr>';
            return;
        }

        body.innerHTML = records.map((row) => {
            const substitute = row.substitute_teacher
                ? escapeHtml(row.substitute_teacher)
                : '<span class="text-muted">Not assigned</span>';

            const canComplete = row.status === 'Assigned';
            const canCancel   = row.status === 'Pending' || row.status === 'Assigned';

            let actions = '';
            if (canComplete) {
                actions += '<button class="btn btn-outline-success btn-sm rounded-3 me-1" ' +
                    'data-act="Completed" data-id="' + row.id + '" title="Mark completed">' +
                    '<i class="fas fa-check"></i></button>';
            }
            if (canCancel) {
                actions += '<button class="btn btn-outline-secondary btn-sm rounded-3" ' +
                    'data-act="Cancelled" data-id="' + row.id + '" title="Cancel">' +
                    '<i class="fas fa-xmark"></i></button>';
            }
            if (actions === '') {
                actions = '<span class="text-muted small">—</span>';
            }

            return '<tr>' +
                '<td class="small">' + escapeHtml(row.absence_date) +
                    '<div class="sa-meta">' + escapeHtml(row.day_of_week) + '</div></td>' +
                '<td class="small">' + escapeHtml(row.original_teacher) + '</td>' +
                '<td class="small">' + substitute + '</td>' +
                '<td class="small"><span class="fw-semibold">' + escapeHtml(row.subject_code) + '</span>' +
                    '<div class="sa-meta">' + escapeHtml(row.section_code) +
                    (row.room_code ? ' · ' + escapeHtml(row.room_code) : '') + '</div></td>' +
                '<td class="small">' + escapeHtml(row.time) + '</td>' +
                '<td class="small">' + escapeHtml(row.reason || '—') + '</td>' +
                '<td><span class="sa-badge st-' + escapeHtml(row.status) + '">' +
                    escapeHtml(row.status) + '</span></td>' +
                '<td>' + actions + '</td>' +
                '</tr>';
        }).join('');

        body.querySelectorAll('button[data-act]').forEach((button) => {
            button.addEventListener('click', () => {
                updateStatus(Number(button.dataset.id), button.dataset.act);
            });
        });
    }

    async function loadRecords() {
        try {
            const params = new URLSearchParams({ action: 'list' });
            const status = $('saFilterStatus').value;
            if (status) { params.set('status', status); }

            const data = await request(SA_API + '?' + params.toString(), { method: 'GET' });
            renderRecords(data.records || []);
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function updateStatus(id, status) {
        try {
            const data = await request(SA_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'update_status', id: id, status: status })
            });

            showAlert(data.message, 'success');
            await loadRecords();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    function resetAll() {
        $('saTeacher').value = '';
        $('saDate').value = '';
        $('saReason').value = '';
        $('saWeekday').textContent = '';
        classRows = [];
        hideAlert();
        $('saSummaryRow').classList.add('d-none');
        $('saClassLabel').textContent = '';
        $('saSaveBtn').disabled = true;
        $('saClassBody').innerHTML =
            '<tr><td colspan="6"><div class="sa-empty">' +
            '<i class="fas fa-user-clock fa-2x mb-2 d-block opacity-50"></i>' +
            'Select a teacher and absence date, then click <strong>Find Affected Classes</strong>.' +
            '</div></td></tr>';
    }

    document.addEventListener('DOMContentLoaded', function () {
        $('saFindBtn').addEventListener('click', findClasses);
        $('saSaveBtn').addEventListener('click', saveAssignments);
        $('saResetBtn').addEventListener('click', resetAll);
        $('saRefreshBtn').addEventListener('click', loadRecords);
        $('saFilterStatus').addEventListener('change', loadRecords);
        $('saDate').addEventListener('change', updateWeekday);

        loadOptions();
        loadRecords();
    });
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
