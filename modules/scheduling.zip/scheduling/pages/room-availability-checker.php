<?php
/**
 * SMS 2 - Room Availability Checker
 * Module: Class Scheduling  (Phase 3)
 *
 * Checks which rooms are free on a given day and time interval.
 * Availability is derived from rooms.status and schedule_entries occupancy.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Room Availability Checker';
$activeModule = 'scheduling';
$activePage   = 'room-availability-checker';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Room Availability Checker', 'url' => null],
];

$hideModulePageBanner = true;

/*
 * Conflict hand-off. The Conflict Checker links here with the day and start
 * time of a room conflict so the free rooms for that period are shown at once.
 * Both are optional; the page behaves normally when they are absent.
 */
$prefillDay   = isset($_GET['day'])   ? preg_replace('/[^A-Za-z]/', '', $_GET['day']) : '';
$prefillStart = isset($_GET['start']) ? preg_replace('/[^0-9:]/', '', $_GET['start']) : '';

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
.rac-prefill-banner{display:flex;align-items:center;gap:1rem;padding:.9rem 1.1rem;margin-bottom:1rem;
    border:1px solid var(--sms-primary);border-radius:12px;background:var(--sms-primary-xlight);}
.rac-prefill-icon{width:40px;height:40px;flex-shrink:0;border-radius:10px;display:flex;align-items:center;
    justify-content:center;background:var(--sms-primary);color:#fff;font-size:1rem;}
.rac-prefill-detail{font-size:.82rem;color:var(--sms-text-muted);margin-top:.15rem;}

    .rac-term-badge {
        background: #eef4fb;
        border: 1px solid #d6e4f5;
        color: var(--sms-primary, #1F4E79);
        border-radius: 999px;
        padding: .45rem 1rem;
        font-size: .85rem;
        font-weight: 600;
        white-space: nowrap;
    }
    .rac-stat {
        border-radius: .6rem;
        border: 1px solid #e6e9ef;
        padding: 1rem;
        text-align: center;
        height: 100%;
    }
    .rac-stat .rac-stat-value { font-size: 1.9rem; font-weight: 700; line-height: 1; }
    .rac-stat .rac-stat-label {
        font-size: .72rem; letter-spacing: .06em;
        text-transform: uppercase; color: #6c757d; margin-top: .35rem;
    }
    .rac-stat.is-available { background: #f2fbf5; border-color: #cdeed9; }
    .rac-stat.is-available .rac-stat-value { color: #1e7e42; }
    .rac-stat.is-occupied  { background: #fdf3f3; border-color: #f3d4d4; }
    .rac-stat.is-occupied  .rac-stat-value { color: #b53d3d; }
    .rac-stat.is-offline   { background: #f8f9fa; border-color: #e6e9ef; }
    .rac-stat.is-offline   .rac-stat-value { color: #6c757d; }
    .rac-stat.is-total     { background: #f4f7fb; border-color: #dbe5f1; }
    .rac-stat.is-total     .rac-stat-value { color: var(--sms-primary, #1F4E79); }

    .rac-badge { font-size: .72rem; font-weight: 600; padding: .3rem .6rem; border-radius: 999px; }
    .rac-badge.available   { background: #d9f2e3; color: #1e7e42; }
    .rac-badge.occupied    { background: #fadede; color: #b53d3d; }
    .rac-badge.unavailable { background: #e9ecef; color: #5a6169; }

    .rac-occupant {
        font-size: .8rem;
        border-left: 3px solid #e9b7b7;
        padding: .15rem 0 .15rem .6rem;
        margin-bottom: .35rem;
    }
    .rac-occupant:last-child { margin-bottom: 0; }
    .rac-occupant .rac-occ-time { font-weight: 600; color: #b53d3d; }
    .rac-room-code { font-weight: 600; }
    .rac-empty { padding: 2.5rem 1rem; text-align: center; color: #6c757d; }
    .rac-capacity-warn { color: #b26a00; font-weight: 600; }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-door-open text-sms-primary me-2"></i>Room Availability Checker</h1>
        <p>Check which rooms are free on a selected day and time, and see what is occupying the rest.</p>
    </div>
    <div class="rac-term-badge">
        <i class="fas fa-calendar-alt me-2"></i>
        <span>SY 2026-2027 &middot; 1st Semester</span>
    </div>
</div>

<div id="racAlert" class="alert alert-danger submodule-alert d-none" role="alert">
    <i class="fas fa-triangle-exclamation me-2"></i><span id="racAlertText"></span>
</div>

<?php if ($prefillDay !== '' && $prefillStart !== ''): ?>
<div class="rac-prefill-banner d-none" id="racPrefillBanner">
    <div class="rac-prefill-icon"><i class="fas fa-magnifying-glass-location"></i></div>
    <div class="flex-grow-1">
        <strong>Finding a vacant room</strong>
        <div class="rac-prefill-detail">
            Showing rooms free on <?= htmlspecialchars($prefillDay) ?>
            at <?= htmlspecialchars($prefillStart) ?>. Note a vacant room, then reassign it
            in Teacher Schedule Mapping.
        </div>
    </div>
    <a class="btn btn-outline-secondary btn-sm"
       href="<?= BASE_URL ?>/modules/scheduling/pages/conflict-checker.php">
        <i class="fas fa-arrow-left me-1"></i>Back to Conflict Checker
    </a>
</div>
<?php endif; ?>

<!-- ================= Filters ================= -->
<div class="card mb-3">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-3">
            <i class="fas fa-filter text-sms-primary me-2"></i>Search Criteria
        </h5>

        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label fw-semibold">Day <span class="text-danger">*</span></label>
                <select class="form-select" id="racDay">
                    <option value="Monday">Monday</option>
                    <option value="Tuesday">Tuesday</option>
                    <option value="Wednesday">Wednesday</option>
                    <option value="Thursday">Thursday</option>
                    <option value="Friday">Friday</option>
                    <option value="Saturday">Saturday</option>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label fw-semibold">Time Block <span class="text-danger">*</span></label>
                <select class="form-select" id="racTimeBlock">
                    <option value="">Loading...</option>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label fw-semibold">Room Type</label>
                <select class="form-select" id="racRoomType">
                    <option value="">All Types</option>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label fw-semibold">Building</label>
                <select class="form-select" id="racBuilding">
                    <option value="">All Buildings</option>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label fw-semibold">Min. Capacity</label>
                <input type="number" class="form-control" id="racMinCapacity" min="0" step="1" placeholder="e.g. 40">
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3">
            <small class="text-muted">
                <i class="fas fa-circle-info me-1"></i>
                A room is available when it is not marked Unavailable or under Maintenance,
                and no class occupies it during the selected period.
            </small>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-secondary" id="racResetBtn">
                    <i class="fas fa-rotate-left me-1"></i> Reset
                </button>
                <button type="button" class="btn btn-primary" id="racCheckBtn">
                    <i class="fas fa-magnifying-glass me-1"></i> Check Availability
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ================= Summary ================= -->
<div class="row g-3 mb-3 d-none" id="racSummaryRow">
    <div class="col-6 col-lg-3">
        <div class="rac-stat is-available">
            <div class="rac-stat-value" id="racStatAvailable">0</div>
            <div class="rac-stat-label">Available</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="rac-stat is-occupied">
            <div class="rac-stat-value" id="racStatOccupied">0</div>
            <div class="rac-stat-label">Occupied</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="rac-stat is-offline">
            <div class="rac-stat-value" id="racStatOffline">0</div>
            <div class="rac-stat-label">Unavailable</div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="rac-stat is-total">
            <div class="rac-stat-value" id="racStatTotal">0</div>
            <div class="rac-stat-label">Rooms Checked</div>
        </div>
    </div>
</div>

<!-- ================= Results ================= -->
<div class="card">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="card-title fw-semibold mb-0">
                <i class="fas fa-list-check text-sms-primary me-2"></i>Room Availability Results
            </h5>
            <span class="text-muted small" id="racQueryLabel"></span>
        </div>

        <div class="table-responsive">
            <table class="table submodule-table align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width:60px;">No.</th>
                        <th>Room</th>
                        <th>Building</th>
                        <th>Type</th>
                        <th class="text-center">Capacity</th>
                        <th class="text-center">Status</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody id="racTableBody">
                    <tr>
                        <td colspan="7">
                            <div class="rac-empty">
                                <i class="fas fa-door-closed fa-2x mb-2 d-block opacity-50"></i>
                                Select a day and time block, then click <strong>Check Availability</strong>.
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    const SMS_BASE = '<?= BASE_URL ?>';
    const RAC_API  = SMS_BASE + '/api/scheduling/room-availability.php';

    let timeBlocks = [];

    const $ = (id) => document.getElementById(id);

    function escapeHtml(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function showAlert(message) {
        $('racAlertText').textContent = message;
        $('racAlert').classList.remove('d-none');
    }

    function hideAlert() {
        $('racAlert').classList.add('d-none');
    }

    async function request(url) {
        const response = await fetch(url, {
            method: 'GET',
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json' }
        });
        const data = await response.json();
        if (!response.ok || !data.ok) {
            throw new Error(data.error || 'Request failed.');
        }
        return data;
    }

    /* ---------- load filter options ---------- */
    /* Values passed in from the Conflict Checker, if any. */
    const RAC_PREFILL = {
        day:   '<?= htmlspecialchars($prefillDay, ENT_QUOTES) ?>',
        start: '<?= htmlspecialchars($prefillStart, ENT_QUOTES) ?>'
    };

    async function loadOptions() {
        try {
            const data = await request(RAC_API + '?action=options');
            timeBlocks = data.time_blocks || [];

            const tb = $('racTimeBlock');
            tb.innerHTML = '';
            if (timeBlocks.length === 0) {
                tb.innerHTML = '<option value="">No active time blocks</option>';
            } else {
                timeBlocks.forEach((block, index) => {
                    const option = document.createElement('option');
                    option.value = index;
                    option.textContent = block.label;
                    tb.appendChild(option);
                });
            }

            applyPrefill();

            const rt = $('racRoomType');
            (data.room_types || []).forEach(type => {
                const option = document.createElement('option');
                option.value = type;
                option.textContent = type;
                rt.appendChild(option);
            });

            const bl = $('racBuilding');
            (data.buildings || []).forEach(building => {
                const option = document.createElement('option');
                option.value = building;
                option.textContent = building;
                bl.appendChild(option);
            });

            console.log('Room Availability options loaded:', data);
        } catch (error) {
            showAlert('Could not load filter options. ' + error.message);
            console.error(error);
        }
    }

    /* ---------- run the check ---------- */
    /*
     * Selects the day and the time block matching the conflict that was clicked,
     * then runs the check immediately so the free rooms are already on screen.
     */
    function applyPrefill() {
        if (!RAC_PREFILL.day || !RAC_PREFILL.start) {
            return;
        }

        $('racDay').value = RAC_PREFILL.day;

        const match = timeBlocks.findIndex(function (block) {
            return String(block.start_time).substring(0, 5) === RAC_PREFILL.start;
        });

        if (match >= 0) {
            $('racTimeBlock').value = String(match);
        }

        const banner = $('racPrefillBanner');
        if (banner) { banner.classList.remove('d-none'); }

        checkAvailability();
    }

    async function checkAvailability() {
        hideAlert();

        const blockIndex = $('racTimeBlock').value;
        if (blockIndex === '' || !timeBlocks[blockIndex]) {
            showAlert('Please select a time block first.');
            return;
        }

        const block = timeBlocks[blockIndex];
        const params = new URLSearchParams({
            action: 'check',
            day:    $('racDay').value,
            start:  String(block.start_time).substring(0, 5),
            end:    String(block.end_time).substring(0, 5)
        });

        const roomType = $('racRoomType').value;
        const building = $('racBuilding').value;
        const minCap   = $('racMinCapacity').value;
        if (roomType) params.append('room_type', roomType);
        if (building) params.append('building', building);
        if (minCap && Number(minCap) > 0) params.append('min_capacity', minCap);

        const button = $('racCheckBtn');
        const original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Checking...';

        try {
            const data = await request(RAC_API + '?' + params.toString());
            renderSummary(data.summary);
            renderResults(data.results, data.query);
            console.log('Room Availability result:', data);
        } catch (error) {
            showAlert(error.message);
            console.error(error);
        } finally {
            button.disabled = false;
            button.innerHTML = original;
        }
    }

    function renderSummary(summary) {
        $('racStatAvailable').textContent = summary.available;
        $('racStatOccupied').textContent  = summary.occupied;
        $('racStatOffline').textContent   = summary.unavailable;
        $('racStatTotal').textContent     = summary.total;
        $('racSummaryRow').classList.remove('d-none');
    }

    function renderResults(results, query) {
        $('racQueryLabel').textContent =
            query.day + ' \u00B7 ' + query.start + ' - ' + query.end;

        const body = $('racTableBody');

        if (!results || results.length === 0) {
            body.innerHTML = '<tr><td colspan="7"><div class="rac-empty">' +
                '<i class="fas fa-filter-circle-xmark fa-2x mb-2 d-block opacity-50"></i>' +
                'No rooms match the selected filters.</div></td></tr>';
            return;
        }

        const minCap = Number($('racMinCapacity').value) || 0;

        body.innerHTML = results.map((room, index) => {
            let badgeClass = 'unavailable';
            if (room.state === 'Available') badgeClass = 'available';
            else if (room.state === 'Occupied') badgeClass = 'occupied';

            let details;
            if (room.state === 'Occupied' && room.occupied_by.length > 0) {
                details = room.occupied_by.map(occupant => {
                    const capacityFlag = (occupant.max_students > room.capacity)
                        ? ' <span class="rac-capacity-warn">(over capacity)</span>'
                        : '';
                    return '<div class="rac-occupant">' +
                        '<span class="rac-occ-time">' +
                        escapeHtml(occupant.start_time) + ' - ' + escapeHtml(occupant.end_time) +
                        '</span> &middot; ' +
                        escapeHtml(occupant.section_code) + ' &middot; ' +
                        escapeHtml(occupant.subject_code) + ' ' +
                        escapeHtml(occupant.subject_name) +
                        '<br><span class="text-muted">' +
                        escapeHtml(occupant.teacher_name) + ' &middot; ' +
                        escapeHtml(occupant.status) + '</span>' + capacityFlag +
                        '</div>';
                }).join('');
            } else {
                details = '<span class="text-muted small">' + escapeHtml(room.detail) + '</span>';
            }

            const capacityCell = (minCap > 0 && room.capacity < minCap)
                ? '<span class="rac-capacity-warn">' + room.capacity + '</span>'
                : room.capacity;

            return '<tr>' +
                '<td>' + (index + 1) + '</td>' +
                '<td class="rac-room-code">' + escapeHtml(room.room_code) + '</td>' +
                '<td>' + escapeHtml(room.building || '\u2014') + '</td>' +
                '<td>' + escapeHtml(room.room_type) + '</td>' +
                '<td class="text-center">' + capacityCell + '</td>' +
                '<td class="text-center"><span class="rac-badge ' + badgeClass + '">' +
                    escapeHtml(room.state) + '</span></td>' +
                '<td>' + details + '</td>' +
                '</tr>';
        }).join('');
    }

    function resetFilters() {
        $('racDay').value = 'Monday';
        if (timeBlocks.length > 0) $('racTimeBlock').value = '0';
        $('racRoomType').value = '';
        $('racBuilding').value = '';
        $('racMinCapacity').value = '';
        hideAlert();
        $('racSummaryRow').classList.add('d-none');
        $('racQueryLabel').textContent = '';
        $('racTableBody').innerHTML =
            '<tr><td colspan="7"><div class="rac-empty">' +
            '<i class="fas fa-door-closed fa-2x mb-2 d-block opacity-50"></i>' +
            'Select a day and time block, then click <strong>Check Availability</strong>.' +
            '</div></td></tr>';
    }

    document.addEventListener('DOMContentLoaded', function () {
        $('racCheckBtn').addEventListener('click', checkAvailability);
        $('racResetBtn').addEventListener('click', resetFilters);
        loadOptions();
    });
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
