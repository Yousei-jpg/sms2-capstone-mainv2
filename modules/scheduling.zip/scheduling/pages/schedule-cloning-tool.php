<?php
/**
 * SMS 2 - Schedule Cloning Tool
 * Module: Class Scheduling  (Phase 6, wizard rebuild)
 *
 * Duplicates the schedule of one section into another. The workflow follows the
 * same stepped pattern as the Section Assignment Tool: choose the sections,
 * adjust the preview, review the checks, then confirm.
 *
 * Cloned rows are always inserted as Draft with source = Cloned, so the
 * Conflict Checker still has to be run before publication.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Schedule Cloning Tool';
$activeModule = 'scheduling';
$activePage   = 'schedule-cloning-tool';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Schedule Cloning Tool', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
.scl-term-badge{display:inline-flex;align-items:center;padding:.55rem .95rem;border-radius:999px;border:1px solid var(--sms-glass-border);background:var(--sms-surface);color:var(--sms-primary);font-weight:700;font-size:.82rem;backdrop-filter:var(--sms-glass-blur);-webkit-backdrop-filter:var(--sms-glass-blur);}
.scl-stepper{list-style:none;display:flex;flex-wrap:wrap;gap:.5rem;margin:0;padding:0;}
.scl-stepper li{flex:1 1 150px;display:flex;align-items:center;gap:.6rem;padding:.5rem .6rem;border-radius:10px;opacity:.55;transition:var(--sms-transition);}
.scl-stepper li strong{display:block;font-size:.8rem;color:var(--sms-heading);line-height:1.2;}
.scl-stepper li small{display:block;font-size:.68rem;color:var(--sms-text-muted);}
.scl-step-dot{width:32px;height:32px;flex-shrink:0;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;background:var(--sms-surface-muted);color:var(--sms-text-muted);border:1px solid var(--sms-border);font-size:.85rem;}
.scl-stepper li.active{opacity:1;background:var(--sms-primary-xlight);}
.scl-stepper li.active .scl-step-dot{background:var(--sms-primary);color:#fff;border-color:transparent;}
.scl-stepper li.done{opacity:1;}
.scl-stepper li.done .scl-step-dot{background:var(--sms-success);color:#fff;border-color:transparent;}

.scl-choice-icon{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0;}
.scl-choice-icon.primary{background:var(--sms-primary-xlight);color:var(--sms-primary);}

.scl-mini-stat{padding:.75rem .5rem;border:1px solid var(--sms-border);border-radius:10px;background:var(--sms-surface-muted);text-align:center;}
.scl-mini-stat i{display:block;margin-bottom:.35rem;}
.scl-mini-stat strong{display:block;font-size:1.15rem;color:var(--sms-heading);}
.scl-mini-stat span{font-size:.72rem;color:var(--sms-text-muted);}

.scl-validate-list{display:grid;gap:.55rem;}
.scl-validate-list div{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.6rem .85rem;border:1px solid var(--sms-border);border-radius:10px;background:var(--sms-surface-muted);font-size:.88rem;}
.scl-validate-list .ok{color:var(--sms-success);font-weight:700;font-size:.8rem;}
.scl-validate-list .fail{color:var(--sms-danger);font-weight:700;font-size:.8rem;}
.scl-validate-list .warn{color:var(--sms-warning,#d97706);font-weight:700;font-size:.8rem;}

.scl-arrow{display:flex;align-items:center;justify-content:center;color:var(--sms-primary);font-size:1.4rem;height:100%;}
.scl-meta{font-size:.78rem;color:var(--sms-text-muted);}
.scl-badge{font-size:.72rem;font-weight:600;padding:.3rem .6rem;border-radius:999px;white-space:nowrap;background:var(--sms-surface-muted);color:var(--sms-text-muted);}
.scl-done-icon{width:74px;height:74px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:2rem;margin:0 auto 1rem;background:rgba(22,163,74,.15);color:var(--sms-success);}
@media (max-width:767.98px){ .scl-stepper li{flex:1 1 100%;} }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-copy text-sms-primary me-2"></i>Schedule Cloning Tool</h1>
        <p>Duplicate an existing section schedule into another section, then adjust it before saving.</p>
    </div>
    <div class="scl-term-badge">
        <i class="fas fa-calendar-alt me-2"></i>
        <span id="sclTermBadge">Class Scheduling</span>
    </div>
</div>

<div class="card mb-3">
    <div class="card-body py-3">
        <ol class="scl-stepper" id="sclStepper">
            <li data-step="1"><span class="scl-step-dot"><i class="fas fa-arrow-right-arrow-left"></i></span><div><strong>Select Sections</strong><small>Source and target</small></div></li>
            <li data-step="2"><span class="scl-step-dot"><i class="fas fa-table-list"></i></span><div><strong>Preview &amp; Adjust</strong><small>Teacher, room, day, time</small></div></li>
            <li data-step="3"><span class="scl-step-dot"><i class="fas fa-shield-halved"></i></span><div><strong>Review &amp; Validate</strong><small>Check before cloning</small></div></li>
            <li data-step="4"><span class="scl-step-dot"><i class="fas fa-clone"></i></span><div><strong>Clone Schedule</strong><small>Confirm &amp; store</small></div></li>
            <li data-step="5"><span class="scl-step-dot"><i class="fas fa-list-check"></i></span><div><strong>Next Module</strong><small>Automated Conflict Checker</small></div></li>
        </ol>
    </div>
</div>

<div id="sclAlert" class="alert submodule-alert d-none" role="alert">
    <i class="fas fa-circle-info me-2"></i><span id="sclAlertText"></span>
</div>

<!-- ============ STEP 1 — Select Sections ============ -->
<section class="scl-step" id="scl-step-select">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-1"><i class="fas fa-arrow-right-arrow-left text-sms-primary me-2"></i>Select Sections</h5>
            <p class="text-muted small mb-3">Choose the section to copy from, and the section to copy into.</p>

            <div class="row g-3 align-items-end">
                <div class="col-md-5">
                    <label for="sclSource" class="form-label fw-semibold small">Source section (copy from)</label>
                    <select id="sclSource" class="form-select">
                        <option value="">Select a section&hellip;</option>
                    </select>
                    <div id="sclSourceMeta" class="scl-meta mt-1"></div>
                </div>
                <div class="col-md-2 d-none d-md-block">
                    <div class="scl-arrow pb-3"><i class="fas fa-arrow-right"></i></div>
                </div>
                <div class="col-md-5">
                    <label for="sclTarget" class="form-label fw-semibold small">Target section (copy into)</label>
                    <select id="sclTarget" class="form-select">
                        <option value="">Select a section&hellip;</option>
                    </select>
                    <div id="sclTargetMeta" class="scl-meta mt-1"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between flex-wrap gap-2 mt-3">
        <button type="button" class="btn btn-outline-secondary" onclick="SCL.resetAll()">
            <i class="fas fa-rotate-left me-2"></i>Reset
        </button>
        <button type="button" class="btn btn-primary" onclick="SCL.loadPreview()">
            Continue<i class="fas fa-arrow-right ms-2"></i>
        </button>
    </div>
</section>

<!-- ============ STEP 2 — Preview & Adjust ============ -->
<section class="scl-step d-none" id="scl-step-preview">
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-3">
                <div>
                    <h5 class="card-title fw-semibold mb-1"><i class="fas fa-table-list text-sms-primary me-2"></i>Preview &amp; Adjust</h5>
                    <p class="text-muted small mb-0">Change the teacher, room, day, time, or class type before cloning.</p>
                </div>
                <span class="scl-badge" id="sclPreviewLabel"></span>
            </div>

            <div class="row g-2 mb-3">
                <div class="col-6 col-lg-3"><div class="scl-mini-stat"><i class="fas fa-list text-sms-primary"></i><strong id="sclStatRows">0</strong><span>ROWS TO COPY</span></div></div>
                <div class="col-6 col-lg-3"><div class="scl-mini-stat"><i class="fas fa-graduation-cap text-sms-primary"></i><strong id="sclStatUnits">0</strong><span>TOTAL UNITS</span></div></div>
                <div class="col-6 col-lg-3"><div class="scl-mini-stat"><i class="fas fa-folder-open text-sms-primary"></i><strong id="sclStatExisting">0</strong><span>EXISTING IN TARGET</span></div></div>
                <div class="col-6 col-lg-3"><div class="scl-mini-stat"><i class="fas fa-lock text-sms-primary"></i><strong id="sclStatPublished">0</strong><span>PUBLISHED IN TARGET</span></div></div>
            </div>

            <div class="table-responsive">
                <table class="table submodule-table align-middle mb-0">
                    <thead>
                        <tr>
                            <th style="width:14%">Subject</th>
                            <th style="width:20%">Description</th>
                            <th style="width:18%">Teacher</th>
                            <th style="width:12%">Room</th>
                            <th style="width:12%">Day</th>
                            <th style="width:14%">Time</th>
                            <th style="width:10%">Type</th>
                        </tr>
                    </thead>
                    <tbody id="sclPreviewBody"></tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="d-flex justify-content-between flex-wrap gap-2 mt-3">
        <button type="button" class="btn btn-outline-secondary" onclick="SCL.goToStep('select')">
            <i class="fas fa-arrow-left me-2"></i>Back
        </button>
        <button type="button" class="btn btn-primary" onclick="SCL.goToValidate()">
            Continue<i class="fas fa-arrow-right ms-2"></i>
        </button>
    </div>
</section>

<!-- ============ STEP 3 — Review & Validate ============ -->
<section class="scl-step d-none" id="scl-step-validate">
    <div class="card">
        <div class="card-body">
            <h5 class="card-title fw-semibold mb-1"><i class="fas fa-shield-halved text-sms-primary me-2"></i>Review &amp; Validate</h5>
            <p class="text-muted small mb-3">Checks performed before the schedule is cloned.</p>

            <div class="scl-validate-list mb-3" id="sclValidateList"></div>

            <label for="sclOnExisting" class="form-label fw-semibold small">If the target section already has entries</label>
            <select id="sclOnExisting" class="form-select mb-2" style="max-width:26rem">
                <option value="block">Stop and warn me (safer)</option>
                <option value="replace">Replace existing draft entries</option>
            </select>
            <div class="scl-meta">Published entries are never replaced. Unpublish them first if you need to overwrite.</div>
        </div>
    </div>

    <div class="d-flex justify-content-between flex-wrap gap-2 mt-3">
        <button type="button" class="btn btn-outline-secondary" onclick="SCL.goToStep('preview')">
            <i class="fas fa-arrow-left me-2"></i>Back to Preview
        </button>
        <button type="button" class="btn btn-success" id="sclCloneBtn" onclick="SCL.runClone()">
            <i class="fas fa-clone me-2"></i>Clone Schedule
        </button>
    </div>
</section>

<!-- ============ STEP 4 — Result ============ -->
<section class="scl-step d-none" id="scl-step-done">
    <div class="card">
        <div class="card-body text-center py-4">
            <div class="scl-done-icon"><i class="fas fa-check"></i></div>
            <h5 class="fw-semibold mb-1">Schedule Cloned</h5>
            <p class="text-muted small mb-4" id="sclDoneText"></p>

            <div class="row g-2 justify-content-center" style="max-width:34rem;margin:0 auto">
                <div class="col-4"><div class="scl-mini-stat"><i class="fas fa-plus text-sms-primary"></i><strong id="sclDoneInserted">0</strong><span>INSERTED</span></div></div>
                <div class="col-4"><div class="scl-mini-stat"><i class="fas fa-arrows-rotate text-sms-primary"></i><strong id="sclDoneRemoved">0</strong><span>REPLACED</span></div></div>
                <div class="col-4"><div class="scl-mini-stat"><i class="fas fa-forward text-sms-primary"></i><strong id="sclDoneSkipped">0</strong><span>SKIPPED</span></div></div>
            </div>
        </div>
    </div>

    <div class="card mt-3">
        <div class="card-body d-flex align-items-center gap-3 flex-wrap">
            <div class="scl-choice-icon primary"><i class="fas fa-list-check"></i></div>
            <div>
                <h6 class="mb-1 fw-semibold">Run the Automated Conflict Checker</h6>
                <p class="text-muted mb-0 small">Cloned rows are saved as Draft. Validate them before publishing.</p>
            </div>
            <a href="<?= BASE_URL ?>/modules/scheduling/pages/conflict-checker.php" class="btn btn-primary ms-auto">
                Open<i class="fas fa-arrow-right ms-2"></i>
            </a>
        </div>
    </div>

    <div class="mt-3">
        <button type="button" class="btn btn-outline-secondary" onclick="SCL.resetAll()">
            <i class="fas fa-rotate-left me-2"></i>Clone Another Section
        </button>
    </div>
</section>

<script>
(function () {
    'use strict';

    const SCL_API = '<?= BASE_URL ?>/api/scheduling/clone-schedule.php';
    const DAYS  = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const TYPES = ['Lecture', 'Laboratory', 'Online', 'Exam'];

    const SCL = {
        sections: [],
        teachers: [],
        rooms: [],
        rows: [],
        targetState: { total: 0, Published: 0 },

        escape(str) {
            return String(str === null || str === undefined ? '' : str)
                .replace(/[&<>"']/g, function (c) {
                    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
                });
        },

        /* ---------- navigation ---------- */
        stepMap: { select: 1, preview: 2, validate: 3, done: 4 },

        goToStep(name) {
            document.querySelectorAll('.scl-step').forEach(function (el) { el.classList.add('d-none'); });
            document.getElementById('scl-step-' + name).classList.remove('d-none');
            window.scrollTo({ top: document.querySelector('.page-header').offsetTop - 20, behavior: 'smooth' });
            this.updateStepper(name);
        },

        updateStepper(name) {
            const active = this.stepMap[name] || 1;
            document.querySelectorAll('#sclStepper li').forEach(function (li) {
                const n = parseInt(li.dataset.step, 10);
                li.classList.remove('active', 'done');
                if (n < active) { li.classList.add('done'); }
                else if (n === active) { li.classList.add('active'); }
            });
        },

        showAlert(msg, kind) {
            const box = document.getElementById('sclAlert');
            box.className = 'alert submodule-alert alert-' + (kind || 'info');
            document.getElementById('sclAlertText').textContent = msg;
            box.classList.remove('d-none');
            clearTimeout(this._alertTimer);
            this._alertTimer = setTimeout(function () { box.classList.add('d-none'); }, 6000);
        },

        hideAlert() {
            document.getElementById('sclAlert').classList.add('d-none');
        },

        async request(url, options) {
            const response = await fetch(url, options || { method: 'GET' });
            let data = null;
            try { data = await response.json(); }
            catch (e) { throw new Error('The server returned an unreadable response.'); }
            if (!response.ok || !data.ok) { throw new Error((data && data.error) || 'Request failed.'); }
            return data;
        },

        /* ---------- STEP 1 ---------- */
        sectionMeta(section) {
            if (!section) { return ''; }
            const bits = [];
            if (section.program)       { bits.push(section.program); }
            if (section.year_level)    { bits.push('Year ' + section.year_level); }
            if (section.semester)      { bits.push(section.semester); }
            if (section.academic_year) { bits.push('SY ' + section.academic_year); }
            return bits.join(' \u00b7 ');
        },

        findSection(code) {
            return this.sections.find(function (s) { return s.code === code; }) || null;
        },

        updateMeta() {
            document.getElementById('sclSourceMeta').textContent =
                this.sectionMeta(this.findSection(document.getElementById('sclSource').value));
            document.getElementById('sclTargetMeta').textContent =
                this.sectionMeta(this.findSection(document.getElementById('sclTarget').value));
        },

        async loadOptions() {
            try {
                const data = await this.request(SCL_API + '?action=options');
                this.sections = data.sections || [];
                this.teachers = data.teachers || [];
                this.rooms    = data.rooms || [];

                const self = this;
                const opts = this.sections.map(function (s) {
                    return '<option value="' + self.escape(s.code) + '">' +
                           self.escape(s.code + ' \u2014 ' + s.name) + '</option>';
                }).join('');

                document.getElementById('sclSource').innerHTML = '<option value="">Select a section&hellip;</option>' + opts;
                document.getElementById('sclTarget').innerHTML = '<option value="">Select a section&hellip;</option>' + opts;

                if (this.sections.length > 0 && this.sections[0].academic_year) {
                    document.getElementById('sclTermBadge').textContent =
                        'SY ' + this.sections[0].academic_year + ' \u00b7 ' + (this.sections[0].semester || '');
                }
            } catch (error) {
                this.showAlert(error.message, 'danger');
            }
        },

        /* ---------- STEP 2 ---------- */
        async loadPreview() {
            const source = document.getElementById('sclSource').value;
            const target = document.getElementById('sclTarget').value;

            if (!source) { this.showAlert('Please select a source section.', 'warning'); return; }
            if (!target) { this.showAlert('Please select a target section.', 'warning'); return; }
            if (source === target) { this.showAlert('Source and target sections must be different.', 'warning'); return; }

            this.hideAlert();

            try {
                const params = new URLSearchParams({ action: 'preview', source_code: source, target_code: target });
                const data = await this.request(SCL_API + '?' + params.toString());

                this.rows = data.entries || [];
                this.targetState = data.target_state || { total: 0, Published: 0 };

                if (this.rows.length === 0) {
                    this.showAlert('The source section has no schedule entries to copy.', 'warning');
                    return;
                }

                document.getElementById('sclPreviewLabel').textContent = source + ' \u2192 ' + target;
                this.renderPreview();
                this.refreshStats();
                this.goToStep('preview');
            } catch (error) {
                this.showAlert(error.message, 'danger');
            }
        },

        selectMarkup(values, selected) {
            const self = this;
            return values.map(function (v) {
                return '<option value="' + self.escape(v) + '"' + (v === selected ? ' selected' : '') + '>' +
                       self.escape(v) + '</option>';
            }).join('');
        },

        renderPreview() {
            const self = this;
            const body = document.getElementById('sclPreviewBody');
            const teacherNames = this.teachers.map(function (t) { return t.full_name; });
            const roomCodes    = this.rooms.map(function (r) { return r.room_code; });

            body.innerHTML = this.rows.map(function (row, i) {
                return '<tr data-index="' + i + '">' +
                    '<td><span class="fw-semibold">' + self.escape(row.subject_code) + '</span>' +
                        (row.units ? '<div class="scl-meta">' + self.escape(row.units) + ' unit(s)</div>' : '') + '</td>' +
                    '<td class="small">' + self.escape(row.subject_name || '') + '</td>' +
                    '<td><select class="form-select form-select-sm" data-field="teacher"><option value="">&mdash;</option>' +
                        self.selectMarkup(teacherNames, row.teacher) + '</select></td>' +
                    '<td><select class="form-select form-select-sm" data-field="room"><option value="">&mdash;</option>' +
                        self.selectMarkup(roomCodes, row.room) + '</select></td>' +
                    '<td><select class="form-select form-select-sm" data-field="day">' +
                        self.selectMarkup(DAYS, row.day) + '</select></td>' +
                    '<td><input type="text" class="form-control form-control-sm" data-field="time" value="' +
                        self.escape(row.time) + '" placeholder="07:30 - 09:00"></td>' +
                    '<td><select class="form-select form-select-sm" data-field="class_type">' +
                        self.selectMarkup(TYPES, row.class_type) + '</select></td>' +
                '</tr>';
            }).join('');

            body.querySelectorAll('tr[data-index]').forEach(function (tr) {
                const i = Number(tr.dataset.index);
                tr.querySelectorAll('[data-field]').forEach(function (input) {
                    input.addEventListener('change', function () {
                        self.rows[i][input.dataset.field] = input.value;
                    });
                });
            });
        },

        refreshStats() {
            const units = this.rows.reduce(function (sum, r) { return sum + (Number(r.units) || 0); }, 0);
            document.getElementById('sclStatRows').textContent      = this.rows.length;
            document.getElementById('sclStatUnits').textContent     = units;
            document.getElementById('sclStatExisting').textContent  = this.targetState.total || 0;
            document.getElementById('sclStatPublished').textContent = this.targetState.Published || 0;
        },

        /* ---------- STEP 3 ---------- */
        goToValidate() {
            const self = this;
            const published  = this.targetState.Published || 0;
            const existing   = this.targetState.total || 0;
            const incomplete = this.rows.filter(function (r) {
                return !r.teacher || !r.room || !r.day || !r.time;
            }).length;

            const check = function (label, passed, note, level) {
                return '<div><span>' + self.escape(label) + '</span><span class="' +
                       (passed ? 'ok' : (level || 'fail')) + '">' + self.escape(note) + '</span></div>';
            };

            document.getElementById('sclValidateList').innerHTML =
                check('Source section has entries to copy', this.rows.length > 0,
                      this.rows.length + ' row(s)') +
                check('Every row has a teacher, room, day and time', incomplete === 0,
                      incomplete === 0 ? 'Complete' : incomplete + ' incomplete') +
                check('Target section has no published entries', published === 0,
                      published === 0 ? 'None' : published + ' published') +
                check('Target section is empty', existing === 0,
                      existing === 0 ? 'Empty' : existing + ' existing', 'warn');

            document.getElementById('sclCloneBtn').disabled = (published > 0 || incomplete > 0);

            if (published > 0) {
                this.showAlert('The target section has published entries. Unpublish them before cloning.', 'warning');
            }

            this.goToStep('validate');
        },

        /* ---------- STEP 4 ---------- */
        async runClone() {
            const source = document.getElementById('sclSource').value;
            const target = document.getElementById('sclTarget').value;
            const button = document.getElementById('sclCloneBtn');

            button.disabled = true;
            button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Cloning&hellip;';

            try {
                const data = await this.request(SCL_API, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'clone',
                        source_code: source,
                        target_code: target,
                        on_existing: document.getElementById('sclOnExisting').value,
                        entries: this.rows.map(function (r) {
                            return {
                                subject_code: r.subject_code,
                                teacher: r.teacher,
                                room: r.room,
                                day: r.day,
                                time: r.time,
                                class_type: r.class_type
                            };
                        })
                    })
                });

                document.getElementById('sclDoneText').textContent =
                    data.inserted_count + ' entry(ies) cloned from ' + source + ' into ' + target + ' as Draft.';
                document.getElementById('sclDoneInserted').textContent = data.inserted_count || 0;
                document.getElementById('sclDoneRemoved').textContent  = data.removed_count || 0;
                document.getElementById('sclDoneSkipped').textContent  = (data.skipped || []).length;

                this.goToStep('done');
            } catch (error) {
                this.showAlert(error.message, 'danger');
            } finally {
                button.disabled = false;
                button.innerHTML = '<i class="fas fa-clone me-2"></i>Clone Schedule';
            }
        },

        resetAll() {
            document.getElementById('sclSource').value = '';
            document.getElementById('sclTarget').value = '';
            this.rows = [];
            this.targetState = { total: 0, Published: 0 };
            this.updateMeta();
            this.hideAlert();
            this.goToStep('select');
        },

        init() {
            const self = this;
            document.getElementById('sclSource').addEventListener('change', function () { self.updateMeta(); });
            document.getElementById('sclTarget').addEventListener('change', function () { self.updateMeta(); });
            this.loadOptions();
            this.goToStep('select');
        }
    };

    document.addEventListener('DOMContentLoaded', function () { SCL.init(); });
    window.SCL = SCL;
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
