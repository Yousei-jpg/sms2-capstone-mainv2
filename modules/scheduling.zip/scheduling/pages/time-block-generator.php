<?php
/**
 * SMS 2 - Time Block Customizer
 * Module: Class Scheduling  (Phase 5)
 *
 * Maintains the class periods used by Teacher Schedule Mapping and the
 * Room Availability Checker.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Time Block Generator';
$activeModule = 'scheduling';
$activePage   = 'time-block-generator';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Time Block Generator', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
    .tb-term-badge {
        background: #eef4fb; border: 1px solid #d6e4f5;
        color: var(--sms-primary, #1F4E79);
        border-radius: 999px; padding: .45rem 1rem;
        font-size: .85rem; font-weight: 600; white-space: nowrap;
    }
    .tb-stat { border-radius: .6rem; border: 1px solid #e6e9ef; padding: 1rem; text-align: center; height: 100%; }
    .tb-stat .tb-stat-value { font-size: 1.9rem; font-weight: 700; line-height: 1; }
    .tb-stat .tb-stat-label {
        font-size: .72rem; letter-spacing: .06em; text-transform: uppercase;
        color: #6c757d; margin-top: .35rem;
    }
    .tb-stat.is-active   { background: #f2fbf5; border-color: #cdeed9; }
    .tb-stat.is-active   .tb-stat-value { color: #1e7e42; }
    .tb-stat.is-inactive { background: #f8f9fa; border-color: #e6e9ef; }
    .tb-stat.is-inactive .tb-stat-value { color: #6c757d; }
    .tb-stat.is-total    { background: #f4f7fb; border-color: #dbe5f1; }
    .tb-stat.is-total    .tb-stat-value { color: var(--sms-primary, #1F4E79); }

    .tb-badge { font-size: .72rem; font-weight: 600; padding: .3rem .6rem; border-radius: 999px; white-space: nowrap; }
    .tb-badge.type-Class { background: #e4ecfa; color: #26497f; }
    .tb-badge.type-Break { background: #fdf0d5; color: #8a5b00; }
    .tb-badge.type-Exam  { background: #ede4fa; color: #5b3d8f; }
    .tb-badge.active     { background: #d9f2e3; color: #1e7e42; }
    .tb-badge.inactive   { background: #e9ecef; color: #5a6169; }

    .tb-code { font-weight: 700; font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
    .tb-row-inactive { opacity: .55; }
    .tb-usage { font-size: .78rem; color: #6c757d; }
    .tb-empty { padding: 2.5rem 1rem; text-align: center; color: #6c757d; }
    .tb-form-card { border-left: 4px solid var(--sms-primary, #1F4E79); }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-clock text-sms-primary me-2"></i>Time Block Customizer</h1>
        <p>Define the class periods used across the scheduling module.</p>
    </div>
    <div class="tb-term-badge">
        <i class="fas fa-calendar-alt me-2"></i>
        <span>SY 2026-2027 &middot; 1st Semester</span>
    </div>
</div>

<div id="tbAlert" class="alert submodule-alert d-none" role="alert">
    <i class="fas fa-circle-info me-2"></i><span id="tbAlertText"></span>
</div>

<div class="alert alert-info submodule-alert" role="alert">
    <i class="fas fa-link me-2"></i>
    Active <strong>Class</strong> blocks appear in the Teacher Schedule Mapping time dropdown
    and in the Room Availability Checker. Changes here take effect immediately.
</div>

<!-- ================= Summary ================= -->
<div class="row g-3 mb-3">
    <div class="col-4">
        <div class="tb-stat is-active">
            <div class="tb-stat-value" id="tbStatActive">0</div>
            <div class="tb-stat-label">Active</div>
        </div>
    </div>
    <div class="col-4">
        <div class="tb-stat is-inactive">
            <div class="tb-stat-value" id="tbStatInactive">0</div>
            <div class="tb-stat-label">Inactive</div>
        </div>
    </div>
    <div class="col-4">
        <div class="tb-stat is-total">
            <div class="tb-stat-value" id="tbStatTotal">0</div>
            <div class="tb-stat-label">Total Blocks</div>
        </div>
    </div>
</div>

<!-- ================= Form ================= -->
<div class="card mb-3 tb-form-card">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-3">
            <i class="fas fa-pen-to-square text-sms-primary me-2"></i>
            <span id="tbFormTitle">Add Time Block</span>
        </h5>

        <input type="hidden" id="tbEditId" value="">

        <div class="row g-3">
            <div class="col-md-2">
                <label class="form-label fw-semibold">Code <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="tbCode" maxlength="20" placeholder="P1">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold">Start <span class="text-danger">*</span></label>
                <input type="time" class="form-control" id="tbStart">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold">End <span class="text-danger">*</span></label>
                <input type="time" class="form-control" id="tbEnd">
            </div>
            <div class="col-md-2">
                <label class="form-label fw-semibold">Type</label>
                <select class="form-select" id="tbType">
                    <option value="Class">Class</option>
                    <option value="Break">Break</option>
                    <option value="Exam">Exam</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label fw-semibold">Label</label>
                <input type="text" class="form-control" id="tbLabel" maxlength="60"
                       placeholder="Leave blank to generate from times">
            </div>
        </div>

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mt-3">
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="tbActive" checked>
                <label class="form-check-label" for="tbActive">
                    Active &mdash; offer this period when scheduling
                </label>
            </div>
            <div class="d-flex gap-2">
                <button type="button" class="btn btn-outline-secondary d-none" id="tbCancelBtn">
                    <i class="fas fa-xmark me-1"></i> Cancel
                </button>
                <button type="button" class="btn btn-primary" id="tbSaveBtn">
                    <i class="fas fa-floppy-disk me-1"></i> Save Time Block
                </button>
            </div>
        </div>
    </div>
</div>

<!-- ================= List ================= -->
<div class="card">
    <div class="card-body">
        <h5 class="card-title fw-semibold mb-3">
            <i class="fas fa-list-ol text-sms-primary me-2"></i>Configured Time Blocks
        </h5>

        <div class="table-responsive">
            <table class="table submodule-table align-middle mb-0">
                <thead>
                    <tr>
                        <th style="width:55px;">No.</th>
                        <th style="width:100px;">Code</th>
                        <th>Label</th>
                        <th style="width:150px;">Period</th>
                        <th style="width:100px;">Type</th>
                        <th style="width:100px;" class="text-center">Status</th>
                        <th style="width:110px;" class="text-center">In Use</th>
                        <th style="width:210px;" class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody id="tbTableBody">
                    <tr><td colspan="8"><div class="tb-empty">Loading time blocks...</div></td></tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    const SMS_BASE = '<?= BASE_URL ?>';
    const TB_API   = SMS_BASE + '/api/scheduling/time-blocks.php';

    let blocks = [];

    const $ = (id) => document.getElementById(id);

    function escapeHtml(value) {
        return String(value ?? '')
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function showAlert(message, kind) {
        const box = $('tbAlert');
        box.className = 'alert submodule-alert alert-' + (kind || 'info');
        $('tbAlertText').textContent = message;
        box.classList.remove('d-none');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    function hideAlert() { $('tbAlert').classList.add('d-none'); }

    async function request(options) {
        const url = options && options.method === 'POST' ? TB_API : TB_API + '?action=list';
        const response = await fetch(url, Object.assign({
            credentials: 'same-origin',
            headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' }
        }, options || { method: 'GET' }));
        const data = await response.json();
        if (!response.ok || !data.ok) {
            throw new Error(data.error || 'Request failed.');
        }
        return data;
    }

    async function post(body) {
        return request({ method: 'POST', body: JSON.stringify(body) });
    }

    /* ---------- load ---------- */
    async function loadBlocks() {
        try {
            const data = await request();
            blocks = data.blocks || [];
            $('tbStatActive').textContent   = data.summary.active;
            $('tbStatInactive').textContent = data.summary.inactive;
            $('tbStatTotal').textContent    = data.summary.total;
            renderBlocks();
            console.log('Time blocks loaded:', data);
        } catch (error) {
            showAlert(error.message, 'danger');
            console.error(error);
        }
    }

    function renderBlocks() {
        const body = $('tbTableBody');

        if (blocks.length === 0) {
            body.innerHTML = '<tr><td colspan="8"><div class="tb-empty">' +
                '<i class="fas fa-clock fa-2x mb-2 d-block opacity-50"></i>' +
                'No time blocks configured yet. Add one above.</div></td></tr>';
            return;
        }

        body.innerHTML = blocks.map((block, index) => {
            const active = Number(block.is_active) === 1;
            const usage  = Number(block.usage_count) || 0;

            const usageCell = usage > 0
                ? '<span class="tb-usage"><i class="fas fa-link me-1"></i>' + usage + '</span>'
                : '<span class="tb-usage text-muted">\u2014</span>';

            const deleteBtn = usage > 0
                ? '<button type="button" class="btn btn-sm btn-outline-secondary" disabled ' +
                  'title="In use by ' + usage + ' schedule entries">' +
                  '<i class="fas fa-trash-can"></i></button>'
                : '<button type="button" class="btn btn-sm btn-outline-danger" ' +
                  'onclick="TBDelete(' + Number(block.id) + ')" title="Delete">' +
                  '<i class="fas fa-trash-can"></i></button>';

            return '<tr class="' + (active ? '' : 'tb-row-inactive') + '">' +
                '<td>' + (index + 1) + '</td>' +
                '<td class="tb-code">' + escapeHtml(block.code) + '</td>' +
                '<td>' + escapeHtml(block.label) + '</td>' +
                '<td>' + escapeHtml(String(block.start_time).substring(0, 5)) + ' - ' +
                         escapeHtml(String(block.end_time).substring(0, 5)) + '</td>' +
                '<td><span class="tb-badge type-' + escapeHtml(block.block_type) + '">' +
                    escapeHtml(block.block_type) + '</span></td>' +
                '<td class="text-center"><span class="tb-badge ' + (active ? 'active' : 'inactive') + '">' +
                    (active ? 'Active' : 'Inactive') + '</span></td>' +
                '<td class="text-center">' + usageCell + '</td>' +
                '<td class="text-end">' +
                    '<div class="d-inline-flex gap-1">' +
                    '<button type="button" class="btn btn-sm btn-outline-primary" ' +
                        'onclick="TBEdit(' + Number(block.id) + ')" title="Edit">' +
                        '<i class="fas fa-pen"></i></button>' +
                    '<button type="button" class="btn btn-sm btn-outline-' +
                        (active ? 'warning' : 'success') + '" ' +
                        'onclick="TBToggle(' + Number(block.id) + ')" title="' +
                        (active ? 'Deactivate' : 'Activate') + '">' +
                        '<i class="fas fa-' + (active ? 'eye-slash' : 'eye') + '"></i></button>' +
                    deleteBtn +
                    '</div>' +
                '</td>' +
                '</tr>';
        }).join('');
    }

    /* ---------- form ---------- */
    function resetForm() {
        $('tbEditId').value = '';
        $('tbCode').value   = '';
        $('tbStart').value  = '';
        $('tbEnd').value    = '';
        $('tbType').value   = 'Class';
        $('tbLabel').value  = '';
        $('tbActive').checked = true;
        $('tbFormTitle').textContent = 'Add Time Block';
        $('tbSaveBtn').innerHTML = '<i class="fas fa-floppy-disk me-1"></i> Save Time Block';
        $('tbCancelBtn').classList.add('d-none');
    }

    window.TBEdit = function (id) {
        const block = blocks.find(b => Number(b.id) === Number(id));
        if (!block) { return; }

        $('tbEditId').value = block.id;
        $('tbCode').value   = block.code;
        $('tbStart').value  = String(block.start_time).substring(0, 5);
        $('tbEnd').value    = String(block.end_time).substring(0, 5);
        $('tbType').value   = block.block_type;
        $('tbLabel').value  = block.label;
        $('tbActive').checked = Number(block.is_active) === 1;

        $('tbFormTitle').textContent = 'Edit Time Block \u2014 ' + block.code;
        $('tbSaveBtn').innerHTML = '<i class="fas fa-floppy-disk me-1"></i> Update Time Block';
        $('tbCancelBtn').classList.remove('d-none');
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    async function saveBlock() {
        hideAlert();

        const id = $('tbEditId').value;
        const body = {
            action:     id ? 'update' : 'create',
            code:       $('tbCode').value.trim(),
            start_time: $('tbStart').value,
            end_time:   $('tbEnd').value,
            block_type: $('tbType').value,
            label:      $('tbLabel').value.trim(),
            is_active:  $('tbActive').checked ? 1 : 0
        };
        if (id) { body.id = Number(id); }

        if (!body.code)       { showAlert('Block code is required.', 'danger'); return; }
        if (!body.start_time) { showAlert('Start time is required.', 'danger'); return; }
        if (!body.end_time)   { showAlert('End time is required.', 'danger'); return; }

        const button = $('tbSaveBtn');
        const original = button.innerHTML;
        button.disabled = true;
        button.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i> Saving...';

        try {
            const data = await post(body);
            showAlert(data.message, 'success');
            resetForm();
            await loadBlocks();
        } catch (error) {
            showAlert(error.message, 'danger');
        } finally {
            button.disabled = false;
            button.innerHTML = original;
        }
    }

    window.TBToggle = async function (id) {
        hideAlert();
        try {
            const data = await post({ action: 'toggle', id: Number(id) });
            showAlert(data.message, 'success');
            await loadBlocks();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    };

    window.TBDelete = async function (id) {
        const block = blocks.find(b => Number(b.id) === Number(id));
        const name  = block ? block.code : 'this block';
        if (!window.confirm('Delete time block ' + name + '? This cannot be undone.')) {
            return;
        }
        hideAlert();
        try {
            const data = await post({ action: 'delete', id: Number(id) });
            showAlert(data.message, 'success');
            resetForm();
            await loadBlocks();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    };

    document.addEventListener('DOMContentLoaded', function () {
        $('tbSaveBtn').addEventListener('click', saveBlock);
        $('tbCancelBtn').addEventListener('click', function () {
            resetForm();
            hideAlert();
        });
        loadBlocks();
    });
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
