<?php
/**
 * SMS 2 - Exam Timetable Generator
 * Module: Class Scheduling  (Phase 10, Part A)
 *
 * Creates examinations from a section's assigned subjects, then assigns each a
 * date, time, room, and proctor. Conflicts are checked against other exams,
 * regular classes, and special sessions before an exam may be published.
 */
require_once __DIR__ . '/../../../config/config.php';

$pageTitle    = 'Exam Timetable Generator';
$activeModule = 'scheduling';
$activePage   = 'exam-timetable-generator';
$breadcrumbs  = [
    ['label' => 'Class Scheduling', 'url' => BASE_URL . '/modules/scheduling/index.php'],
    ['label' => 'Exam Timetable Generator', 'url' => null],
];

$hideModulePageBanner = true;

require_once __DIR__ . '/../../../includes/breadcrumbs.php';
require_once __DIR__ . '/../../../includes/layout-start.php';
?>

<?php renderBreadcrumbs($breadcrumbs); ?>

<style>
    .exm-meta { font-size: .78rem; color: #6c757d; }

    .exm-stat { border-radius: .6rem; border: 1px solid #e6e9ef; padding: .9rem; text-align: center; height: 100%; }
    .exm-stat .exm-stat-value { font-size: 1.7rem; font-weight: 700; line-height: 1; }
    .exm-stat .exm-stat-label {
        font-size: .7rem; letter-spacing: .05em; text-transform: uppercase;
        color: #6c757d; margin-top: .3rem;
    }
    .exm-stat.is-total   { background: #f4f7fb; border-color: #dbe5f1; }
    .exm-stat.is-total   .exm-stat-value { color: var(--sms-primary, #1F4E79); }
    .exm-stat.is-clean   { background: #f2fbf5; border-color: #cdeed9; }
    .exm-stat.is-clean   .exm-stat-value { color: #1e7e42; }
    .exm-stat.is-warning { background: #fff9ee; border-color: #f2e2c4; }
    .exm-stat.is-warning .exm-stat-value { color: #b26a00; }

    .exm-badge { font-size: .72rem; font-weight: 600; padding: .3rem .6rem; border-radius: 999px; white-space: nowrap; }
    .exm-badge.st-Draft     { background: #e4ecfa; color: #26497f; }
    .exm-badge.st-Validated { background: #fdf0d5; color: #8a5b00; }
    .exm-badge.st-Published { background: #d9f2e3; color: #1e7e42; }
    .exm-badge.st-Cancelled { background: #f1f3f5; color: #6c757d; }

    .exm-type { font-size: .72rem; font-weight: 600; padding: .25rem .55rem; border-radius: .35rem;
                background: #eef2f7; color: #40506b; white-space: nowrap; }
    .exm-src  { font-size: .68rem; font-weight: 600; padding: .18rem .45rem; border-radius: .3rem;
                background: #f1f3f5; color: #6c757d; white-space: nowrap; }
    .exm-src.is-optimizer { background: #ede7f9; color: #4a2f86; }

    .exm-unscheduled { background: #fffdf6; }
    .exm-unscheduled td { border-left: 3px solid transparent; }
    .exm-unscheduled td:first-child { border-left-color: #e0b64a; }

    .exm-conflict {
        border: 1px solid #f2c9cd; background: #fdf4f5; border-radius: .5rem;
        padding: .7rem .9rem; margin-bottom: .5rem;
    }
    .exm-conflict.is-warning { border-color: #f2e2c4; background: #fff9ee; }
    .exm-conflict .exm-conflict-head { font-weight: 600; color: #b02a37; font-size: .85rem; }
    .exm-conflict.is-warning .exm-conflict-head { color: #b26a00; }
    .exm-conflict .exm-conflict-body { font-size: .82rem; color: #55424a; margin-top: .15rem; }
    .exm-conflict .exm-conflict-act  { font-size: .78rem; color: #6c757d; margin-top: .2rem; }

    .exm-solved {
        border: 1px solid #cdeed9; background: #f2fbf5; border-radius: .5rem;
        padding: .8rem 1rem;
    }
    .exm-solved .exm-solved-head { font-weight: 600; color: #1e7e42; font-size: .88rem; }
    .exm-solved .exm-solved-body { font-size: .82rem; color: #40563f; margin-top: .2rem; }

    .exm-empty { padding: 2.5rem 1rem; text-align: center; color: #6c757d; }
    #exmTable td { vertical-align: middle; }
</style>

<div class="page-header d-flex justify-content-between align-items-start flex-wrap gap-2">
    <div>
        <h1><i class="fas fa-file-pen text-sms-primary me-2"></i>Exam Timetable Generator</h1>
        <p>Create examinations for a section, then assign each a date, room, and proctor.</p>
    </div>
</div>

<div id="exmAlert" class="alert submodule-alert d-none" role="alert">
    <i class="fas fa-circle-info me-2"></i><span id="exmAlertText"></span>
</div>

<!-- Step 1: generate -->
<div class="card mb-3">
    <div class="card-body p-4">
        <h5 class="fw-semibold mb-3"><i class="fas fa-wand-magic-sparkles me-2 text-sms-primary"></i>Create Examinations</h5>

        <div class="row g-3 align-items-end">
            <div class="col-md-5">
                <label for="exmGenSection" class="form-label fw-semibold">Section</label>
                <select id="exmGenSection" class="form-select rounded-3"></select>
                <div id="exmGenMeta" class="exm-meta mt-1"></div>
            </div>
            <div class="col-md-3">
                <label for="exmGenType" class="form-label fw-semibold">Examination</label>
                <select id="exmGenType" class="form-select rounded-3"></select>
            </div>
            <div class="col-md-4">
                <button id="exmGenBtn" class="btn btn-primary rounded-3 w-100">
                    <i class="fas fa-plus me-2"></i>Create for All Subjects
                </button>
            </div>
        </div>

        <div class="exm-meta mt-2">
            One examination is created per subject assigned to the section. Existing examinations are left alone.
        </div>
    </div>
</div>

<!-- Optimiser -->
<div class="card mb-3">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0">
                <i class="fas fa-microchip me-2 text-sms-primary"></i>Automatic Scheduling
            </h5>
            <span class="exm-src is-optimizer">Google OR-Tools &middot; CP-SAT</span>
        </div>

        <p class="exm-meta mb-3">
            Assigns a date, period, and room to every examination still awaiting a schedule,
            avoiding proctor, room, and section clashes as well as published class hours.
        </p>

        <div class="row g-3">
            <div class="col-md-3">
                <label for="optFrom" class="form-label fw-semibold">Examination period from</label>
                <input type="date" id="optFrom" class="form-control rounded-3">
            </div>
            <div class="col-md-3">
                <label for="optTo" class="form-label fw-semibold">to</label>
                <input type="date" id="optTo" class="form-control rounded-3">
            </div>
            <div class="col-md-3">
                <label for="optPeriods" class="form-label fw-semibold">Daily periods</label>
                <select id="optPeriods" class="form-select rounded-3">
                    <option value="2">2 periods (08:00, 10:30)</option>
                    <option value="3" selected>3 periods (08:00, 10:30, 13:00)</option>
                    <option value="4">4 periods (08:00, 10:30, 13:00, 15:30)</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="optMaxPerDay" class="form-label fw-semibold">Max per section per day</label>
                <select id="optMaxPerDay" class="form-select rounded-3">
                    <option value="1">1</option>
                    <option value="2" selected>2</option>
                    <option value="3">3</option>
                </select>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-2 mt-3 align-items-center">
            <button id="optRunBtn" class="btn btn-primary rounded-3">
                <i class="fas fa-play me-2"></i>Generate Optimised Timetable
            </button>
            <span id="optPending" class="exm-meta"></span>
        </div>

        <div id="optResult" class="mt-3 d-none">
            <div class="exm-solved">
                <div class="exm-solved-head" id="optResultHead"></div>
                <div class="exm-solved-body" id="optResultBody"></div>
            </div>
        </div>
    </div>
</div>

<!-- Summary -->
<div class="row g-3 mb-3">
    <div class="col-4">
        <div class="exm-stat is-total">
            <div class="exm-stat-value" id="exmStatTotal">0</div>
            <div class="exm-stat-label">Examinations</div>
        </div>
    </div>
    <div class="col-4">
        <div class="exm-stat is-warning">
            <div class="exm-stat-value" id="exmStatUnscheduled">0</div>
            <div class="exm-stat-label">Awaiting Schedule</div>
        </div>
    </div>
    <div class="col-4">
        <div class="exm-stat is-clean">
            <div class="exm-stat-value" id="exmStatPublished">0</div>
            <div class="exm-stat-label">Published</div>
        </div>
    </div>
</div>

<!-- Step 2: schedule -->
<div class="card">
    <div class="card-body p-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
            <h5 class="fw-semibold mb-0"><i class="fas fa-list-check me-2 text-sms-primary"></i>Examination Timetable</h5>
            <div class="d-flex gap-2 align-items-center">
                <select id="exmFilterSection" class="form-select form-select-sm rounded-3" style="width:auto"></select>
                <select id="exmFilterType" class="form-select form-select-sm rounded-3" style="width:auto">
                    <option value="">All examinations</option>
                </select>
                <select id="exmFilterStatus" class="form-select form-select-sm rounded-3" style="width:auto">
                    <option value="">All statuses</option>
                    <option value="Draft">Draft</option>
                    <option value="Validated">Validated</option>
                    <option value="Published">Published</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
                <button id="exmRefreshBtn" class="btn btn-outline-primary btn-sm rounded-3">
                    <i class="fas fa-rotate me-1"></i>Refresh
                </button>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-hover align-middle" id="exmTable">
                <thead class="table-light">
                    <tr>
                        <th style="width:16%">Subject</th>
                        <th style="width:9%">Section</th>
                        <th style="width:9%">Type</th>
                        <th style="width:12%">Date</th>
                        <th style="width:12%">Time</th>
                        <th style="width:14%">Proctor</th>
                        <th style="width:9%">Room</th>
                        <th style="width:9%">Status</th>
                        <th style="width:10%">Action</th>
                    </tr>
                </thead>
                <tbody id="exmBody">
                    <tr>
                        <td colspan="9">
                            <div class="exm-empty">
                                <i class="fas fa-file-pen fa-2x mb-2 d-block opacity-50"></i>
                                No examinations yet. Select a section above and create them.
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Schedule dialog -->
<div class="modal fade" id="exmModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content rounded-4">
            <div class="modal-header">
                <h5 class="modal-title fw-semibold"><i class="fas fa-calendar-check me-2 text-sms-primary"></i>Schedule Examination</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="exmModalHeading" class="fw-semibold mb-1"></div>
                <div id="exmModalMeta" class="exm-meta mb-3"></div>

                <div class="row g-3">
                    <div class="col-md-4">
                        <label for="exmDate" class="form-label fw-semibold">Date</label>
                        <input type="date" id="exmDate" class="form-control rounded-3">
                        <div id="exmWeekday" class="exm-meta mt-1"></div>
                    </div>
                    <div class="col-md-4">
                        <label for="exmStart" class="form-label fw-semibold">Start time</label>
                        <input type="time" id="exmStart" class="form-control rounded-3">
                    </div>
                    <div class="col-md-4">
                        <label for="exmEnd" class="form-label fw-semibold">End time</label>
                        <input type="time" id="exmEnd" class="form-control rounded-3">
                    </div>
                    <div class="col-md-6">
                        <label for="exmProctor" class="form-label fw-semibold">Proctor</label>
                        <select id="exmProctor" class="form-select rounded-3"></select>
                    </div>
                    <div class="col-md-6">
                        <label for="exmRoom" class="form-label fw-semibold">Room</label>
                        <select id="exmRoom" class="form-select rounded-3"></select>
                    </div>
                    <div class="col-12">
                        <label for="exmRemarks" class="form-label fw-semibold">Remarks <span class="text-muted fw-normal">(optional)</span></label>
                        <input type="text" id="exmRemarks" class="form-control rounded-3" maxlength="255">
                    </div>
                </div>

                <div id="exmConflictBox" class="mt-3 d-none">
                    <div class="fw-semibold mb-2 text-danger">
                        <i class="fas fa-triangle-exclamation me-1"></i><span id="exmConflictCount"></span>
                    </div>
                    <div id="exmConflictList"></div>
                </div>
            </div>
            <div class="modal-footer">
                <button id="exmCheckBtn" class="btn btn-outline-primary rounded-3">
                    <i class="fas fa-magnifying-glass me-2"></i>Check Conflicts
                </button>
                <button id="exmSaveBtn" class="btn btn-success rounded-3">
                    <i class="fas fa-floppy-disk me-2"></i>Save Schedule
                </button>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    const EXM_API = '<?= BASE_URL ?>/api/scheduling/exam-timetable.php';
    const OPT_API = '<?= BASE_URL ?>/api/scheduling/exam-optimize.php';

    let sections = [];
    let teachers = [];
    let rooms    = [];
    let editing  = null;
    let modal    = null;

    const $ = (id) => document.getElementById(id);

    function showAlert(message, kind) {
        const box = $('exmAlert');
        box.className = 'alert submodule-alert alert-' + (kind || 'info');
        $('exmAlertText').textContent = message;
        box.classList.remove('d-none');
    }

    function hideAlert() {
        $('exmAlert').classList.add('d-none');
    }

    async function request(url, options) {
        const response = await fetch(url, options || { method: 'GET' });
        let data = null;

        try {
            data = await response.json();
        } catch (error) {
            throw new Error('The server returned an unreadable response.');
        }

        if (!response.ok || !data.ok) {
            throw new Error((data && data.error) || 'Request failed.');
        }

        return data;
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function optionList(items, valueKey, labelFn, selected) {
        return items.map((item) =>
            '<option value="' + item[valueKey] + '"' +
            (Number(selected) === Number(item[valueKey]) ? ' selected' : '') + '>' +
            escapeHtml(labelFn(item)) + '</option>'
        ).join('');
    }

    function updateGenMeta() {
        const id = Number($('exmGenSection').value);
        const section = sections.find((s) => Number(s.id) === id);

        if (!section) {
            $('exmGenMeta').textContent = '';
            return;
        }

        const bits = [];
        if (section.program)       { bits.push(section.program); }
        if (section.year_level)    { bits.push('Year ' + section.year_level); }
        if (section.semester)      { bits.push(section.semester); }
        if (section.academic_year) { bits.push('SY ' + section.academic_year); }
        if (section.current_students) { bits.push(section.current_students + ' students'); }

        $('exmGenMeta').textContent = bits.join(' · ');
    }

    async function loadOptions() {
        try {
            const data = await request(EXM_API + '?action=options');
            sections = data.sections || [];
            teachers = data.teachers || [];
            rooms    = data.rooms || [];

            const sectionOpts = optionList(sections, 'id', (s) => s.code + ' — ' + s.name);

            $('exmGenSection').innerHTML = '<option value="">Select a section…</option>' + sectionOpts;
            $('exmFilterSection').innerHTML = '<option value="">All sections</option>' + sectionOpts;

            const typeOpts = (data.types || [])
                .map((t) => '<option value="' + t + '">' + t + '</option>').join('');

            $('exmGenType').innerHTML = typeOpts;
            $('exmFilterType').innerHTML = '<option value="">All examinations</option>' + typeOpts;

            $('exmProctor').innerHTML = '<option value="">— None —</option>' +
                optionList(teachers, 'id', (t) => t.full_name);

            $('exmRoom').innerHTML = '<option value="">— None —</option>' +
                optionList(rooms, 'id', (r) => r.room_code +
                    (r.capacity ? ' (' + r.capacity + ' seats)' : ''));
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function generateExams() {
        const sectionId = $('exmGenSection').value;
        const examType  = $('exmGenType').value;

        if (!sectionId) {
            showAlert('Please select a section first.', 'warning');
            return;
        }

        const button = $('exmGenBtn');
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Creating…';

        try {
            const data = await request(EXM_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'generate',
                    section_id: Number(sectionId),
                    exam_type: examType
                })
            });

            showAlert(data.message, data.created > 0 ? 'success' : 'info');

            $('exmFilterSection').value = sectionId;
            await loadList();
        } catch (error) {
            showAlert(error.message, 'danger');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-plus me-2"></i>Create for All Subjects';
        }
    }

    function renderConflicts(conflicts) {
        const box = $('exmConflictBox');

        if (!conflicts || conflicts.length === 0) {
            box.classList.add('d-none');
            $('exmConflictList').innerHTML = '';
            return;
        }

        $('exmConflictCount').textContent = conflicts.length + ' issue(s) found';

        $('exmConflictList').innerHTML = conflicts.map((item) =>
            '<div class="exm-conflict' + (item.severity === 'Warning' ? ' is-warning' : '') + '">' +
                '<div class="exm-conflict-head">' + escapeHtml(item.type) + ' ' +
                    escapeHtml(item.severity.toLowerCase()) + ' · ' + escapeHtml(item.against) + '</div>' +
                '<div class="exm-conflict-body">' + escapeHtml(item.detail) + '</div>' +
                '<div class="exm-conflict-act"><i class="fas fa-lightbulb me-1"></i>' +
                    escapeHtml(item.action) + '</div>' +
            '</div>'
        ).join('');

        box.classList.remove('d-none');
    }

    function updateWeekday() {
        const value = $('exmDate').value;

        if (!value) {
            $('exmWeekday').textContent = '';
            return;
        }

        const parts = value.split('-').map(Number);
        const date = new Date(parts[0], parts[1] - 1, parts[2]);
        const names = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        $('exmWeekday').textContent = names[date.getDay()];
    }

    function openModal(row) {
        editing = row;

        $('exmModalHeading').textContent =
            row.subject_code + ' — ' + row.subject_name;
        $('exmModalMeta').textContent =
            row.section_code + ' · ' + row.exam_type + ' examination' +
            (row.units ? ' · ' + row.units + ' unit(s)' : '');

        $('exmDate').value    = row.exam_date || '';
        $('exmStart').value   = row.start_time || '';
        $('exmEnd').value     = row.end_time || '';
        $('exmProctor').value = row.proctor_id || '';
        $('exmRoom').value    = row.room_id || '';
        $('exmRemarks').value = '';

        updateWeekday();
        renderConflicts([]);

        modal.show();
    }

    function collectModal() {
        return {
            id: editing ? editing.id : 0,
            exam_date: $('exmDate').value,
            start_time: $('exmStart').value,
            end_time: $('exmEnd').value,
            proctor_id: Number($('exmProctor').value) || 0,
            room_id: Number($('exmRoom').value) || 0,
            remarks: $('exmRemarks').value.trim()
        };
    }

    function validateModal(form) {
        if (!form.exam_date)  { return 'Please choose a date.'; }
        if (!form.start_time) { return 'Please enter a start time.'; }
        if (!form.end_time)   { return 'Please enter an end time.'; }
        if (form.start_time >= form.end_time) {
            return 'Start time must be earlier than end time.';
        }
        return null;
    }

    async function checkConflicts() {
        const form = collectModal();
        const problem = validateModal(form);

        if (problem) {
            showAlert(problem, 'warning');
            return;
        }

        try {
            const params = new URLSearchParams({
                action: 'check',
                exam_date: form.exam_date,
                start_time: form.start_time,
                end_time: form.end_time,
                proctor_id: form.proctor_id,
                room_id: form.room_id,
                section_id: editing.section_id,
                id: form.id
            });

            const data = await request(EXM_API + '?' + params.toString());
            renderConflicts(data.conflicts);

            if (data.count === 0) {
                showAlert('No conflicts found for ' + data.weekday + ' ' + form.exam_date + '.', 'success');
            }
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function saveSchedule() {
        const form = collectModal();
        const problem = validateModal(form);

        if (problem) {
            showAlert(problem, 'warning');
            return;
        }

        const button = $('exmSaveBtn');
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Saving…';

        try {
            const data = await request(EXM_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(Object.assign({ action: 'save' }, form))
            });

            renderConflicts(data.conflicts);

            const hasErrors = (data.conflicts || [])
                .some((c) => c.severity === 'Error');

            showAlert(data.message, hasErrors ? 'warning' : 'success');

            if (!hasErrors) {
                modal.hide();
            }

            await loadList();
        } catch (error) {
            showAlert(error.message, 'danger');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-floppy-disk me-2"></i>Save Schedule';
        }
    }

    function renderList(data) {
        const body = $('exmBody');
        const records = data.records || [];

        if (records.length === 0) {
            body.innerHTML =
                '<tr><td colspan="9"><div class="exm-empty">' +
                '<i class="fas fa-file-pen fa-2x mb-2 d-block opacity-50"></i>' +
                'No examinations match the current filter.' +
                '</div></td></tr>';
            return;
        }

        body.innerHTML = records.map((row) => {
            let actions = '<button class="btn btn-outline-primary btn-sm rounded-3 me-1" ' +
                'data-act="edit" data-id="' + row.id + '" title="Schedule">' +
                '<i class="fas fa-calendar-days"></i></button>';

            if (row.status === 'Draft' && row.scheduled) {
                actions += '<button class="btn btn-outline-success btn-sm rounded-3 me-1" ' +
                    'data-act="Published" data-id="' + row.id + '" title="Publish">' +
                    '<i class="fas fa-check"></i></button>';
            }

            if (row.status !== 'Cancelled' && row.status !== 'Published') {
                actions += '<button class="btn btn-outline-secondary btn-sm rounded-3" ' +
                    'data-act="Cancelled" data-id="' + row.id + '" title="Cancel">' +
                    '<i class="fas fa-xmark"></i></button>';
            }

            const dateCell = row.scheduled
                ? escapeHtml(row.exam_date) + '<div class="exm-meta">' + escapeHtml(row.weekday) + '</div>'
                : '<span class="text-muted">Not set</span>';

            const srcBadge = row.source === 'Optimizer'
                ? '<span class="exm-src is-optimizer">Optimizer</span>'
                : '';

            return '<tr' + (row.scheduled ? '' : ' class="exm-unscheduled"') + '>' +
                '<td class="small"><span class="fw-semibold">' + escapeHtml(row.subject_code) + '</span>' +
                    '<div class="exm-meta">' + escapeHtml(row.subject_name) + '</div></td>' +
                '<td class="small">' + escapeHtml(row.section_code) + '</td>' +
                '<td><span class="exm-type">' + escapeHtml(row.exam_type) + '</span> ' + srcBadge + '</td>' +
                '<td class="small">' + dateCell + '</td>' +
                '<td class="small">' + (row.time ? escapeHtml(row.time) : '<span class="text-muted">—</span>') + '</td>' +
                '<td class="small">' + escapeHtml(row.proctor_name || '—') + '</td>' +
                '<td class="small">' + escapeHtml(row.room_code || '—') + '</td>' +
                '<td><span class="exm-badge st-' + escapeHtml(row.status) + '">' +
                    escapeHtml(row.status) + '</span></td>' +
                '<td>' + actions + '</td>' +
                '</tr>';
        }).join('');

        body.querySelectorAll('button[data-act]').forEach((button) => {
            const id = Number(button.dataset.id);
            const act = button.dataset.act;

            button.addEventListener('click', () => {
                if (act === 'edit') {
                    const row = records.find((r) => r.id === id);
                    if (row) { openModal(row); }
                } else {
                    updateStatus(id, act);
                }
            });
        });
    }

    async function loadList() {
        try {
            const params = new URLSearchParams({ action: 'list' });

            const section = $('exmFilterSection').value;
            if (section) { params.set('section_id', section); }

            const type = $('exmFilterType').value;
            if (type) { params.set('exam_type', type); }

            const status = $('exmFilterStatus').value;
            if (status) { params.set('status', status); }

            const data = await request(EXM_API + '?' + params.toString());

            renderList(data);

            const published = (data.records || [])
                .filter((r) => r.status === 'Published').length;

            $('exmStatTotal').textContent       = data.count || 0;
            $('exmStatUnscheduled').textContent = data.unscheduled || 0;
            $('exmStatPublished').textContent   = published;
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    async function updateStatus(id, status) {
        try {
            const data = await request(EXM_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ action: 'update_status', id: id, status: status })
            });

            showAlert(data.message, 'success');
            await loadList();
        } catch (error) {
            showAlert(error.message, 'danger');
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        modal = new bootstrap.Modal($('exmModal'));

        $('exmGenBtn').addEventListener('click', generateExams);
        $('exmGenSection').addEventListener('change', updateGenMeta);
        $('exmRefreshBtn').addEventListener('click', loadList);
        $('exmFilterSection').addEventListener('change', function () { loadList(); refreshPending(); });
        $('exmFilterType').addEventListener('change', loadList);
        $('exmFilterStatus').addEventListener('change', loadList);
        $('exmCheckBtn').addEventListener('click', checkConflicts);
        $('exmSaveBtn').addEventListener('click', saveSchedule);
        $('exmDate').addEventListener('change', updateWeekday);

        $('optRunBtn').addEventListener('click', runOptimizer);

        loadOptions().then(function () {
            loadList();
            refreshPending();
        });
    });

    /* ------------------------- Optimiser ------------------------- */

    const OPT_PERIOD_SETS = {
        2: [{ start: '08:00', end: '10:00' }, { start: '10:30', end: '12:30' }],
        3: [{ start: '08:00', end: '10:00' }, { start: '10:30', end: '12:30' },
            { start: '13:00', end: '15:00' }],
        4: [{ start: '08:00', end: '10:00' }, { start: '10:30', end: '12:30' },
            { start: '13:00', end: '15:00' }, { start: '15:30', end: '17:30' }]
    };

    async function refreshPending() {
        try {
            const params = new URLSearchParams({ action: 'preview' });

            const section = $('exmFilterSection').value;
            if (section) { params.set('section_id', section); }

            const type = $('exmFilterType').value;
            if (type) { params.set('exam_type', type); }

            const data = await request(OPT_API + '?' + params.toString());

            $('optPending').textContent = data.pending > 0
                ? data.pending + ' examination(s) awaiting a schedule · ' +
                  data.rooms + ' room(s) available'
                : 'Nothing is awaiting a schedule.';
        } catch (error) {
            $('optPending').textContent = '';
        }
    }

    async function runOptimizer() {
        const from = $('optFrom').value;
        const to   = $('optTo').value;

        if (!from || !to) {
            showAlert('Please choose the start and end of the examination period.', 'warning');
            return;
        }

        if (from > to) {
            showAlert('The start date must not be after the end date.', 'warning');
            return;
        }

        const button = $('optRunBtn');
        button.disabled = true;
        button.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Solving…';
        $('optResult').classList.add('d-none');

        try {
            const data = await request(OPT_API, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action: 'optimize',
                    section_id: Number($('exmFilterSection').value) || 0,
                    exam_type: $('exmFilterType').value || '',
                    from_date: from,
                    to_date: to,
                    periods: OPT_PERIOD_SETS[$('optPeriods').value] || OPT_PERIOD_SETS[3],
                    max_per_day: Number($('optMaxPerDay').value) || 2
                })
            });

            $('optResultHead').textContent = data.status === 'OPTIMAL'
                ? 'Optimal timetable found'
                : 'Feasible timetable found';

            $('optResultBody').textContent =
                data.applied + ' examination(s) placed across ' + data.slots +
                ' candidate slot(s) and ' + data.rooms + ' room(s). ' +
                data.blocked + ' combination(s) were ruled out by published classes. ' +
                'Solved in ' + (data.wall_time !== null ? data.wall_time + 's' : 'under a second') + '.';

            $('optResult').classList.remove('d-none');
            showAlert(data.message, 'success');

            await loadList();
            await refreshPending();
        } catch (error) {
            showAlert(error.message, 'danger');
        } finally {
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-play me-2"></i>Generate Optimised Timetable';
        }
    }
})();
</script>

<?php require_once __DIR__ . '/../../../includes/layout-end.php'; ?>
